import { useState, useMemo } from 'react';
import { cn } from '@/lib/utils';
import { Users, AlertCircle } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useLanguage } from '@/context/LanguageContext';
import { useCart } from '@/context/CartContext';
import type { ProductDetail } from '@/config';

interface BulkQuoteModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: ProductDetail;
  selectedColor: string;
  onColorChange: (color: string) => void;
}

export function BulkQuoteModal({
  isOpen,
  onClose,
  product,
  selectedColor,
  onColorChange,
}: BulkQuoteModalProps) {
  const { t, language } = useLanguage();
  const { addItem } = useCart();

  const [localColor, setLocalColor] = useState(selectedColor);
  const [sizeQuantities, setSizeQuantities] = useState<Record<string, number>>(() => {
    const initial: Record<string, number> = {};
    product.sizes.forEach((size) => {
      initial[size.id] = 0;
    });
    return initial;
  });

  const selectedColorData = product.colors.find((c) => c.id === localColor);

  const totalQuantity = useMemo(() => {
    return Object.values(sizeQuantities).reduce((sum, qty) => sum + qty, 0);
  }, [sizeQuantities]);

  const isValidQuantity = totalQuantity >= product.minBulkQuantity;

  const handleColorSelect = (colorId: string) => {
    setLocalColor(colorId);
    onColorChange(colorId);
  };

  const handleQuantityChange = (sizeId: string, delta: number) => {
    setSizeQuantities((prev) => {
      const currentQty = prev[sizeId] || 0;
      const newQty = Math.max(0, currentQty + delta);
      return { ...prev, [sizeId]: newQty };
    });
  };

  const handleInputChange = (sizeId: string, value: string) => {
    const numValue = parseInt(value, 10);
    setSizeQuantities((prev) => ({
      ...prev,
      [sizeId]: isNaN(numValue) ? 0 : Math.max(0, numValue),
    }));
  };

  const handleSubmit = () => {
    if (!localColor || !isValidQuantity) {
      return;
    }

    const colorData = product.colors.find((c) => c.id === localColor);
    const filteredSizes: Record<string, number> = {};
    Object.entries(sizeQuantities).forEach(([size, qty]) => {
      if (qty > 0) {
        filteredSizes[size] = qty;
      }
    });

    addItem({
      productId: product.id,
      productName: product.name,
      productImage: product.images[0],
      type: 'BULK',
      color: localColor,
      colorLabel: colorData?.name || { en: localColor, ar: localColor },
      sizes: filteredSizes,
      quantity: totalQuantity,
      sku: product.sku,
    });

    onClose();
    // Reset quantities
    const initial: Record<string, number> = {};
    product.sizes.forEach((size) => {
      initial[size.id] = 0;
    });
    setSizeQuantities(initial);
  };

  const canSubmit = localColor && isValidQuantity;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-[#000000] flex items-center gap-2">
            <Users className="w-5 h-5 text-[#E10715]" />
            {language === 'ar' ? 'طلب بالجملة' : 'Bulk Order Request'}
          </DialogTitle>
        </DialogHeader>

        <div className="mt-4 space-y-6">
          {/* Product Info */}
          <div className="flex items-center gap-4 p-4 bg-[#F6F6F6] rounded-xl">
            <img
              src={product.images[0]}
              alt={t(product.name)}
              className="w-16 h-16 object-cover rounded-lg"
              onError={(e) => {
                (e.target as HTMLImageElement).src = '/images/placeholder-product.jpg';
              }}
            />
            <div>
              <p className="font-medium text-[#000000]">{t(product.name)}</p>
              <p className="text-sm text-[#000000]/50">{product.sku}</p>
            </div>
          </div>

          {/* Color Selector */}
          <div>
            <label className="block text-sm font-medium text-[#000000] mb-3">
              {language === 'ar' ? 'اختر اللون:' : 'Select Color:'}
            </label>
            <div className="flex gap-3">
              {product.colors.map((color) => (
                <button
                  key={color.id}
                  onClick={() => handleColorSelect(color.id)}
                  className={cn(
                    'group relative w-10 h-10 rounded-full border-2 transition-all',
                    localColor === color.id
                      ? 'border-[#E10715] ring-2 ring-[#E10715]/30'
                      : 'border-transparent hover:scale-110'
                  )}
                  title={t(color.name)}
                >
                  <span
                    className="absolute inset-1 rounded-full"
                    style={{ backgroundColor: color.hex }}
                  />
                  {localColor === color.id && (
                    <span className="absolute inset-0 flex items-center justify-center">
                      <span className="w-1.5 h-1.5 bg-white rounded-full shadow-sm" />
                    </span>
                  )}
                </button>
              ))}
            </div>
            {selectedColorData && (
              <p className="mt-2 text-sm text-[#000000]/60">{t(selectedColorData.name)}</p>
            )}
          </div>

          {/* Size Quantities */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <label className="block text-sm font-medium text-[#000000]">
                {language === 'ar' ? 'الكمية حسب المقاس:' : 'Quantity by Size:'}
              </label>
              <span
                className={cn(
                  'text-sm font-medium',
                  isValidQuantity ? 'text-green-600' : 'text-[#E10715]'
                )}
              >
                {language === 'ar' ? 'الإجمالي:' : 'Total:'} {totalQuantity}
              </span>
            </div>

            <div className="space-y-3">
              {product.sizes.map((size) => (
                <div
                  key={size.id}
                  className="flex items-center justify-between p-3 bg-[#F6F6F6] rounded-lg"
                >
                  <div className="flex items-center gap-3">
                    <span className="w-10 h-10 flex items-center justify-center bg-white rounded-lg font-medium text-[#000000]">
                      {size.label}
                    </span>
                    <div className="text-xs text-[#000000]/50">
                      {size.chest && <span>{size.chest}</span>}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleQuantityChange(size.id, -1)}
                      className="w-8 h-8 flex items-center justify-center bg-white rounded-lg hover:bg-[#000000]/5 transition-colors"
                    >
                      <span className="text-lg leading-none">−</span>
                    </button>
                    <input
                      type="number"
                      min="0"
                      value={sizeQuantities[size.id] || 0}
                      onChange={(e) => handleInputChange(size.id, e.target.value)}
                      className="w-14 h-8 text-center bg-white rounded-lg text-sm font-medium text-[#000000] border-0 focus:ring-2 focus:ring-[#E10715]/20"
                    />
                    <button
                      onClick={() => handleQuantityChange(size.id, 1)}
                      className="w-8 h-8 flex items-center justify-center bg-white rounded-lg hover:bg-[#000000]/5 transition-colors"
                    >
                      <span className="text-lg leading-none">+</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Minimum Quantity Warning */}
            {!isValidQuantity && (
              <div className="mt-3 flex items-center gap-2 p-3 bg-amber-50 rounded-lg">
                <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0" />
                <p className="text-sm text-amber-700">
                  {language === 'ar'
                    ? `الحد الأدنى للطلب ${product.minBulkQuantity} قطعة`
                    : `Minimum order is ${product.minBulkQuantity} pieces`}
                </p>
              </div>
            )}
          </div>

          {/* Submit Button */}
          <button
            onClick={handleSubmit}
            disabled={!canSubmit}
            className={cn(
              'w-full flex items-center justify-center gap-2 px-6 py-4 font-medium rounded-full transition-colors',
              canSubmit
                ? 'bg-[#E10715] text-white hover:bg-[#C00612]'
                : 'bg-[#F6F6F6] text-[#000000]/40 cursor-not-allowed'
            )}
          >
            {language === 'ar' ? 'إضافة إلى قائمة الطلب' : 'Add to Quote List'}
          </button>

          {!localColor && (
            <p className="text-center text-sm text-[#000000]/50">
              {language === 'ar' ? 'الرجاء اختيار اللون' : 'Please select a color'}
            </p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

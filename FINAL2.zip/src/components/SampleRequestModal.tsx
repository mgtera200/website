import { useState } from 'react';
import { cn } from '@/lib/utils';
import { Minus, Plus, TestTube } from 'lucide-react';  // FIXED: Removed unused X
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useLanguage } from '@/context/LanguageContext';
import { useCart } from '@/context/CartContext';
import type { ProductDetail } from '@/config';

interface SampleRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: ProductDetail;
  selectedColor: string;
  selectedSize: string;
  onColorChange: (color: string) => void;
  onSizeChange: (size: string) => void;
}

export function SampleRequestModal({
  isOpen,
  onClose,
  product,
  selectedColor,
  selectedSize,
  onColorChange,
  onSizeChange,
}: SampleRequestModalProps) {
  const { t, language } = useLanguage();  // FIXED: Removed unused dir
  const { addItem } = useCart();

  const [quantity, setQuantity] = useState(1);
  const [localColor, setLocalColor] = useState(selectedColor);
  const [localSize, setLocalSize] = useState(selectedSize);

  const selectedColorData = product.colors.find((c) => c.id === localColor);

  const handleQuantityChange = (delta: number) => {
    const newQuantity = quantity + delta;
    if (newQuantity >= 1 && newQuantity <= product.maxSampleQuantity) {
      setQuantity(newQuantity);
    }
  };

  const handleColorSelect = (colorId: string) => {
    setLocalColor(colorId);
    onColorChange(colorId);
  };

  const handleSizeSelect = (sizeId: string) => {
    setLocalSize(sizeId);
    onSizeChange(sizeId);
  };

  const handleSubmit = () => {
    if (!localColor || !localSize) {
      return;
    }

    const colorData = product.colors.find((c) => c.id === localColor);

    addItem({
      productId: product.id,
      productName: product.name,
      productImage: product.images[0],
      type: 'SAMPLE',
      color: localColor,
      colorLabel: colorData?.name || { en: localColor, ar: localColor },
      size: localSize,
      quantity,
      sku: product.sku,
    });

    onClose();
    setQuantity(1);
  };

  const canSubmit = localColor && localSize;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-[#000000] flex items-center gap-2">
            <TestTube className="w-5 h-5 text-[#E10715]" />
            {language === 'ar' ? 'طلب عينة' : 'Request Sample'}
          </DialogTitle>
        </DialogHeader>

        <div className="mt-4 space-y-6">
          {/* Product Info */}
          <div className="flex items-center gap-4 p-4 bg-[#F6F6F6] rounded-xl">
            <img
              src={product.images[0]}
              alt={t(product.name)}
              className="w-16 h-16 object-cover rounded-lg"
              onError={(e) => {
                (e.target as HTMLImageElement).src = '/images/placeholder-product.jpg';
              }}
            />
            <div>
              <p className="font-medium text-[#000000]">{t(product.name)}</p>
              <p className="text-sm text-[#000000]/50">{product.sku}</p>
            </div>
          </div>

          {/* Color Selector */}
          <div>
            <label className="block text-sm font-medium text-[#000000] mb-3">
              {language === 'ar' ? 'اختر اللون:' : 'Select Color:'}
            </label>
            <div className="flex gap-3">
              {product.colors.map((color) => (
                <button
                  key={color.id}
                  onClick={() => handleColorSelect(color.id)}
                  className={cn(
                    'group relative w-10 h-10 rounded-full border-2 transition-all',
                    localColor === color.id
                      ? 'border-[#E10715] ring-2 ring-[#E10715]/30'
                      : 'border-transparent hover:scale-110'
                  )}
                  title={t(color.name)}
                >
                  <span
                    className="absolute inset-1 rounded-full"
                    style={{ backgroundColor: color.hex }}
                  />
                  {localColor === color.id && (
                    <span className="absolute inset-0 flex items-center justify-center">
                      <span className="w-1.5 h-1.5 bg-white rounded-full shadow-sm" />
                    </span>
                  )}
                </button>
              ))}
            </div>
            {selectedColorData && (
              <p className="mt-2 text-sm text-[#000000]/60">{t(selectedColorData.name)}</p>
            )}
          </div>

          {/* Size Selector */}
          <div>
            <label className="block text-sm font-medium text-[#000000] mb-3">
              {language === 'ar' ? 'اختر المقاس:' : 'Select Size:'}
            </label>
            <div className="flex flex-wrap gap-2">
              {product.sizes.map((size) => (
                <button
                  key={size.id}
                  onClick={() => handleSizeSelect(size.id)}
                  className={cn(
                    'px-4 py-2 text-sm font-medium rounded-lg transition-all',
                    localSize === size.id
                      ? 'bg-[#000000] text-white'
                      : 'bg-[#F6F6F6] text-[#000000]/70 hover:bg-[#000000]/10'
                  )}
                >
                  {size.label}
                </button>
              ))}
            </div>
          </div>

          {/* Quantity Selector */}
          <div>
            <label className="block text-sm font-medium text-[#000000] mb-3">
              {language === 'ar' ? 'الكمية:' : 'Quantity:'}
            </label>
            <div className="flex items-center gap-4">
              <button
                onClick={() => handleQuantityChange(-1)}
                disabled={quantity <= 1}
                className="w-10 h-10 flex items-center justify-center bg-[#F6F6F6] rounded-lg hover:bg-[#000000]/10 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Minus className="w-4 h-4" />
              </button>
              <span className="text-lg font-medium text-[#000000] w-8 text-center">
                {quantity}
              </span>
              <button
                onClick={() => handleQuantityChange(1)}
                disabled={quantity >= product.maxSampleQuantity}
                className="w-10 h-10 flex items-center justify-center bg-[#F6F6F6] rounded-lg hover:bg-[#000000]/10 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
            <p className="mt-2 text-xs text-[#000000]/50">
              {language === 'ar'
                ? `الحد الأقصى: ${product.maxSampleQuantity} قطع`
                : `Maximum: ${product.maxSampleQuantity} pieces`}
            </p>
          </div>

          {/* Submit Button */}
          <button
            onClick={handleSubmit}
            disabled={!canSubmit}
            className={cn(
              'w-full flex items-center justify-center gap-2 px-6 py-4 font-medium rounded-full transition-colors',
              canSubmit
                ? 'bg-[#E10715] text-white hover:bg-[#C00612]'
                : 'bg-[#F6F6F6] text-[#000000]/40 cursor-not-allowed'
            )}
          >
            {language === 'ar' ? 'إضافة إلى قائمة الطلب' : 'Add to Quote List'}
          </button>

          {!canSubmit && (
            <p className="text-center text-sm text-[#000000]/50">
              {language === 'ar'
                ? 'الرجاء اختيار اللون والمقاس'
                : 'Please select color and size'}
            </p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

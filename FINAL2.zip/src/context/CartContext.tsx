import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import { toast } from 'sonner';
import { useLanguage } from './LanguageContext';

export type CartItemType = 'SAMPLE' | 'BULK';

export interface CartItem {
  id: string;
  productId: string;
  productName: Record<string, string>;
  productImage: string;
  type: CartItemType;
  color: string;
  colorLabel: Record<string, string>;
  size?: string;
  sizes?: Record<string, number>;
  quantity: number;
  sku: string;
  addedAt: number;
}

interface CartContextType {
  items: CartItem[];
  addItem: (item: Omit<CartItem, 'id' | 'addedAt'>) => void;
  removeItem: (id: string) => void;
  updateItemQuantity: (id: string, quantity: number) => void;
  updateBulkSizes: (id: string, sizes: Record<string, number>) => void;
  clearCart: () => void;
  getTotalItems: () => number;
  getSampleItems: () => CartItem[];
  getBulkItems: () => CartItem[];
  getBulkTotalQuantity: () => number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

const CART_STORAGE_KEY = 'tera_cart';

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);
  const { language } = useLanguage();

  // Load cart from localStorage on mount
  useEffect(() => {
    const savedCart = localStorage.getItem(CART_STORAGE_KEY);
    if (savedCart) {
      try {
        const parsed = JSON.parse(savedCart);
        setItems(parsed);
      } catch (e) {
        console.error('Failed to parse cart:', e);
      }
    }
    setIsLoaded(true);
  }, []);

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(items));
    }
  }, [items, isLoaded]);

  const generateId = () => {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  };

  const addItem = (item: Omit<CartItem, 'id' | 'addedAt'>) => {
    const newItem: CartItem = {
      ...item,
      id: generateId(),
      addedAt: Date.now(),
    };

    setItems((prev) => [...prev, newItem]);

    // Show toast notification
    const message = item.type === 'SAMPLE'
      ? language === 'ar' ? 'تم إضافة العينة إلى قائمة الطلب' : 'Sample added to quote list'
      : language === 'ar' ? 'تم إضافة الطلبية إلى قائمة الطلب' : 'Bulk order added to quote list';

    toast.success(message, {
      duration: 3000,
      position: 'bottom-right',
    });
  };

  const removeItem = (id: string) => {
    setItems((prev) => prev.filter((item) => item.id !== id));

    const message = language === 'ar' ? 'تم إزالة المنتج من القائمة' : 'Item removed from list';
    toast.success(message, {
      duration: 2000,
      position: 'bottom-right',
    });
  };

  const updateItemQuantity = (id: string, quantity: number) => {
    if (quantity <= 0) {
      removeItem(id);
      return;
    }

    setItems((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, quantity } : item
      )
    );
  };

  const updateBulkSizes = (id: string, sizes: Record<string, number>) => {
    const totalQuantity = Object.values(sizes).reduce((sum, qty) => sum + qty, 0);

    setItems((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, sizes, quantity: totalQuantity } : item
      )
    );
  };

  const clearCart = () => {
    setItems([]);
    localStorage.removeItem(CART_STORAGE_KEY);
  };

  const getTotalItems = () => {
    return items.length;
  };

  const getSampleItems = () => {
    return items.filter((item) => item.type === 'SAMPLE');
  };

  const getBulkItems = () => {
    return items.filter((item) => item.type === 'BULK');
  };

  const getBulkTotalQuantity = () => {
    return getBulkItems().reduce((total, item) => total + item.quantity, 0);
  };

  return (
    <CartContext.Provider
      value={{
        items,
        addItem,
        removeItem,
        updateItemQuantity,
        updateBulkSizes,
        clearCart,
        getTotalItems,
        getSampleItems,
        getBulkItems,
        getBulkTotalQuantity,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}

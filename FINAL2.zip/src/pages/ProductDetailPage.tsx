import { useState, useEffect, useRef } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import {
  ArrowLeft,
  ArrowUpRight,
  ChevronRight,
  Home,
  Package,
  Ruler,
  ShoppingCart,
  TestTube,
  Users,
} from 'lucide-react';
import { productDetailsConfig, sizeChartConfig } from '@/config';
import { useLanguage } from '@/context/LanguageContext';
import { useCart } from '@/context/CartContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { SampleRequestModal } from '@/components/SampleRequestModal';
import { BulkQuoteModal } from '@/components/BulkQuoteModal';

export function ProductDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { t, language, dir } = useLanguage();
  const { getTotalItems } = useCart();

  const [isVisible, setIsVisible] = useState(false);
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [isSizeChartOpen, setIsSizeChartOpen] = useState(false);
  const [isSampleModalOpen, setIsSampleModalOpen] = useState(false);
  const [isBulkModalOpen, setIsBulkModalOpen] = useState(false);

  const pageRef = useRef<HTMLDivElement>(null);

  const product = productDetailsConfig.find((p) => p.id === id);

  useEffect(() => {
    setIsVisible(true);
    if (product && product.colors.length > 0) {
      setSelectedColor(product.colors[0].id);
    }
  }, [product]);

  if (!product) {
    return (
      <div className="min-h-screen bg-white pt-24 lg:pt-32 pb-20">
        <div className="container-large px-5 lg:px-12 text-center">
          <h1 className="text-2xl lg:text-3xl font-bold text-[#000000] mb-4">
            {language === 'ar' ? 'المنتج غير موجود' : 'Product Not Found'}
          </h1>
          <Link
            to="/products"
            className="inline-flex items-center gap-2 px-6 py-3 bg-[#E10715] text-white rounded-full hover:bg-[#C00612] transition-colors"
          >
            <ArrowLeft className={cn("w-4 h-4", dir === 'rtl' && "rotate-180")} />
            {language === 'ar' ? 'العودة للمنتجات' : 'Back to Products'}
          </Link>
        </div>
      </div>
    );
  }

  const selectedColorData = product.colors.find((c) => c.id === selectedColor);
  const currentImages = product.images;

  const getSizeChartKey = () => {
    // Check for vests (including hv201, hv401, vs201)
    if (product.id.includes('vs201') || product.id.includes('hv201') || product.id.includes('hv401')) {
      return 'vests';
    }
    // Check for jackets (all jk products)
    if (product.id.includes('jk')) {
      return 'jackets';
    }
    // Check for farm wear (fw products)
    if (product.id.includes('fw')) {
      return 'farm-wear';
    }
    // Check for overalls (bib overalls, field engineer, hv901 set, workwear set)
    if (product.id.includes('bo301') || product.id.includes('fe402') || product.id.includes('hv901') || product.id.includes('workwear-set')) {
      return 'overalls';
    }
    // Default to coveralls for mc301, cw501, cw401, aw301
    return 'coveralls';
  };

  const sizeChartData = sizeChartConfig[getSizeChartKey()] || sizeChartConfig.coveralls;

  return (
    <div ref={pageRef} className="min-h-screen bg-white pt-20 lg:pt-28 pb-20">
      {/* Breadcrumb */}
      <div className="container-large px-5 lg:px-12 mb-6 lg:mb-8">
        <nav
          className={cn(
            'flex items-center gap-2 text-sm transition-all duration-700',
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          )}
        >
          <Link to="/" className="flex items-center gap-1 text-[#000000]/50 hover:text-[#E10715] transition-colors">
            <Home className="w-4 h-4" />
            <span>{language === 'ar' ? 'الرئيسية' : 'Home'}</span>
          </Link>
          <ChevronRight className={cn("w-4 h-4 text-[#000000]/30", dir === 'rtl' && "rotate-180")} />
          <Link to="/products" className="text-[#000000]/50 hover:text-[#E10715] transition-colors">
            {language === 'ar' ? 'المنتجات' : 'Products'}
          </Link>
          <ChevronRight className={cn("w-4 h-4 text-[#000000]/30", dir === 'rtl' && "rotate-180")} />
          <span className="text-[#000000] font-medium">{t(product.name)}</span>
        </nav>
      </div>

      {/* Main Content */}
      <div className="container-large px-5 lg:px-12">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
          {/* Image Gallery */}
          <div
            className={cn(
              'space-y-4 transition-all duration-700',
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            )}
            style={{ transitionDelay: '100ms' }}
          >
            {/* Main Image */}
            <div className="relative aspect-square bg-[#F6F6F6] rounded-[20px] lg:rounded-[28px] overflow-hidden">
              <img
                src={currentImages[selectedImageIndex]}
                alt={t(product.name)}
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = '/images/placeholder-product.jpg';
                }}
              />
              <div className="absolute top-4 left-4">
                <span className="px-3 py-1.5 text-xs font-geist-mono bg-white/90 backdrop-blur-sm rounded-full text-[#000000]">
                  {product.sku}
                </span>
              </div>
            </div>

            {/* Thumbnails */}
            <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
              {currentImages.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedImageIndex(index)}
                  className={cn(
                    'flex-shrink-0 w-20 h-20 lg:w-24 lg:h-24 rounded-xl overflow-hidden border-2 transition-all',
                    selectedImageIndex === index
                      ? 'border-[#E10715] ring-2 ring-[#E10715]/20'
                      : 'border-transparent hover:border-[#000000]/20'
                  )}
                >
                  <img
                    src={image}
                    alt={`${t(product.name)} - ${index + 1}`}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = '/images/placeholder-product.jpg';
                    }}
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Product Info */}
          <div
            className={cn(
              'space-y-6 lg:space-y-8 transition-all duration-700',
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            )}
            style={{ transitionDelay: '200ms' }}
          >
            {/* Header */}
            <div>
              <span className="text-xs font-geist-mono uppercase tracking-widest text-[#000000]/50">
                {t(product.category)}
              </span>
              <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-[#000000] mt-2 tracking-[-0.02em]">
                {t(product.name)}
              </h1>
              <p className="mt-4 text-base lg:text-lg text-[#000000]/70 leading-relaxed">
                {t(product.description)}
              </p>
            </div>

            {/* Material Specs */}
            <div className="p-4 lg:p-5 bg-[#F6F6F6] rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <Package className="w-4 h-4 text-[#E10715]" />
                <span className="text-sm font-medium text-[#000000]">
                  {language === 'ar' ? 'المواصفات' : 'Specifications'}
                </span>
              </div>
              <p className="text-sm text-[#000000]/60">{t(product.materialSpecs)}</p>
            </div>

            {/* Color Selector */}
            <div>
              <label className="block text-sm font-medium text-[#000000] mb-3">
                {language === 'ar' ? 'اللون:' : 'Color:'}{' '}
                <span className="text-[#000000]/60">{selectedColorData ? t(selectedColorData.name) : ''}</span>
              </label>
              <div className="flex gap-3">
                {product.colors.map((color) => (
                  <button
                    key={color.id}
                    onClick={() => setSelectedColor(color.id)}
                    className={cn(
                      'group relative w-12 h-12 rounded-full border-2 transition-all',
                      selectedColor === color.id
                        ? 'border-[#E10715] ring-2 ring-[#E10715]/30'
                        : 'border-transparent hover:scale-110'
                    )}
                    title={t(color.name)}
                  >
                    <span
                      className="absolute inset-1 rounded-full"
                      style={{ backgroundColor: color.hex }}
                    />
                    {selectedColor === color.id && (
                      <span className="absolute inset-0 flex items-center justify-center">
                        <span className="w-2 h-2 bg-white rounded-full shadow-sm" />
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Size Selector */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <label className="text-sm font-medium text-[#000000]">
                  {language === 'ar' ? 'المقاس:' : 'Size:'}{' '}
                  <span className="text-[#000000]/60">{selectedSize || (language === 'ar' ? 'اختر المقاس' : 'Select size')}</span>
                </label>
                <button
                  onClick={() => setIsSizeChartOpen(true)}
                  className="flex items-center gap-1.5 text-sm text-[#E10715] hover:text-[#C00612] transition-colors"
                >
                  <Ruler className="w-4 h-4" />
                  {language === 'ar' ? 'جدول المقاسات' : 'Size Chart'}
                </button>
              </div>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((size) => (
                  <button
                    key={size.id}
                    onClick={() => setSelectedSize(size.id)}
                    className={cn(
                      'px-4 py-2 text-sm font-medium rounded-lg transition-all',
                      selectedSize === size.id
                        ? 'bg-[#000000] text-white'
                        : 'bg-[#F6F6F6] text-[#000000]/70 hover:bg-[#000000]/10'
                    )}
                  >
                    {size.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3 pt-4 border-t border-[#000000]/10">
              <button
                onClick={() => setIsSampleModalOpen(true)}
                className="w-full flex items-center justify-center gap-3 px-6 py-4 bg-[#F6F6F6] text-[#000000] font-medium rounded-full hover:bg-[#000000]/10 transition-colors"
              >
                <TestTube className="w-5 h-5" />
                {language === 'ar' ? 'طلب عينة' : 'Request Sample'}
                <span className="text-xs text-[#000000]/50">({language === 'ar' ? '1-3 قطع' : '1-3 pcs'})</span>
              </button>

              <button
                onClick={() => setIsBulkModalOpen(true)}
                className="w-full flex items-center justify-center gap-3 px-6 py-4 bg-[#E10715] text-white font-medium rounded-full hover:bg-[#C00612] transition-colors"
              >
                <Users className="w-5 h-5" />
                {language === 'ar' ? 'إضافة للطلب بالجملة' : 'Add to Bulk Quote'}
                <span className="text-xs text-white/70">({language === 'ar' ? '50 قطعة كحد أدنى' : 'Min 50 pcs'})</span>
              </button>
            </div>

            {/* Back Link */}
            <Link
              to="/products"
              className="inline-flex items-center gap-2 text-[#000000]/50 hover:text-[#000000] transition-colors"
            >
              <ArrowLeft className={cn("w-4 h-4", dir === 'rtl' && "rotate-180")} />
              {language === 'ar' ? 'العودة للمنتجات' : 'Back to Products'}
            </Link>
          </div>
        </div>
      </div>

      {/* Size Chart Modal */}
      <Dialog open={isSizeChartOpen} onOpenChange={setIsSizeChartOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-[#000000]">
              {language === 'ar' ? 'جدول المقاسات' : 'Size Chart'}
            </DialogTitle>
          </DialogHeader>
          <div className="mt-4">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#000000]/10">
                  <th className="py-3 text-left font-medium text-[#000000]/50">
                    {language === 'ar' ? 'المقاس' : 'Size'}
                  </th>
                  <th className="py-3 text-left font-medium text-[#000000]/50">
                    {language === 'ar' ? 'الصدر' : 'Chest'}
                  </th>
                  <th className="py-3 text-left font-medium text-[#000000]/50">
                    {language === 'ar' ? 'الخصر' : 'Waist'}
                  </th>
                  <th className="py-3 text-left font-medium text-[#000000]/50">
                    {language === 'ar' ? 'الطول' : 'Length'}
                  </th>
                </tr>
              </thead>
              <tbody>
                {sizeChartData.map((row) => (
                  <tr key={row.size} className="border-b border-[#000000]/5">
                    <td className="py-3 font-medium text-[#000000]">{row.size}</td>
                    <td className="py-3 text-[#000000]/70">{row.chest}</td>
                    <td className="py-3 text-[#000000]/70">{row.waist}</td>
                    <td className="py-3 text-[#000000]/70">{row.length}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </DialogContent>
      </Dialog>

      {/* Sample Request Modal */}
      <SampleRequestModal
        isOpen={isSampleModalOpen}
        onClose={() => setIsSampleModalOpen(false)}
        product={product}
        selectedColor={selectedColor}
        selectedSize={selectedSize}
        onColorChange={setSelectedColor}
        onSizeChange={setSelectedSize}
      />

      {/* Bulk Quote Modal */}
      <BulkQuoteModal
        isOpen={isBulkModalOpen}
        onClose={() => setIsBulkModalOpen(false)}
        product={product}
        selectedColor={selectedColor}
        onColorChange={setSelectedColor}
      />

      {/* Floating Action Button */}
      {getTotalItems() > 0 && (
        <button
          onClick={() => navigate('/quote-cart')}
          className={cn(
            'fixed bottom-6 z-50 flex items-center gap-3 px-6 py-4 bg-[#E10715] text-white font-medium rounded-full shadow-lg hover:bg-[#C00612] transition-all hover:shadow-xl',
            dir === 'rtl' ? 'left-6' : 'right-6'
          )}
        >
          <ShoppingCart className="w-5 h-5" />
          <span>
            {language === 'ar'
              ? `عرض قائمة الطلب (${getTotalItems()})`
              : `View Quote List (${getTotalItems()})`}
          </span>
          <ArrowUpRight className={cn("w-4 h-4", dir === 'rtl' && "rotate-90")} />
        </button>
      )}
    </div>
  );
}

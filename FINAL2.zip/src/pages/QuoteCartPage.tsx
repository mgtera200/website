import { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import {
  ArrowLeft,
  Building2,
  Check,
  Download,
  Mail,
  MapPin,
  MessageSquare,
  Phone,
  Plus,
  ShoppingBag,
  Trash2,
  User,
  FileText,
} from 'lucide-react';  // FIXED: Removed ArrowRight and Package
import { useLanguage } from '@/context/LanguageContext';
import { useCart, type CartItem } from '@/context/CartContext';
import { cityOptions, whatsappConfig } from '@/config';  // FIXED: Removed productDetailsConfig
import { toast } from 'sonner';

interface FormData {
  companyName: string;
  contactName: string;
  phone: string;
  email: string;
  city: string;
  notes: string;
}

interface FormErrors {
  companyName?: string;
  contactName?: string;
  phone?: string;
  email?: string;
  city?: string;
}

export function QuoteCartPage() {
  const navigate = useNavigate();
  const { t, language, dir } = useLanguage();
  const { items, removeItem, getSampleItems, getBulkItems, clearCart, getTotalItems } = useCart();

  const [isVisible, setIsVisible] = useState(false);
  const [formData, setFormData] = useState<FormData>({
    companyName: '',
    contactName: '',
    phone: '',
    email: '',
    city: '',
    notes: '',
  });
  const [errors, setErrors] = useState<FormErrors>({});
  // FIXED: Removed unused isSubmitting state
  const [showSuccess, setShowSuccess] = useState(false);

  const pageRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const sampleItems = getSampleItems();
  const bulkItems = getBulkItems();

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {};

    if (!formData.companyName.trim()) {
      newErrors.companyName = language === 'ar' ? 'اسم الشركة مطلوب' : 'Company name is required';
    }
    if (!formData.contactName.trim()) {
      newErrors.contactName = language === 'ar' ? 'اسم جهة الاتصال مطلوب' : 'Contact name is required';
    }
    if (!formData.phone.trim()) {
      newErrors.phone = language === 'ar' ? 'رقم الهاتف مطلوب' : 'Phone number is required';
    }
    if (!formData.email.trim()) {
      newErrors.email = language === 'ar' ? 'البريد الإلكتروني مطلوب' : 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = language === 'ar' ? 'البريد الإلكتروني غير صالح' : 'Invalid email address';
    }
    if (!formData.city) {
      newErrors.city = language === 'ar' ? 'المدينة مطلوبة' : 'City is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    // Clear error when user starts typing
    if (errors[name as keyof FormErrors]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  const handleWhatsAppSubmit = () => {
    if (!validateForm()) {
      toast.error(language === 'ar' ? 'الرجاء ملء جميع الحقول المطلوبة' : 'Please fill in all required fields');
      return;
    }

    const samples = sampleItems.map((item) => ({
      productName: t(item.productName),
      color: t(item.colorLabel),
      size: item.size || '',
      quantity: item.quantity,
    }));

    const bulkItemsData = bulkItems.map((item) => ({
      productName: t(item.productName),
      color: t(item.colorLabel),
      sizes: item.sizes || {},
      total: item.quantity,
    }));

    const cityLabel = cityOptions.find((c) => c.value === formData.city);
    const cityName = cityLabel ? t({ en: cityLabel.en, ar: cityLabel.ar }) : formData.city;

    const message = whatsappConfig.getMessageTemplate(language, {
      companyName: formData.companyName,
      contactName: formData.contactName,
      phone: formData.phone,
      email: formData.email,
      city: cityName,
      samples,
      bulkItems: bulkItemsData,
      notes: formData.notes,
    });

    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/${whatsappConfig.phoneNumber}?text=${encodedMessage}`;

    window.open(whatsappUrl, '_blank');
    setShowSuccess(true);
  };

  const handlePDFDownload = () => {
    if (!validateForm()) {
      toast.error(language === 'ar' ? 'الرجاء ملء جميع الحقول المطلوبة' : 'Please fill in all required fields');
      return;
    }

    // Create PDF content
    const cityLabel = cityOptions.find((c) => c.value === formData.city);
    const cityName = cityLabel ? t({ en: cityLabel.en, ar: cityLabel.ar }) : formData.city;

    let pdfContent = `
      <html dir="${dir}">
      <head>
        <style>
          body { font-family: Arial, sans-serif; padding: 40px; color: #333; }
          h1 { color: #E10715; border-bottom: 2px solid #E10715; padding-bottom: 10px; }
          h2 { color: #111; margin-top: 30px; }
          .section { margin-bottom: 20px; }
          .label { font-weight: bold; color: #666; }
          .value { margin-bottom: 10px; }
          table { width: 100%; border-collapse: collapse; margin-top: 15px; }
          th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
          th { background-color: #f5f5f5; font-weight: bold; }
          .badge { display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: bold; }
          .badge-sample { background-color: #e3f2fd; color: #1976d2; }
          .badge-bulk { background-color: #e8f5e9; color: #388e3c; }
        </style>
      </head>
      <body>
        <h1>${language === 'ar' ? 'طلب عرض سعر - تيرا لليونيفورم' : 'Quote Request - TERA Uniforms'}</h1>
        
        <div class="section">
          <h2>${language === 'ar' ? 'معلومات الشركة' : 'Company Information'}</h2>
          <div><span class="label">${language === 'ar' ? 'الشركة:' : 'Company:'}</span> <span class="value">${formData.companyName}</span></div>
          <div><span class="label">${language === 'ar' ? 'جهة الاتصال:' : 'Contact:'}</span> <span class="value">${formData.contactName}</span></div>
          <div><span class="label">${language === 'ar' ? 'الهاتف:' : 'Phone:'}</span> <span class="value">${formData.phone}</span></div>
          <div><span class="label">${language === 'ar' ? 'البريد الإلكتروني:' : 'Email:'}</span> <span class="value">${formData.email}</span></div>
          <div><span class="label">${language === 'ar' ? 'المدينة:' : 'City:'}</span> <span class="value">${cityName}</span></div>
        </div>
    `;

    if (sampleItems.length > 0) {
      pdfContent += `
        <div class="section">
          <h2>${language === 'ar' ? 'عينات للتقييم' : 'Samples for Evaluation'}</h2>
          <table>
            <thead>
              <tr>
                <th>${language === 'ar' ? 'المنتج' : 'Product'}</th>
                <th>${language === 'ar' ? 'اللون' : 'Color'}</th>
                <th>${language === 'ar' ? 'المقاس' : 'Size'}</th>
                <th>${language === 'ar' ? 'الكمية' : 'Quantity'}</th>
              </tr>
            </thead>
            <tbody>
      `;
      sampleItems.forEach((item) => {
        pdfContent += `
          <tr>
            <td>${t(item.productName)}</td>
            <td>${t(item.colorLabel)}</td>
            <td>${item.size}</td>
            <td>${item.quantity}</td>
          </tr>
        `;
      });
      pdfContent += `</tbody></table></div>`;
    }

    if (bulkItems.length > 0) {
      pdfContent += `
        <div class="section">
          <h2>${language === 'ar' ? 'طلبية بالجملة' : 'Bulk Order Items'}</h2>
          <table>
            <thead>
              <tr>
                <th>${language === 'ar' ? 'المنتج' : 'Product'}</th>
                <th>${language === 'ar' ? 'اللون' : 'Color'}</th>
                <th>${language === 'ar' ? 'تفاصيل المقاسات' : 'Size Details'}</th>
                <th>${language === 'ar' ? 'الإجمالي' : 'Total'}</th>
              </tr>
            </thead>
            <tbody>
      `;
      bulkItems.forEach((item) => {
        const sizeDetails = item.sizes
          ? Object.entries(item.sizes)
              .filter(([, qty]) => qty > 0)
              .map(([size, qty]) => `${size}: ${qty}`)
              .join(', ')
          : '';
        pdfContent += `
          <tr>
            <td>${t(item.productName)}</td>
            <td>${t(item.colorLabel)}</td>
            <td>${sizeDetails}</td>
            <td>${item.quantity}</td>
          </tr>
        `;
      });
      pdfContent += `</tbody></table></div>`;
    }

    if (formData.notes) {
      pdfContent += `
        <div class="section">
          <h2>${language === 'ar' ? 'ملاحظات' : 'Notes'}</h2>
          <p>${formData.notes}</p>
        </div>
      `;
    }

    pdfContent += `
        <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #ddd; text-align: center; color: #666; font-size: 12px;">
          ${language === 'ar' ? 'تم إنشاء هذا الطلب من تيرا لليونيفورم' : 'Generated by TERA Uniforms'}
        </div>
      </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(pdfContent);
      printWindow.document.close();
      printWindow.print();
    }
  };

  if (showSuccess) {
    return (
      <div className="min-h-screen bg-white pt-24 lg:pt-32 pb-20">
        <div className="container-large px-5 lg:px-12">
          <div className="max-w-2xl mx-auto text-center">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Check className="w-10 h-10 text-green-600" />
            </div>
            <h1 className="text-3xl lg:text-4xl font-bold text-[#000000] mb-4">
              {language === 'ar' ? 'تم إرسال طلبك!' : 'Quote Request Submitted!'}
            </h1>
            <p className="text-[#000000]/60 mb-8">
              {language === 'ar'
                ? 'سنقوم بالتواصل معك قريباً مع عرض السعر والخطوات التالية.'
                : 'We will get back to you soon with a quote and next steps.'}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => {
                  clearCart();
                  navigate('/products');
                }}
                className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-[#E10715] text-white rounded-full hover:bg-[#C00612] transition-colors"
              >
                <ShoppingBag className="w-4 h-4" />
                {language === 'ar' ? 'تصفح المزيد من المنتجات' : 'Browse More Products'}
              </button>
              <Link
                to="/"
                className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-[#F6F6F6] text-[#000000] rounded-full hover:bg-[#000000]/10 transition-colors"
              >
                <ArrowLeft className={cn("w-4 h-4", dir === 'rtl' && "rotate-180")} />
                {language === 'ar' ? 'العودة إلى الصفحة الرئيسية' : 'Back to Home'}
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Empty State
  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-white pt-24 lg:pt-32 pb-20">
        <div className="container-large px-5 lg:px-12">
          <div
            className={cn(
              'max-w-xl mx-auto text-center transition-all duration-700',
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            )}
          >
            <div className="w-24 h-24 bg-[#F6F6F6] rounded-full flex items-center justify-center mx-auto mb-6">
              <ShoppingBag className="w-10 h-10 text-[#000000]/30" />
            </div>
            <h1 className="text-2xl lg:text-3xl font-bold text-[#000000] mb-4">
              {language === 'ar' ? 'قائمة الطلب فارغة' : 'Your Quote List is Empty'}
            </h1>
            <p className="text-[#000000]/60 mb-8">
              {language === 'ar'
                ? 'أضف منتجات إلى قائمة الطلب للحصول على عرض سعر مخصص.'
                : 'Add products to your quote list to get a custom price quote.'}
            </p>
            <Link
              to="/products"
              className="inline-flex items-center gap-2 px-6 py-3 bg-[#E10715] text-white rounded-full hover:bg-[#C00612] transition-colors"
            >
              <Plus className="w-4 h-4" />
              {language === 'ar' ? 'تصفح المنتجات' : 'Browse Products'}
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div ref={pageRef} className="min-h-screen bg-white pt-20 lg:pt-28 pb-20">
      <div className="container-large px-5 lg:px-12">
        {/* Back Link */}
        <Link
          to="/products"
          className={cn(
            'inline-flex items-center gap-2 text-[#000000]/60 hover:text-[#000000] transition-colors mb-6 transition-all duration-700',
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          )}
        >
          <ArrowLeft className={cn("w-4 h-4", dir === 'rtl' && "rotate-180")} />
          {language === 'ar' ? 'العودة للمنتجات' : 'Back to Products'}
        </Link>

        {/* Header */}
        <div
          className={cn(
            'mb-10 transition-all duration-700',
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          )}
          style={{ transitionDelay: '100ms' }}
        >
          <span className="text-xs font-geist-mono uppercase tracking-widest text-[#000000]/50">
            {language === 'ar' ? 'طلب عرض سعر' : 'Quote Request'}
          </span>
          <h1 className="text-3xl sm:text-4xl lg:text-[clamp(2.5rem,5vw,4rem)] font-black text-[#000000] mt-4 tracking-[-0.03em] leading-[1.1]">
            {language === 'ar' ? 'طلب عرض السعر الخاص بك' : 'Your Quote Request'}
          </h1>
          <p className="mt-4 text-base lg:text-lg text-[#000000]/60 max-w-xl">
            {language === 'ar'
              ? 'راجع عناصر طلبك وأكمل معلومات شركتك لإرسال الطلب.'
              : 'Review your request items and complete your company information to submit.'}
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 lg:gap-12">
          {/* Left Column - Items */}
          <div className="lg:col-span-2 space-y-8">
            {/* Sample Items Section */}
            {sampleItems.length > 0 && (
              <div
                className={cn(
                  'transition-all duration-700',
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
                )}
                style={{ transitionDelay: '200ms' }}
              >
                <div className="flex items-center gap-3 mb-4">
                  <span className="px-3 py-1 text-xs font-medium bg-blue-100 text-blue-700 rounded-full">
                    {language === 'ar' ? 'عينات' : 'Samples'}
                  </span>
                  <h2 className="text-lg font-semibold text-[#000000]">
                    {language === 'ar' ? 'عينات للتقييم' : 'Samples for Evaluation'}
                  </h2>
                </div>
                <div className="space-y-3">
                  {sampleItems.map((item) => (
                    <CartItemCard key={item.id} item={item} onRemove={removeItem} />
                  ))}
                </div>
              </div>
            )}

            {/* Bulk Items Section */}
            {bulkItems.length > 0 && (
              <div
                className={cn(
                  'transition-all duration-700',
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
                )}
                style={{ transitionDelay: '300ms' }}
              >
                <div className="flex items-center gap-3 mb-4">
                  <span className="px-3 py-1 text-xs font-medium bg-green-100 text-green-700 rounded-full">
                    {language === 'ar' ? 'بالجملة' : 'Bulk'}
                  </span>
                  <h2 className="text-lg font-semibold text-[#000000]">
                    {language === 'ar' ? 'طلبية بالجملة' : 'Bulk Order Items'}
                  </h2>
                </div>
                <div className="space-y-3">
                  {bulkItems.map((item) => (
                    <CartItemCard key={item.id} item={item} onRemove={removeItem} />
                  ))}
                </div>
              </div>
            )}

            {/* Total Items */}
            <div className="flex items-center justify-between p-4 bg-[#F6F6F6] rounded-xl">
              <span className="text-[#000000]/60">
                {language === 'ar' ? 'إجمالي العناصر:' : 'Total Items:'}
              </span>
              <span className="text-lg font-semibold text-[#000000]">{getTotalItems()}</span>
            </div>
          </div>

          {/* Right Column - Form */}
          <div
            className={cn(
              'transition-all duration-700',
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            )}
            style={{ transitionDelay: '400ms' }}
          >
            <div className="sticky top-28 space-y-6">
              <div className="p-6 bg-[#F6F6F6] rounded-2xl">
                <h2 className="text-lg font-semibold text-[#000000] mb-6">
                  {language === 'ar' ? 'معلومات الشركة' : 'Company Information'}
                </h2>

                <div className="space-y-4">
                  {/* Company Name */}
                  <div>
                    <label className="block text-sm font-medium text-[#000000] mb-2">
                      {language === 'ar' ? 'اسم الشركة *' : 'Company Name *'}
                    </label>
                    <div className="relative">
                      <Building2 className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#000000]/40" />
                      <input
                        type="text"
                        name="companyName"
                        value={formData.companyName}
                        onChange={handleInputChange}
                        className={cn(
                          'w-full pl-12 pr-4 py-3 bg-white border rounded-xl text-sm text-[#000000] placeholder:text-[#000000]/40 focus:outline-none focus:border-[#E10715] transition-colors',
                          errors.companyName ? 'border-red-500' : 'border-transparent'
                        )}
                        placeholder={language === 'ar' ? 'اسم شركتك' : 'Your company name'}
                      />
                    </div>
                    {errors.companyName && (
                      <p className="mt-1 text-xs text-red-500">{errors.companyName}</p>
                    )}
                  </div>

                  {/* Contact Name */}
                  <div>
                    <label className="block text-sm font-medium text-[#000000] mb-2">
                      {language === 'ar' ? 'اسم الشخص المسؤول *' : 'Contact Person *'}
                    </label>
                    <div className="relative">
                      <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#000000]/40" />
                      <input
                        type="text"
                        name="contactName"
                        value={formData.contactName}
                        onChange={handleInputChange}
                        className={cn(
                          'w-full pl-12 pr-4 py-3 bg-white border rounded-xl text-sm text-[#000000] placeholder:text-[#000000]/40 focus:outline-none focus:border-[#E10715] transition-colors',
                          errors.contactName ? 'border-red-500' : 'border-transparent'
                        )}
                        placeholder={language === 'ar' ? 'الاسم الكامل' : 'Full name'}
                      />
                    </div>
                    {errors.contactName && (
                      <p className="mt-1 text-xs text-red-500">{errors.contactName}</p>
                    )}
                  </div>

                  {/* Phone */}
                  <div>
                    <label className="block text-sm font-medium text-[#000000] mb-2">
                      {language === 'ar' ? 'رقم الجوال *' : 'Phone Number *'}
                    </label>
                    <div className="relative">
                      <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#000000]/40" />
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        className={cn(
                          'w-full pl-12 pr-4 py-3 bg-white border rounded-xl text-sm text-[#000000] placeholder:text-[#000000]/40 focus:outline-none focus:border-[#E10715] transition-colors',
                          errors.phone ? 'border-red-500' : 'border-transparent'
                        )}
                        placeholder={language === 'ar' ? '+966 50 000 0000' : '+966 50 000 0000'}
                      />
                    </div>
                    {errors.phone && <p className="mt-1 text-xs text-red-500">{errors.phone}</p>}
                  </div>

                  {/* Email */}
                  <div>
                    <label className="block text-sm font-medium text-[#000000] mb-2">
                      {language === 'ar' ? 'البريد الإلكتروني *' : 'Email *'}
                    </label>
                    <div className="relative">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#000000]/40" />
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className={cn(
                          'w-full pl-12 pr-4 py-3 bg-white border rounded-xl text-sm text-[#000000] placeholder:text-[#000000]/40 focus:outline-none focus:border-[#E10715] transition-colors',
                          errors.email ? 'border-red-500' : 'border-transparent'
                        )}
                        placeholder={language === 'ar' ? 'your@email.com' : 'your@email.com'}
                      />
                    </div>
                    {errors.email && <p className="mt-1 text-xs text-red-500">{errors.email}</p>}
                  </div>

                  {/* City */}
                  <div>
                    <label className="block text-sm font-medium text-[#000000] mb-2">
                      {language === 'ar' ? 'المدينة *' : 'City *'}
                    </label>
                    <div className="relative">
                      <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#000000]/40" />
                      <select
                        name="city"
                        value={formData.city}
                        onChange={handleInputChange}
                        className={cn(
                          'w-full pl-12 pr-4 py-3 bg-white border rounded-xl text-sm text-[#000000] focus:outline-none focus:border-[#E10715] transition-colors appearance-none cursor-pointer',
                          errors.city ? 'border-red-500' : 'border-transparent'
                        )}
                      >
                        <option value="">
                          {language === 'ar' ? 'اختر المدينة' : 'Select City'}
                        </option>
                        {cityOptions.map((city) => (
                          <option key={city.value} value={city.value}>
                            {t({ en: city.en, ar: city.ar })}
                          </option>
                        ))}
                      </select>
                    </div>
                    {errors.city && <p className="mt-1 text-xs text-red-500">{errors.city}</p>}
                  </div>

                  {/* Notes */}
                  <div>
                    <label className="block text-sm font-medium text-[#000000] mb-2">
                      {language === 'ar' ? 'ملاحظات' : 'Notes'}
                    </label>
                    <div className="relative">
                      <FileText className="absolute left-4 top-4 w-5 h-5 text-[#000000]/40" />
                      <textarea
                        name="notes"
                        value={formData.notes}
                        onChange={handleInputChange}
                        rows={3}
                        className="w-full pl-12 pr-4 py-3 bg-white border border-transparent rounded-xl text-sm text-[#000000] placeholder:text-[#000000]/40 focus:outline-none focus:border-[#E10715] transition-colors resize-none"
                        placeholder={
                          language === 'ar'
                            ? 'أي متطلبات خاصة...'
                            : 'Any special requirements...'
                        }
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-3">
                <button
                  onClick={handleWhatsAppSubmit}
                  className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-green-600 text-white font-medium rounded-full hover:bg-green-700 transition-colors"
                >
                  <MessageSquare className="w-5 h-5" />
                  {language === 'ar' ? 'إرسال عبر واتساب' : 'Send via WhatsApp'}
                </button>

                <button
                  onClick={handlePDFDownload}
                  className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-[#F6F6F6] text-[#000000] font-medium rounded-full hover:bg-[#000000]/10 transition-colors"
                >
                  <Download className="w-5 h-5" />
                  {language === 'ar' ? 'تحميل PDF' : 'Download PDF'}
                </button>

                <Link
                  to="/products"
                  className="w-full flex items-center justify-center gap-2 px-6 py-4 border border-[#000000]/20 text-[#000000] font-medium rounded-full hover:bg-[#000000]/5 transition-colors"
                >
                  <Plus className="w-5 h-5" />
                  {language === 'ar' ? 'إضافة منتجات أخرى' : 'Add More Products'}
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Cart Item Card Component
interface CartItemCardProps {
  item: CartItem;
  onRemove: (id: string) => void;
}

function CartItemCard({ item, onRemove }: CartItemCardProps) {
  const { t, language } = useLanguage();  // FIXED: Removed unused dir

  const sizeDetails = item.sizes
    ? Object.entries(item.sizes)
        .filter(([, qty]) => qty > 0)
        .map(([size, qty]) => `${size}: ${qty}`)
        .join(', ')
    : null;

  return (
    <div className="flex gap-4 p-4 bg-white border border-[#000000]/10 rounded-xl">
      <img
        src={item.productImage}
        alt={t(item.productName)}
        className="w-20 h-20 object-cover rounded-lg flex-shrink-0"
        onError={(e) => {
          (e.target as HTMLImageElement).src = '/images/placeholder-product.jpg';
        }}
      />

      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-2">
          <div>
            <h3 className="font-medium text-[#000000] truncate">{t(item.productName)}</h3>
            <p className="text-sm text-[#000000]/50">{item.sku}</p>
          </div>
          <button
            onClick={() => onRemove(item.id)}
            className="p-2 text-[#000000]/40 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>

        <div className="mt-2 flex flex-wrap items-center gap-2">
          <span
            className={cn(
              'px-2 py-0.5 text-xs font-medium rounded-full',
              item.type === 'SAMPLE'
                ? 'bg-blue-100 text-blue-700'
                : 'bg-green-100 text-green-700'
            )}
          >
            {item.type === 'SAMPLE'
              ? language === 'ar'
                ? 'عينة'
                : 'Sample'
              : language === 'ar'
                ? 'بالجملة'
                : 'Bulk'}
          </span>

          <span className="text-sm text-[#000000]/60">
            {language === 'ar' ? 'اللون:' : 'Color:'} {t(item.colorLabel)}
          </span>

          {item.size && (
            <span className="text-sm text-[#000000]/60">
              {language === 'ar' ? 'المقاس:' : 'Size:'} {item.size}
            </span>
          )}
        </div>

        {sizeDetails && (
          <p className="mt-1 text-sm text-[#000000]/60">{sizeDetails}</p>
        )}

        <p className="mt-2 text-sm font-medium text-[#000000]">
          {language === 'ar' ? 'الكمية:' : 'Qty:'} {item.quantity}
        </p>
      </div>
    </div>
  );
}

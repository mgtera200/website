import { useEffect, useState, useRef, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { heroConfig } from '@/config';
import { ArrowRight } from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';

// Logo dimensions - scaled from SVG viewBox 1280x769
const logoScale = 0.55;
const logoWidth = 1280 * logoScale;
const logoHeight = 769 * logoScale;
const halfLogoWidth = logoWidth / 2;
const halfLogoHeight = logoHeight / 2;

// TERA logo paths (relative to viewBox 0,0)
const logoPaths = [
  "M686.45,127.06v326.75h0c-42.68-9.23-95.17-34.03-95.17-112.19v-100.94c0-66.19,42.61-113.63,95.17-113.63h0Z",
  "M352.2,127.06h285.8s-57.1,35.18-57.1,94.88h-126.03c-62.01,0-102.67-54.51-102.67-94.88h0Z",
  "M927.8,127.06h0c0,40.38-40.66,94.88-102.67,94.88h-127v-94.88h229.67Z",
  "M473.32,240.69h0c0,55.75,45.19,100.94,100.94,100.94h6.63v-100.94h-107.57Z",
];

export function Hero() {
  const { t, language, dir } = useLanguage();
  const config = heroConfig;
  
  const [isLoaded, setIsLoaded] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [smoothMousePos, setSmoothMousePos] = useState({ x: 0, y: 0 });
  const sectionRef = useRef<HTMLElement>(null);
  const rafRef = useRef<number | undefined>(undefined);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoaded(true);
    }, 300);
    
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 1024);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    return () => {
      clearTimeout(timer);
      window.removeEventListener('resize', checkMobile);
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, []);

  // Smooth animation loop for mouse position
  useEffect(() => {
    const animate = () => {
      setSmoothMousePos(prev => ({
        x: prev.x + (mousePos.x - prev.x) * 0.15,
        y: prev.y + (mousePos.y - prev.y) * 0.15
      }));
      rafRef.current = requestAnimationFrame(animate);
    };
    
    if (!isMobile) {
      rafRef.current = requestAnimationFrame(animate);
    }
    
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [mousePos, isMobile]);

  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLElement>) => {
    if (isMobile) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    setMousePos({ x, y });
  }, [isMobile]);

  // Calculate logo position (top-left corner of bounding box)
  const logoX = smoothMousePos.x - halfLogoWidth;
  const logoY = smoothMousePos.y - halfLogoHeight;

  return (
    <section
      ref={sectionRef}
      id="hero"
      className="relative w-full min-h-screen overflow-hidden bg-neutral-900 lg:cursor-none"
      onMouseMove={handleMouseMove}
      dir={dir}
    >
      {/* SHARP Background Image (Full Quality) */}
      <div
        className={cn(
          'absolute inset-0 z-0 transition-opacity duration-700',
          isLoaded && imageLoaded ? 'opacity-100' : 'opacity-0'
        )}
      >
        <img
          src={config.backgroundImage}
          alt=""
          className="w-full h-full object-cover"
          onLoad={() => setImageLoaded(true)}
        />
      </div>

      {/* BLURRED Overlay with Logo-shaped Window (Desktop Only) */}
      {!isMobile && (
        <div
          className={cn(
            'absolute inset-0 z-10 pointer-events-none hidden lg:block transition-opacity duration-700',
            isLoaded && imageLoaded ? 'opacity-100' : 'opacity-0'
          )}
        >
          {/* Full blurred overlay */}
          <div 
            className="absolute inset-0"
            style={{
              backgroundImage: `url(${config.backgroundImage})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              filter: 'blur(12px) brightness(0.7)',
            }}
          />
          
          {/* Logo-shaped sharp window */}
          <div
            className="absolute"
            style={{
              left: logoX,
              top: logoY,
              width: logoWidth,
              height: logoHeight,
              willChange: 'left, top',
            }}
          >
            {/* Inner container with clip-path */}
            <div
              className="absolute inset-0"
              style={{
                clipPath: `path('${logoPaths.join(' ')}')`,
              }}
            >
              {/* Sharp image - positioned to align with background */}
              <div
                className="absolute"
                style={{
                  left: -logoX,
                  top: -logoY,
                  width: '100vw',
                  height: '100vh',
                  backgroundImage: `url(${config.backgroundImage})`,
                  backgroundSize: 'cover',
                  backgroundPosition: 'center',
                }}
              />
            </div>
          </div>
        </div>
      )}

      {/* DESKTOP LAYOUT */}
      <div className="hidden lg:block relative z-30 h-screen">
        {/* Left Headline with Animated Subheading */}
        <div
          className={cn(
            'absolute left-[6vw] top-[14vh] transition-all duration-1000 ease-out',
            isLoaded ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-12'
          )}
          style={{ transitionDelay: '400ms' }}
        >
          <h1 
            className="text-[clamp(2.5rem,4.5vw,4.5rem)] font-black text-white tracking-[-0.02em] leading-[1.1]"
            style={{ direction: 'ltr' }}
          >
            {language === 'ar' ? 'تصميم الزي الحديث' : 'MODERN UNIFORM DESIGN'}
          </h1>
          
          <div className="mt-4 overflow-hidden">
            <p 
              className={cn(
                'text-2xl lg:text-3xl text-white/90 font-light tracking-wider',
                'transition-all duration-700 ease-out'
              )}
              style={{ 
                transitionDelay: '800ms',
                animation: isLoaded ? 'slideUpFade 1s ease-out 0.8s both' : 'none'
              }}
            >
              <span className="inline-block">
                {language === 'ar' ? 'تصميم. جودة. هوية.' : 'Design. Quality. Identity.'}
              </span>
            </p>
          </div>
        </div>

        {/* Bottom-left microcopy */}
        <div
          className={cn(
            'absolute left-[6vw] bottom-[12vh] max-w-[28vw] transition-all duration-1000 ease-out',
            isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          )}
          style={{ transitionDelay: '600ms' }}
        >
          <p className="text-sm text-white/70 leading-relaxed mb-4">
            {t(config.microcopy.text)}
          </p>
          <div className="flex items-center gap-3">
            <div className="w-8 h-1 bg-[#E10715]" />
            <span className="text-xs font-geist-mono uppercase tracking-widest text-[#E10715]">
              {t(config.microcopy.badge)}
            </span>
          </div>
        </div>

        {/* Right Floating Card */}
        <div
          className={cn(
            'absolute right-[6vw] top-[14vh] w-[28vw] max-w-[360px] transition-all duration-1000 ease-out',
            isLoaded ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-12'
          )}
          style={{ transitionDelay: '700ms' }}
        >
          <div className="bg-[#FFFFFF] rounded-[24px] p-5 shadow-2xl">
            <span className="text-xs font-geist-mono uppercase tracking-widest text-[#000000]/50">
              {t(config.featuredProduct.label)}
            </span>

            <div className="mt-3 aspect-[3/4] rounded-xl overflow-hidden bg-neutral-200">
              <img
                src={config.featuredProduct.image}
                alt={t(config.featuredProduct.name)}
                className="w-full h-full object-cover"
              />
            </div>

            <h3 className="mt-3 text-base font-semibold text-[#000000]">
              {t(config.featuredProduct.name)}
            </h3>

            <Link 
              to="/product/studio-coat-charcoal" 
              className="mt-3 w-full py-2.5 px-5 bg-[#E10715] text-white rounded-full text-sm font-medium flex items-center justify-center gap-2 hover:bg-[#C00612] transition-colors"
            >
              {t(config.featuredProduct.cta)}
              <ArrowRight className={cn("w-4 h-4", dir === 'rtl' && "rotate-180")} />
            </Link>
          </div>
        </div>
      </div>

      {/* MOBILE LAYOUT - Fixed image visibility */}
      <div className="lg:hidden relative z-30 min-h-screen flex flex-col px-5 pt-24 pb-8">
        {/* Header Content */}
        <div className="flex-shrink-0 mb-4">
          <div
            className={cn(
              'transition-all duration-1000 ease-out',
              isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            )}
            style={{ transitionDelay: '400ms' }}
          >
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-[-0.02em] leading-[1.1]">
              {language === 'ar' ? 'تصميم الزي الحديث' : 'MODERN UNIFORM DESIGN'}
            </h1>
            <p 
              className="mt-3 text-xl text-white/90 font-light tracking-wide"
              style={{ animation: isLoaded ? 'slideUpFade 1s ease-out 0.6s both' : 'none' }}
            >
              {language === 'ar' ? 'تصميم. جودة. هوية.' : 'Design. Quality. Identity.'}
            </p>
          </div>

          <div
            className={cn(
              'mt-4 transition-all duration-1000 ease-out',
              isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            )}
            style={{ transitionDelay: '500ms' }}
          >
            <p className="text-sm text-white/70 leading-relaxed mb-2">
              {t(config.microcopy.text)}
            </p>
            <div className="flex items-center gap-3">
              <div className="w-6 h-1 bg-[#E10715]" />
              <span className="text-xs font-geist-mono uppercase tracking-widest text-[#E10715]">
                {t(config.microcopy.badge)}
              </span>
            </div>
          </div>
        </div>

        {/* Card - fills remaining space with visible image */}
        <div
          className={cn(
            'flex-1 min-h-0 transition-all duration-1000 ease-out',
            isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          )}
          style={{ transitionDelay: '600ms' }}
        >
          <div className="bg-[#FFFFFF] rounded-[20px] p-4 shadow-2xl h-full flex flex-col max-w-sm mx-auto">
            <span className="text-xs font-geist-mono uppercase tracking-widest text-[#000000]/50 mb-2">
              {t(config.featuredProduct.label)}
            </span>

            {/* Image container with explicit height */}
            <div className="flex-1 min-h-[200px] rounded-lg overflow-hidden bg-neutral-200 mb-3">
              <img
                src={config.featuredProduct.image}
                alt={t(config.featuredProduct.name)}
                className="w-full h-full object-cover"
              />
            </div>

            <h3 className="text-sm font-semibold text-[#000000] mb-3">
              {t(config.featuredProduct.name)}
            </h3>

            <Link 
              to="/product/studio-coat-charcoal" 
              className="w-full py-2.5 px-4 bg-[#E10715] text-white rounded-full text-sm font-medium flex items-center justify-center gap-2 hover:bg-[#C00612] transition-colors"
            >
              {t(config.featuredProduct.cta)}
              <ArrowRight className={cn("w-4 h-4", dir === 'rtl' && "rotate-180")} />
            </Link>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes slideUpFade {
          0% {
            opacity: 0;
            transform: translateY(20px);
          }
          100% {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </section>
  );
}

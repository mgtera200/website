import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { LanguageProvider } from '@/context/LanguageContext';
import { CartProvider } from '@/context/CartContext';
import { Navigation } from '@/components/layout/Navigation';
import { HomePage } from '@/pages/HomePage';
import { ShopPage } from '@/pages/ShopPage';
import { ProductDetailPage } from '@/pages/ProductDetailPage';  // FIXED: Use named import
import { QuoteCartPage } from '@/pages/QuoteCartPage';
import { Footer } from '@/sections/Footer';
import { SmoothScroll } from '@/components/SmoothScroll';
import { Toaster } from 'sonner';
import './App.css';

function App() {
  return (
    <LanguageProvider>
      <CartProvider>
        <Router>
          <SmoothScroll>
            <div className="min-h-screen bg-white">
              <Navigation />
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/products" element={<ShopPage />} />
                <Route path="/product/:id" element={<ProductDetailPage />} />
                <Route path="/quote-cart" element={<QuoteCartPage />} />
                {/* Redirect old routes */}
                <Route path="/shop" element={<Navigate to="/products" replace />} />
                <Route path="/shop/:productId" element={<Navigate to="/products" replace />} />
                <Route path="/quote" element={<Navigate to="/quote-cart" replace />} />
              </Routes>
              <Footer />
              <Toaster 
                position="bottom-right"
                toastOptions={{
                  style: {
                    background: '#111111',
                    color: '#ffffff',
                    border: 'none',
                  },
                }}
              />
            </div>
          </SmoothScroll>
        </Router>
      </CartProvider>
    </LanguageProvider>
  );
}

export default App;

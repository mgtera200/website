// Bilingual Site Configuration
// TERA Uniforms - Professional Workwear Solutions

export type Language = 'en' | 'ar';

export interface SiteConfig {
  languages: Language[];
  defaultLanguage: Language;
  title: Record<Language, string>;
  description: Record<Language, string>;
}

export const siteConfig: SiteConfig = {
  languages: ['en', 'ar'],
  defaultLanguage: 'en',
  title: {
    en: "TERA Uniforms | Modern Uniform Design",
    ar: "تيرا للزي الموحد | تصميم الزي الحديث"
  },
  description: {
    en: "Custom workwear systems for teams that care about fit, function, and identity. Professional uniforms for corporate, hospitality, medical, and industrial sectors.",
    ar: "أنظمة ملابس العمل المخصصة للفرق التي تهتم بالملاءمة والوظيفة والهوية. زي موحد احترافي للقطاعات المؤسسية والضيافة والطبية والصناعية."
  },
};

// Navigation configuration
export interface NavLink {
  label: Record<Language, string>;
  href: string;
}

export interface NavigationConfig {
  logo: string;
  links: NavLink[];
  contactLabel: Record<Language, string>;
  contactHref: string;
  loginLabel: Record<Language, string>;
  registerLabel: Record<Language, string>;
}

export const navigationConfig: NavigationConfig = {
  logo: "/images/logo.png",
  links: [
    { label: { en: "Work", ar: "أعمالنا" }, href: "#portfolio" },
    { label: { en: "Services", ar: "خدماتنا" }, href: "#services" },
    { label: { en: "Studio", ar: "الاستوديو" }, href: "#about" },
    { label: { en: "Contact", ar: "اتصل بنا" }, href: "#contact" },
  ],
  contactLabel: {
    en: "Request a Quote",
    ar: "اطلب عرض سعر"
  },
  contactHref: "/quote",
  loginLabel: {
    en: "Login",
    ar: "تسجيل الدخول"
  },
  registerLabel: {
    en: "Register",
    ar: "التسجيل"
  },
};

// Hero section configuration
export interface HeroConfig {
  name: Record<Language, string>;
  roles: Record<Language, string[]>;
  backgroundImage: string;
  featuredProduct: {
    label: Record<Language, string>;
    name: Record<Language, string>;
    image: string;
    cta: Record<Language, string>;
  };
  microcopy: {
    text: Record<Language, string>;
    badge: Record<Language, string>;
  };
}

export const heroConfig: HeroConfig = {
  name: {
    en: "MODERN / UNIFORM / DESIGN",
    ar: "تصميم / الزي / الحديث"
  },
  roles: {
    en: ["Design", "Sampling", "Production"],
    ar: ["تصميم", "عينات", "إنتاج"]
  },
  backgroundImage: "/images/custom.png",
  featuredProduct: {
    label: {
      en: "FEATURED UNIFORM",
      ar: "الزي المميز"
    },
    name: {
      en: "TERA Studio Coat — Charcoal",
      ar: "معطف تيرا الاستوديو — رمادي"
    },
    image: "/images/custom2.png",
    cta: {
      en: "Shop the coat",
      ar: "تسوق المعطف"
    },
  },
  microcopy: {
    text: {
      en: "Custom workwear systems for teams that care about fit, function, and identity.",
      ar: "أنظمة ملابس العمل المخصصة للفرق التي تهتم بالملاءمة والوظيفة والهوية."
    },
    badge: {
      en: "NEW SEASON DROP",
      ar: "تشكيلة الموسم الجديد"
    },
  },
};

// About section configuration
export interface AboutStat {
  value: string;
  label: Record<Language, string>;
}

export interface AboutImage {
  src: string;
  alt: Record<Language, string>;
}

export interface AboutConfig {
  label: Record<Language, string>;
  description: Record<Language, string>;
  experienceValue: string;
  experienceLabel: Record<Language, string>;
  stats: AboutStat[];
  images: AboutImage[];
}

export const aboutConfig: AboutConfig = {
  label: {
    en: "About",
    ar: "من نحن"
  },
  description: {
    en: "TERA is a uniform studio that treats workwear like product design—fit-first, brand-consistent, and made to last. We partner with operations and brand teams to roll out uniforms that people actually want to wear.",
    ar: "تيرا هو استوديو للزي الموحد يعامل ملابس العمل مثل تصميم المنتجات—الملاءمة أولاً، والاتساق مع العلامة التجارية، والمتانة. نتعاون مع فرق العمليات والعلامات التجارية لتقديم أزياء يرغب الناس فعلاً في ارتدائها."
  },
  experienceValue: "12+",
  experienceLabel: {
    en: "Years of\nExperience",
    ar: "سنوات\nمن الخبرة"
  },
  stats: [
    { value: "180+", label: { en: "Clients", ar: "عميل" } },
    { value: "24–48h", label: { en: "Sample turnaround", ar: " turnaround العينات" } },
  ],
  images: [
    { src: "/images/studio-portrait.jpg", alt: { en: "TERA Studio", ar: "استوديو تيرا" } },
  ],
};

// Services section configuration
export interface ServiceItem {
  iconName: string;
  title: Record<Language, string>;
  description: Record<Language, string>;
  image: string;
}

export interface ServicesConfig {
  label: Record<Language, string>;
  heading: Record<Language, string>;
  services: ServiceItem[];
  backgroundImage: string;
}

export const servicesConfig: ServicesConfig = {
  label: {
    en: "Services",
    ar: "خدماتنا"
  },
  heading: {
    en: "DESIGN / SAMPLING / PRODUCTION",
    ar: "تصميم / عينات / إنتاج"
  },
  backgroundImage: "/images/capabilities-bg.jpg",
  services: [
    {
      iconName: "Palette",
      title: {
        en: "Design & Branding",
        ar: "التصميم والعلامة التجارية"
      },
      description: {
        en: "We translate your identity into silhouettes, color systems, and wearable guidelines.",
        ar: "نترجم هويتك إلى أشكال ونظم ألوان ومبادئ قابلة للارتداء."
      },
      image: "/images/portfolio-01.jpg",
    },
    {
      iconName: "Scissors",
      title: {
        en: "Sampling & Fitting",
        ar: "العينات والملاءمة"
      },
      description: {
        en: "Sizes, adjustments, and wear-tests—so the final uniform feels made for your team.",
        ar: "المقاسات والتعديلات واختبارات الارتداء—لجعل الزي النهائي مناسباً لفريقك."
      },
      image: "/images/portfolio-02.jpg",
    },
    {
      iconName: "Factory",
      title: {
        en: "Manufacturing",
        ar: "التصنيع"
      },
      description: {
        en: "Reliable batches, consistent quality, and delivery that matches your rollout schedule.",
        ar: "دفعات موثوقة، وجودة متسقة، وتسليل يتناسب مع جدول طرحك."
      },
      image: "/images/portfolio-03.jpg",
    },
  ],
};

// Process section configuration
export interface ProcessStep {
  number: string;
  title: Record<Language, string>;
  description: Record<Language, string>;
}

export interface ProcessConfig {
  label: Record<Language, string>;
  heading: Record<Language, string>;
  steps: ProcessStep[];
  backgroundImage: string;
}

export const processConfig: ProcessConfig = {
  label: {
    en: "Process",
    ar: "العملية"
  },
  heading: {
    en: "OUR / PROCESS",
    ar: "عمليتنا"
  },
  backgroundImage: "/images/process-bg.jpg",
  steps: [
    {
      number: "01",
      title: {
        en: "Discovery",
        ar: "الاكتشاف"
      },
      description: {
        en: "We audit your environment, roles, and brand rules.",
        ar: "نقوم بتدقيق بيئتك وأدوارك وقواعد علامتك التجارية."
      },
    },
    {
      number: "02",
      title: {
        en: "Design",
        ar: "التصميم"
      },
      description: {
        en: "Moodboards, materials, and first silhouettes.",
        ar: "لوحات المزاج والمواد والأشكال الأولى."
      },
    },
    {
      number: "03",
      title: {
        en: "Sampling",
        ar: "العينات"
      },
      description: {
        en: "Fittings, feedback, and final refinements.",
        ar: "القياسات والملاحظات والتعديلات النهائية."
      },
    },
    {
      number: "04",
      title: {
        en: "Delivery",
        ar: "التسليم"
      },
      description: {
        en: "Batch production and rollout support.",
        ar: "الإنتاج بالدفعات ودعم الإطلاق."
      },
    },
  ],
};

// Products section configuration
export interface ProductItem {
  id: string;
  name: Record<Language, string>;
  variant: Record<Language, string>;
  price: number;
  category: Record<Language, string>;
  image: string;
  featured?: boolean;
  description: Record<Language, string>;
}

export interface ProductsConfig {
  label: Record<Language, string>;
  heading: Record<Language, string>;
  description: Record<Language, string>;
  products: ProductItem[];
  viewAllLabel: Record<Language, string>;
  shopNowLabel: Record<Language, string>;
}

export const productsConfig: ProductsConfig = {
  label: {
    en: "Products",
    ar: "المنتجات"
  },
  heading: {
    en: "OUR / PRODUCTS",
    ar: "منتجاتنا"
  },
  description: {
    en: "Premium workwear designed for teams that care about fit, function, and identity.",
    ar: "ملابس عمل متميزة مصممة للفرق التي تهتم بالملاءمة والوظيفة والهوية."
  },
  viewAllLabel: {
    en: "View All Products",
    ar: "عرض جميع المنتجات"
  },
  shopNowLabel: {
    en: "Shop Now",
    ar: "تسوق الآن"
  },
  products: [
    {
      id: 'studio-coat-charcoal',
      name: {
        en: 'TERA Studio Coat',
        ar: 'معطف تيرا الاستوديو'
      },
      variant: {
        en: 'Charcoal',
        ar: 'رمادي'
      },
      price: 189,
      category: {
        en: 'Studio Uniforms',
        ar: 'أزياء الاستوديو'
      },
      image: '/images/featured-coat.jpg',
      featured: true,
      description: {
        en: 'Premium tailored work coat designed for creative professionals.',
        ar: 'معطف عمل أنيق متميز مصمم للمحترفين الإبداعيين.'
      },
    },
    {
      id: 'hospitality-apron',
      name: {
        en: 'Hospitality Apron',
        ar: 'مريلة الضيافة'
      },
      variant: {
        en: 'Charcoal Gray',
        ar: 'رمادي فاتح'
      },
      price: 79,
      category: {
        en: 'Hospitality',
        ar: 'الضيافة'
      },
      image: '/images/portfolio-01.jpg',
      featured: false,
      description: {
        en: 'Elegant apron with premium leather straps for hospitality teams.',
        ar: 'مريلة أنيقة بحزام جلدي متميز لفرق الضيافة.'
      },
    },
    {
      id: 'medical-scrubs-navy',
      name: {
        en: 'Medical Scrubs Set',
        ar: 'طقم الملابس الطبية'
      },
      variant: {
        en: 'Navy Blue',
        ar: 'كحلي'
      },
      price: 129,
      category: {
        en: 'Medical',
        ar: 'الطبية'
      },
      image: '/images/portfolio-02.jpg',
      featured: false,
      description: {
        en: 'Comfortable and durable scrubs for healthcare professionals.',
        ar: 'ملابس طبية مريحة ومتينة لمحترفي الرعاية الصحية.'
      },
    },
    {
      id: 'field-jacket',
      name: {
        en: 'Field Workwear Jacket',
        ar: 'جاكيت ملابس العمل الميداني'
      },
      variant: {
        en: 'Charcoal',
        ar: 'رمادي'
      },
      price: 249,
      category: {
        en: 'Industrial',
        ar: 'الصناعية'
      },
      image: '/images/portfolio-03.jpg',
      featured: false,
      description: {
        en: 'Heavy-duty jacket with reinforced pockets for field work.',
        ar: 'جاكيت قوي بجيوب معززة للعمل الميداني.'
      },
    },
    {
      id: 'service-polo-set',
      name: {
        en: 'Service Kit',
        ar: 'طقم الخدمة'
      },
      variant: {
        en: 'Charcoal Gray',
        ar: 'رمادي فاتح'
      },
      price: 149,
      category: {
        en: 'Hospitality',
        ar: 'الضيافة'
      },
      image: '/images/portfolio-05.jpg',
      featured: false,
      description: {
        en: 'Professional polo and trousers set for service staff.',
        ar: 'طقم بولو وبنطلون احترافي لموظفي الخدمة.'
      },
    },
  ],
};

// Portfolio section configuration
export interface PortfolioCTA {
  label: Record<Language, string>;
  heading: Record<Language, string>;
  linkText: Record<Language, string>;
  linkHref: string;
}

export interface PortfolioConfig {
  label: Record<Language, string>;
  heading: Record<Language, string>;
  description: Record<Language, string>;
  cta: PortfolioCTA;
  viewAllLabel: Record<Language, string>;
}

export const portfolioConfig: PortfolioConfig = {
  label: {
    en: "Portfolio",
    ar: "أعمالنا"
  },
  heading: {
    en: "SELECTED / WORK",
    ar: "أعمالنا / المختارة"
  },
  description: {
    en: "A curated selection of uniform systems we've designed and produced for teams across industries.",
    ar: "مجموعة مختارة من أنظمة الزي الموحد التي صممناها وأنتجناها لفرق عبر الصناعات."
  },
  cta: {
    label: {
      en: "Have a project in mind?",
      ar: "هل لديك مشروع في بالك؟"
    },
    heading: {
      en: "Let's create your perfect uniform system",
      ar: "لننشئ نظام الزي الموحد المثالي لك"
    },
    linkText: {
      en: "Start a conversation",
      ar: "ابدأ محادثة"
    },
    linkHref: "#contact",
  },
  viewAllLabel: {
    en: "View All Projects",
    ar: "عرض جميع المشاريع"
  },
};

// Detail/Craft section configuration
export interface DetailConfig {
  label: Record<Language, string>;
  heading: Record<Language, string>;
  card: {
    label: Record<Language, string>;
    paragraph: Record<Language, string>;
    bullets: Record<Language, string[]>;
    cta: Record<Language, string>;
  };
  backgroundImage: string;
}

export const detailConfig: DetailConfig = {
  label: {
    en: "Materials",
    ar: "المواد"
  },
  heading: {
    en: "DETAIL / THAT LASTS",
    ar: "التفاصيل / التي تدوم"
  },
  backgroundImage: "/images/detail-bg.jpg",
  card: {
    label: {
      en: "MATERIALS & FINISH",
      ar: "المواد والتشطيب"
    },
    paragraph: {
      en: "We choose fabrics for real-world punishment—industrial laundering, daily movement, and weather.",
      ar: "نختار الأقمشة لتحمل الاستخدام الواقعي—الغسيل الصناعي، الحركة اليومية، والطقس."
    },
    bullets: {
      en: [
        "Reinforced stress points",
        "Color-fast dyes",
        "Moisture-wicking options",
        "Sustainable alternatives available",
      ],
      ar: [
        "نقاط ضغط معززة",
        "أصباغ ثابتة اللون",
        "خيارات امتصاص الرطوبة",
        "بدائل مستدامة متاحة",
      ],
    },
    cta: {
      en: "Request a swatch book",
      ar: "اطلب كتاب العينات"
    },
  },
};

// Testimonials section configuration
export interface TestimonialItem {
  quote: Record<Language, string>;
  author: string;
  role: Record<Language, string>;
  company: string;
  image: string;
  rating: number;
}

export interface TestimonialsConfig {
  label: Record<Language, string>;
  heading: Record<Language, string>;
  testimonials: TestimonialItem[];
}

export const testimonialsConfig: TestimonialsConfig = {
  label: {
    en: "Testimonials",
    ar: "آراء العملاء"
  },
  heading: {
    en: "TRUSTED / BY TEAMS",
    ar: "موثوق / من الفرق"
  },
  testimonials: [
    {
      quote: {
        en: "TERA turned our brand colors into a uniform system that actually fits the whole team.",
        ar: "حولت تيرا ألوان علامتنا التجارية إلى نظام زي موحد يناسب الفريق بأكمله فعلياً."
      },
      author: "A. Bennett",
      role: {
        en: "Operations",
        ar: "العمليات"
      },
      company: "Northfield",
      image: "/images/studio-portrait.jpg",
      rating: 5,
    },
    {
      quote: {
        en: "Sampling was fast. The final product feels premium—and it survives our laundry cycle.",
        ar: "كانت العينات سريعة. المنتج النهائي يبدو متميزاً—ويتحمل دورة الغسيل لدينا."
      },
      author: "R. Chen",
      role: {
        en: "Facilities",
        ar: "المرافق"
      },
      company: "Metro Health",
      image: "/images/featured-coat.jpg",
      rating: 5,
    },
    {
      quote: {
        en: "They designed for our brand, not just our logo. That made the rollout easy.",
        ar: "صمموا لعلامتنا التجارية، وليس فقط لشعارنا. وهذا جعل الإطلاق سهلاً."
      },
      author: "S. Patel",
      role: {
        en: "Brand Lead",
        ar: "قائد العلامة التجارية"
      },
      company: "Atlas Hotels",
      image: "/images/portfolio-01.jpg",
      rating: 5,
    },
  ],
};

// CTA section configuration
export interface CTAConfig {
  tags: Record<Language, string[]>;
  heading: Record<Language, string>;
  description: Record<Language, string>;
  buttonText: Record<Language, string>;
  buttonHref: string;
  email: string;
  backgroundImage: string;
}

export const ctaConfig: CTAConfig = {
  tags: {
    en: ["Custom Design", "Bulk Orders", "Brand Uniforms"],
    ar: ["تصميم مخصص", "طلبات بالجملة", "أزياء العلامة التجارية"]
  },
  heading: {
    en: "READY WHEN / YOU ARE",
    ar: "جاهزون / عندما تكونون"
  },
  description: {
    en: "Tell us what you need. We'll reply with next steps, timelines, and a clear quote.",
    ar: "أخبرنا بما تحتاجه. سوف نرد بالخطوات التالية والجداول الزمنية وعرض سعر واضح."
  },
  buttonText: {
    en: "Request a quote",
    ar: "اطلب عرض سعر"
  },
  buttonHref: "#contact",
  email: "hello@terauniforms.com",
  backgroundImage: "/images/cta-bg.jpg",
};

// Footer section configuration
export interface FooterLinkColumn {
  title: Record<Language, string>;
  links: { label: Record<Language, string>; href: string }[];
}

export interface SocialLink {
  iconName: string;
  href: string;
  label: string;
}

export interface FooterConfig {
  logo: string;
  description: Record<Language, string>;
  columns: FooterLinkColumn[];
  socialLinks: SocialLink[];
  newsletterHeading: Record<Language, string>;
  newsletterDescription: Record<Language, string>;
  newsletterButtonText: Record<Language, string>;
  newsletterPlaceholder: Record<Language, string>;
  copyright: Record<Language, string>;
  credit: Record<Language, string>;
  contactInfo: {
    email: string;
    phone: string;
    hours: Record<Language, string>;
  };
}

export const footerConfig: FooterConfig = {
  logo: "/images/logo.png",
  description: {
    en: "Uniforms that feel like your brand. Custom workwear systems for teams that care about fit, function, and identity.",
    ar: "أزياء تشعر وكأنها علامتك التجارية. أنظمة ملابس العمل المخصصة للفرق التي تهتم بالملاءمة والوظيفة والهوية."
  },
  columns: [
    {
      title: {
        en: "Services",
        ar: "خدماتنا"
      },
      links: [
        { label: { en: "Design & Branding", ar: "التصميم والعلامة التجارية" }, href: "#services" },
        { label: { en: "Sampling & Fitting", ar: "العينات والملاءمة" }, href: "#services" },
        { label: { en: "Manufacturing", ar: "التصنيع" }, href: "#services" },
        { label: { en: "Custom Orders", ar: "الطلبات المخصصة" }, href: "#contact" },
      ],
    },
    {
      title: {
        en: "Company",
        ar: "الشركة"
      },
      links: [
        { label: { en: "About Us", ar: "من نحن" }, href: "#about" },
        { label: { en: "Our Work", ar: "أعمالنا" }, href: "#portfolio" },
        { label: { en: "Process", ar: "العملية" }, href: "#process" },
        { label: { en: "Contact", ar: "اتصل بنا" }, href: "#contact" },
      ],
    },
    {
      title: {
        en: "Industries",
        ar: "الصناعات"
      },
      links: [
        { label: { en: "Corporate", ar: "المؤسسات" }, href: "#" },
        { label: { en: "Hospitality", ar: "الضيافة" }, href: "#" },
        { label: { en: "Medical", ar: "الطبية" }, href: "#" },
        { label: { en: "Industrial", ar: "الصناعية" }, href: "#" },
      ],
    },
  ],
  socialLinks: [
    { iconName: "Instagram", href: "#", label: "Instagram" },
    { iconName: "Linkedin", href: "#", label: "LinkedIn" },
    { iconName: "Twitter", href: "#", label: "Twitter" },
  ],
  newsletterHeading: {
    en: "Stay Updated",
    ar: "ابقَ على اطلاع"
  },
  newsletterDescription: {
    en: "Get the latest on new collections, materials, and uniform design insights.",
    ar: "احصل على أحدث المعلومات حول المجموعات الجديدة والمواد ورؤى تصميم الزي الموحد."
  },
  newsletterButtonText: {
    en: "Subscribe",
    ar: "اشترك"
  },
  newsletterPlaceholder: {
    en: "Enter your email",
    ar: "أدخل بريدك الإلكتروني"
  },
  copyright: {
    en: "© 2026 TERA Uniforms. All rights reserved.",
    ar: "© 2026 تيرا للزي الموحد. جميع الحقوق محفوظة."
  },
  credit: {
    en: "Designed with precision. Crafted with care.",
    ar: "مصمم بدقة. مصنوع بعناية."
  },
  contactInfo: {
    email: "hello@terauniforms.com",
    phone: "+1 (555) 013-2488",
    hours: {
      en: "Mon–Fri, 9am–6pm",
      ar: "الإثنين–الجمعة، 9ص–6م"
    },
  },
};

import { useState, useEffect, useRef } from 'react';
import { cn } from '@/lib/utils';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { testimonialsConfig } from '@/config';
import { useLanguage } from '@/context/LanguageContext';
import { Star, ChevronLeft, ChevronRight, Quote } from 'lucide-react';

export function Testimonials() {
  const { t, language, dir } = useLanguage();
  const config = testimonialsConfig;
  const { ref, isVisible } = useScrollAnimation({ threshold: 0.2 });
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const testimonials = config.testimonials;

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const goToSlide = (index: number) => {
    setCurrentIndex(index);
  };

  useEffect(() => {
    if (isAutoPlaying) {
      intervalRef.current = setInterval(nextSlide, 6000);
    }
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isAutoPlaying]);

  const handleManualNavigation = (action: () => void) => {
    setIsAutoPlaying(false);
    action();
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  return (
    <section 
      id="testimonials" 
      className="w-full py-20 lg:py-28 bg-white"
      dir={dir}
    >
      <div ref={ref} className="container-large px-5 lg:px-12">
        {/* Header */}
        <div
          className={cn(
            'mb-12 lg:mb-16 text-center transition-all duration-1000',
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          )}
        >
          <span className="text-xs font-geist-mono uppercase tracking-widest text-[#000000]/50">
            {t(config.label)}
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-[clamp(2rem,5vw,4rem)] font-black text-[#000000] mt-4 tracking-[-0.03em] leading-[1.1]">
            {language === 'ar' ? 'موثوق من الفرق' : 'Trusted by Teams'}
          </h2>
        </div>

        {/* Testimonial Slider */}
        <div
          className={cn(
            'relative max-w-4xl mx-auto transition-all duration-1000 delay-200',
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          )}
        >
          {/* Quote Icon */}
          <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-12 h-12 bg-[#E10715] rounded-full flex items-center justify-center z-10">
            <Quote className="w-5 h-5 text-white" />
          </div>

          {/* Slider Container */}
          <div className="bg-[#F6F6F6] rounded-[28px] p-8 lg:p-12 pt-12 lg:pt-16 overflow-hidden">
            <div className="relative h-[300px] sm:h-[250px]">
              {testimonials.map((testimonial, index) => (
                <div
                  key={index}
                  className={cn(
                    'absolute inset-0 transition-all duration-500',
                    index === currentIndex
                      ? 'opacity-100 translate-x-0'
                      : index < currentIndex
                      ? 'opacity-0 -translate-x-full'
                      : 'opacity-0 translate-x-full'
                  )}
                >
                  {/* Stars */}
                  <div className="flex justify-center gap-1 mb-6">
                    {Array.from({ length: testimonial.rating }).map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-[#E10715] text-[#E10715]" />
                    ))}
                  </div>

                  {/* Quote */}
                  <p className="text-lg lg:text-xl text-[#000000] text-center leading-relaxed mb-8">
                    &ldquo;{t(testimonial.quote)}&rdquo;
                  </p>

                  {/* Author */}
                  <div className="flex items-center justify-center gap-4">
                    <div className="w-12 h-12 rounded-full overflow-hidden bg-neutral-200">
                      <img
                        src={testimonial.image}
                        alt={testimonial.author}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="text-center">
                      <div className="font-semibold text-[#000000]">{testimonial.author}</div>
                      <div className="text-sm text-[#000000]/60">
                        {t(testimonial.role)}, {testimonial.company}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Navigation */}
            <div className="flex items-center justify-center gap-4 mt-8">
              <button
                onClick={() => handleManualNavigation(prevSlide)}
                className="w-10 h-10 rounded-full bg-white flex items-center justify-center hover:bg-[#E10715] hover:text-white transition-colors"
              >
                <ChevronLeft className={cn("w-5 h-5", dir === 'rtl' && "rotate-180")} />
              </button>

              {/* Dots */}
              <div className="flex gap-2">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => handleManualNavigation(() => goToSlide(index))}
                    className={cn(
                      'w-2 h-2 rounded-full transition-all',
                      index === currentIndex
                        ? 'w-6 bg-[#E10715]'
                        : 'bg-[#000000]/20 hover:bg-[#000000]/40'
                    )}
                  />
                ))}
              </div>

              <button
                onClick={() => handleManualNavigation(nextSlide)}
                className="w-10 h-10 rounded-full bg-white flex items-center justify-center hover:bg-[#E10715] hover:text-white transition-colors"
              >
                <ChevronRight className={cn("w-5 h-5", dir === 'rtl' && "rotate-180")} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

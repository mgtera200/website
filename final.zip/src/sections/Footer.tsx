import { cn } from '@/lib/utils';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { footerConfig } from '@/config';
import { useLanguage } from '@/context/LanguageContext';
import { Mail, Phone, Clock, Send, Instagram, Linkedin, Twitter } from 'lucide-react';

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Instagram,
  Linkedin,
  Twitter,
};

export function Footer() {
  const { t, dir } = useLanguage();
  const config = footerConfig;
  const { ref, isVisible } = useScrollAnimation({ threshold: 0.1 });

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // WordPress Contact Form 7 integration placeholder
    alert('Form submission will be connected to WordPress Contact Form 7');
  };

  return (
    <footer
      ref={ref}
      id="contact"
      className="w-full bg-[#111111] text-white py-16 lg:py-24"
      dir={dir}
    >
      <div className="container-large px-6 lg:px-12">
        {/* Main Footer Content */}
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-8 mb-16">
          {/* Left Column - Brand & Contact */}
          <div
            className={cn(
              'lg:col-span-5 space-y-8 transition-all duration-800',
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            )}
          >
            {/* Logo */}
            <img 
              src={config.logo} 
              alt="TERA UNIFORMS" 
              className="h-16 w-auto brightness-0 invert"
            />

            <p className="text-sm text-white/60 max-w-sm leading-relaxed">
              {t(config.description)}
            </p>

            {/* Contact Info */}
            <div className="space-y-4">
              {config.contactInfo.email && (
                <a
                  href={`mailto:${config.contactInfo.email}`}
                  className="flex items-center gap-3 text-white/70 hover:text-white transition-colors"
                >
                  <Mail className="w-4 h-4" />
                  <span className="text-sm">{config.contactInfo.email}</span>
                </a>
              )}

              {config.contactInfo.phone && (
                <a
                  href={`tel:${config.contactInfo.phone}`}
                  className="flex items-center gap-3 text-white/70 hover:text-white transition-colors"
                >
                  <Phone className="w-4 h-4" />
                  <span className="text-sm">{config.contactInfo.phone}</span>
                </a>
              )}

              {config.contactInfo.hours && (
                <div className="flex items-center gap-3 text-white/70">
                  <Clock className="w-4 h-4" />
                  <span className="text-sm">{t(config.contactInfo.hours)}</span>
                </div>
              )}
            </div>

            {/* Social Links */}
            <div className="flex gap-3">
              {config.socialLinks.map((social) => {
                const IconComponent = iconMap[social.iconName];
                return (
                  <a
                    key={social.label}
                    href={social.href}
                    className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-[#E10715] transition-colors"
                    aria-label={social.label}
                  >
                    {IconComponent && <IconComponent className="w-4 h-4" />}
                  </a>
                );
              })}
            </div>
          </div>

          {/* Link Columns */}
          <div className="lg:col-span-4 grid grid-cols-3 gap-6">
            {config.columns.map((column, columnIndex) => (
              <div
                key={column.title.en}
                className={cn(
                  'transition-all duration-800',
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
                )}
                style={{ transitionDelay: `${(columnIndex + 1) * 100}ms` }}
              >
                <h4 className="text-sm font-semibold text-white mb-4">
                  {t(column.title)}
                </h4>
                <ul className="space-y-3">
                  {column.links.map((link) => (
                    <li key={link.label.en}>
                      <a
                        href={link.href}
                        className="text-sm text-white/60 hover:text-white transition-colors"
                      >
                        {t(link.label)}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* Newsletter */}
          <div
            className={cn(
              'lg:col-span-3 transition-all duration-800',
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            )}
            style={{ transitionDelay: '400ms' }}
          >
            <h4 className="text-sm font-semibold text-white mb-2">
              {t(config.newsletterHeading)}
            </h4>
            <p className="text-sm text-white/60 mb-4">
              {t(config.newsletterDescription)}
            </p>

            <form onSubmit={handleSubmit} className="flex gap-2">
              <input
                type="email"
                placeholder={t(config.newsletterPlaceholder)}
                className="flex-1 px-4 py-3 bg-white/10 border border-white/10 rounded-full text-sm text-white placeholder:text-white/40 focus:outline-none focus:border-white/30"
              />
              <button
                type="submit"
                className="w-12 h-12 bg-[#E10715] rounded-full flex items-center justify-center hover:bg-[#C00612] transition-colors flex-shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>

        {/* Contact Form Section */}
        <div
          className={cn(
            'border-t border-white/10 pt-12 transition-all duration-800',
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
          )}
          style={{ transitionDelay: '500ms' }}
        >
          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl lg:text-3xl font-bold text-white mb-4">
                {dir === 'rtl' ? 'لنتحدث' : "Let's Talk"}
              </h3>
              <p className="text-white/60">
                {dir === 'rtl' 
                  ? 'أرسل لنا رسالة وسنرد عليك في أقرب وقت ممكن.' 
                  : 'Send us a message and we will get back to you as soon as possible.'}
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <input
                  type="text"
                  name="your-name"
                  placeholder={dir === 'rtl' ? 'الاسم' : 'Name'}
                  required
                  className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-sm text-white placeholder:text-white/40 focus:outline-none focus:border-white/30"
                />
                <input
                  type="email"
                  name="your-email"
                  placeholder={dir === 'rtl' ? 'البريد الإلكتروني' : 'Email'}
                  required
                  className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-sm text-white placeholder:text-white/40 focus:outline-none focus:border-white/30"
                />
              </div>

              <input
                type="text"
                name="your-subject"
                placeholder={dir === 'rtl' ? 'الموضوع' : 'Subject'}
                required
                className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-sm text-white placeholder:text-white/40 focus:outline-none focus:border-white/30"
              />

              <textarea
                name="your-message"
                placeholder={dir === 'rtl' ? 'الرسالة' : 'Message'}
                rows={4}
                className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-sm text-white placeholder:text-white/40 focus:outline-none focus:border-white/30 resize-none"
              />

              <button
                type="submit"
                className="w-full sm:w-auto px-8 py-3 bg-[#E10715] text-white text-sm font-medium rounded-full hover:bg-[#C00612] transition-colors"
              >
                {dir === 'rtl' ? 'إرسال الرسالة' : 'Send Message'}
              </button>
            </form>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/10 mt-12 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-white/40">
            {t(config.copyright)}
          </p>
          <p className="text-sm text-white/40">
            {t(config.credit)}
          </p>
        </div>
      </div>
    </footer>
  );
}

import { cn } from '@/lib/utils';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { aboutConfig } from '@/config';
import { useLanguage } from '@/context/LanguageContext';

export function About() {
  const { t, language, dir } = useLanguage();
  const config = aboutConfig;
  const { ref, isVisible } = useScrollAnimation({ threshold: 0.2 });

  if (!config.description) return null;

  return (
    <section 
      id="about" 
      className="w-full py-20 lg:py-28 bg-white"
      dir={dir}
    >
      <div ref={ref} className="container-large px-5 lg:px-12">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Content */}
          <div
            className={cn(
              'space-y-8 transition-all duration-1000',
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            )}
          >
            <span className="text-xs font-geist-mono uppercase tracking-widest text-[#000000]/50">
              {t(config.label)}
            </span>
            
            <h2 className="text-3xl sm:text-4xl lg:text-[clamp(2rem,5vw,4rem)] font-black text-[#000000] tracking-[-0.03em] leading-[1.1]">
              {language === 'ar' ? 'من نحن' : 'About Us'}
            </h2>

            <p className="text-xl lg:text-2xl text-[#000000] leading-relaxed">
              {t(config.description)}
            </p>

            {/* Stats */}
            <div className="flex flex-wrap gap-8 lg:gap-12 pt-4">
              <div className="text-center">
                <div className="text-4xl lg:text-5xl font-black text-[#E10715]">
                  {config.experienceValue}
                </div>
                <div className="mt-2 text-sm text-[#000000]/60 whitespace-pre-line">
                  {t(config.experienceLabel)}
                </div>
              </div>
              {config.stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="text-4xl lg:text-5xl font-black text-[#000000]">
                    {stat.value}
                  </div>
                  <div className="mt-2 text-sm text-[#000000]/60">
                    {t(stat.label)}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Image */}
          <div
            className={cn(
              'relative transition-all duration-1000 delay-200',
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            )}
          >
            <div className="aspect-[4/5] rounded-[28px] overflow-hidden bg-neutral-200">
              <img
                src={config.images[0]?.src}
                alt={t(config.images[0]?.alt)}
                className="w-full h-full object-cover"
              />
            </div>
            
            {/* Decorative element */}
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-[#E10715]/10 rounded-full -z-10" />
            <div className="absolute -top-6 -left-6 w-24 h-24 border-2 border-[#E10715]/20 rounded-full -z-10" />
          </div>
        </div>
      </div>
    </section>
  );
}

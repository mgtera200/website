import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { ArrowUpRight, ShoppingBag } from 'lucide-react';
import { productsConfig } from '@/config';
import { useLanguage } from '@/context/LanguageContext';

function ProductCard({ product, index }: { product: typeof productsConfig.products[0]; index: number }) {
  const { t, dir } = useLanguage();
  const [isVisible, setIsVisible] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setTimeout(() => setIsVisible(true), index * 100);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (cardRef.current) {
      observer.observe(cardRef.current);
    }

    return () => observer.disconnect();
  }, [index]);

  return (
    <div
      ref={cardRef}
      className={cn(
        'group cursor-pointer transition-all duration-700',
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
      )}
    >
      <Link to={`/shop/${product.id}`}>
        <div className="relative overflow-hidden bg-[#000000]/5 rounded-[20px] lg:rounded-[28px]">
          <div className="aspect-[4/5]">
            <img
              src={product.image}
              alt={t(product.name)}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
          </div>

          <div className="absolute inset-0 bg-[#000000]/0 group-hover:bg-[#000000]/20 transition-colors duration-500" />

          <div className="absolute top-3 lg:top-4 right-3 lg:right-4">
            <span className="px-2.5 lg:px-3 py-1 lg:py-1.5 text-xs font-geist-mono bg-white/90 backdrop-blur-sm rounded-full text-[#000000]">
              {t(product.category)}
            </span>
          </div>

          <div className="absolute bottom-3 lg:bottom-4 right-3 lg:right-4 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-2 group-hover:translate-y-0">
            <div className="w-8 lg:w-10 h-8 lg:h-10 bg-white rounded-full flex items-center justify-center">
              <ArrowUpRight className={cn("w-3.5 lg:w-4 h-3.5 lg:h-4 text-[#000000]", dir === 'rtl' && "rotate-90")} />
            </div>
          </div>
        </div>

        <div className="mt-3 lg:mt-4 space-y-1">
          <div className="flex items-start justify-between">
            <div>
              <h3 className="text-base lg:text-lg font-semibold text-[#000000] group-hover:text-[#E10715] transition-colors">
                {t(product.name)}
              </h3>
              <p className="text-xs lg:text-sm text-[#000000]/50">{t(product.variant)}</p>
            </div>
            <span className="text-base lg:text-lg font-semibold text-[#E10715]">
              ${product.price}
            </span>
          </div>
          <p className="text-xs lg:text-sm text-[#000000]/60 line-clamp-2">
            {t(product.description)}
          </p>
        </div>
      </Link>
    </div>
  );
}

export function Products() {
  const { t, language, dir } = useLanguage();
  const config = productsConfig;
  const [headerVisible, setHeaderVisible] = useState(false);
  const headerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setHeaderVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (headerRef.current) {
      observer.observe(headerRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section 
      id="products" 
      className="w-full py-20 lg:py-28 bg-white"
      dir={dir}
    >
      <div className="container-large px-5 lg:px-12">
        {/* Header */}
        <div ref={headerRef} className="mb-12 lg:mb-16">
          <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6">
            <div>
              <span
                className={cn(
                  'text-xs font-geist-mono uppercase tracking-widest text-[#000000]/50 transition-all duration-800',
                  headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
                )}
              >
                {t(config.label)}
              </span>
              <h2
                className={cn(
                  'text-3xl sm:text-4xl lg:text-[clamp(2rem,5vw,4rem)] font-black text-[#000000] mt-4 tracking-[-0.03em] leading-[1.1] transition-all duration-800',
                  headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
                )}
                style={{ transitionDelay: '100ms' }}
              >
                {language === 'ar' ? 'منتجاتنا' : 'Our Products'}
              </h2>
              <p
                className={cn(
                  'mt-4 text-base lg:text-lg text-[#000000]/60 max-w-xl transition-all duration-800',
                  headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
                )}
                style={{ transitionDelay: '200ms' }}
              >
                {t(config.description)}
              </p>
            </div>

            <div
              className={cn(
                'flex items-center gap-4 transition-all duration-800',
                headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              )}
              style={{ transitionDelay: '300ms' }}
            >
              <Link
                to="/shop"
                className="flex items-center gap-3 px-5 lg:px-6 py-2.5 lg:py-3 bg-[#E10715] text-white rounded-full hover:bg-[#C00612] transition-colors"
              >
                <ShoppingBag className="w-4 lg:w-5 h-4 lg:h-5" />
                <span className="text-sm font-medium">
                  {t(config.viewAllLabel)}
                </span>
              </Link>
            </div>
          </div>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4 lg:gap-6">
          {config.products.map((product, index) => (
            <ProductCard
              key={product.id}
              product={product}
              index={index}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

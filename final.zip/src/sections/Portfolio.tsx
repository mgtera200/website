import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { ArrowUpRight } from 'lucide-react';
import { portfolioConfig } from '@/config';
import { useLanguage } from '@/context/LanguageContext';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

// Portfolio projects data
const projects = [
  {
    title: { en: "Hospitality Collection", ar: "مجموعة الضيافة" },
    category: { en: "Aprons & Shirts", ar: "المريلات والقمصان" },
    year: "2024",
    image: "/images/portfolio-01.jpg",
    featured: true,
  },
  {
    title: { en: "Medical Scrubs System", ar: "نظام الملابس الطبية" },
    category: { en: "Scrubs & Lab Coats", ar: "الملابس الطبية والمعاطف" },
    year: "2024",
    image: "/images/portfolio-02.jpg",
    featured: false,
  },
  {
    title: { en: "Field Workwear", ar: "ملابس العمل الميداني" },
    category: { en: "Jackets & Trousers", ar: "الجاكيتات والبناطيل" },
    year: "2023",
    image: "/images/portfolio-03.jpg",
    featured: false,
  },
  {
    title: { en: "Studio Uniform", ar: "زي الاستوديو" },
    category: { en: "Coats & Tops", ar: "المعاطف والقمصان" },
    year: "2023",
    image: "/images/portfolio-04.jpg",
    featured: false,
  },
  {
    title: { en: "Service Kit", ar: "طقم الخدمة" },
    category: { en: "Polos & Trousers", ar: "البولو والبناطيل" },
    year: "2023",
    image: "/images/portfolio-05.jpg",
    featured: false,
  },
];

function ProjectCard({ project, index }: { project: typeof projects[0]; index: number }) {
  const { t, dir } = useLanguage();
  const [isVisible, setIsVisible] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setTimeout(() => setIsVisible(true), index * 100);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (cardRef.current) {
      observer.observe(cardRef.current);
    }

    return () => observer.disconnect();
  }, [index]);

  return (
    <div
      ref={cardRef}
      className={cn(
        'group cursor-pointer transition-all duration-700',
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8',
        project.featured && 'md:col-span-2 md:row-span-2'
      )}
    >
      <div className="relative overflow-hidden rounded-[20px] lg:rounded-[28px] bg-neutral-200 h-full">
        <div className={cn('w-full', project.featured ? 'aspect-square' : 'aspect-[4/3]')}>
          <img
            src={project.image}
            alt={t(project.title)}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
        </div>

        <div className="absolute inset-0 bg-gradient-to-t from-[#000000]/80 via-[#000000]/20 to-transparent opacity-60 group-hover:opacity-80 transition-opacity duration-500" />

        {/* Content */}
        <div className="absolute bottom-0 left-0 right-0 p-5 lg:p-6">
          <div className="flex items-center gap-3 mb-2">
            <span className="text-xs font-geist-mono text-white/60">{t(project.category)}</span>
            <span className="text-xs text-white/40">•</span>
            <span className="text-xs font-geist-mono text-white/60">{project.year}</span>
          </div>
          <h3 className={cn(
            'font-semibold text-white group-hover:text-[#E10715] transition-colors',
            project.featured ? 'text-2xl lg:text-3xl' : 'text-lg lg:text-xl'
          )}>
            {t(project.title)}
          </h3>
        </div>

        {/* Arrow */}
        <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-2 group-hover:translate-y-0">
          <div className={cn("w-10 h-10 bg-white rounded-full flex items-center justify-center", dir === 'rtl' && "rotate-90")}>
            <ArrowUpRight className="w-5 h-5 text-[#000000]" />
          </div>
        </div>
      </div>
    </div>
  );
}

export function Portfolio() {
  const { t, language, dir } = useLanguage();
  const config = portfolioConfig;
  const { ref, isVisible } = useScrollAnimation({ threshold: 0.1 });

  return (
    <section 
      id="portfolio" 
      className="w-full py-20 lg:py-28 bg-white"
      dir={dir}
    >
      <div ref={ref} className="container-large px-5 lg:px-12">
        {/* Header */}
        <div
          className={cn(
            'mb-12 lg:mb-16 transition-all duration-1000',
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          )}
        >
          <span className="text-xs font-geist-mono uppercase tracking-widest text-[#000000]/50">
            {t(config.label)}
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-[clamp(2rem,5vw,4rem)] font-black text-[#000000] mt-4 tracking-[-0.03em] leading-[1.1]">
            {language === 'ar' ? 'أعمالنا المختارة' : 'Selected Work'}
          </h2>
          <p className="mt-4 text-base lg:text-lg text-[#000000]/60 max-w-2xl">
            {t(config.description)}
          </p>
        </div>

        {/* Bento Grid */}
        <div className="grid md:grid-cols-3 gap-4 lg:gap-6">
          {projects.map((project, index) => (
            <ProjectCard key={index} project={project} index={index} />
          ))}

          {/* CTA Card */}
          <div
            className={cn(
              'bg-[#111111] rounded-[20px] lg:rounded-[28px] p-6 lg:p-8 flex flex-col justify-between transition-all duration-700',
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            )}
            style={{ transitionDelay: '600ms' }}
          >
            <div>
              <span className="text-xs font-geist-mono uppercase tracking-widest text-white/50">
                {t(config.cta.label)}
              </span>
              <h3 className="text-xl lg:text-2xl font-semibold text-white mt-4">
                {t(config.cta.heading)}
              </h3>
            </div>
            <Link
              to={config.cta.linkHref}
              className="inline-flex items-center gap-2 text-[#E10715] hover:text-white transition-colors mt-6"
            >
              <span className="text-sm font-medium">{t(config.cta.linkText)}</span>
              <ArrowUpRight className={cn("w-4 h-4", dir === 'rtl' && "rotate-90")} />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}

import { cn } from '@/lib/utils';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { useMouseParallax } from '@/hooks/useMouseParallax';
import { servicesConfig } from '@/config';
import { useLanguage } from '@/context/LanguageContext';
import { Palette, Scissors, Factory } from 'lucide-react';

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Palette,
  Scissors,
  Factory,
};

function ServiceCard({ service }: { service: typeof servicesConfig.services[0] }) {
  const { t } = useLanguage();
  const { ref, position } = useMouseParallax(15);
  
  const IconComponent = iconMap[service.iconName];

  return (
    <div
      ref={ref}
      className="group relative bg-white/80 backdrop-blur-sm rounded-[24px] p-6 lg:p-8 hover:shadow-xl transition-all duration-500 overflow-hidden"
    >
      {/* Parallax Image Background */}
      <div 
        className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
        style={{
          transform: `translate(${position.x}px, ${position.y}px)`,
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-[#000000]/80 to-transparent" />
        <img
          src={service.image}
          alt={t(service.title)}
          className="w-full h-full object-cover scale-110"
        />
      </div>

      {/* Content */}
      <div className="relative z-10">
        <div className="w-12 h-12 bg-[#E10715]/10 rounded-xl flex items-center justify-center mb-6 group-hover:bg-white/20 transition-colors">
          {IconComponent && <IconComponent className="w-6 h-6 text-[#E10715] group-hover:text-white transition-colors" />}
        </div>

        <h3 className="text-xl lg:text-2xl font-semibold text-[#000000] group-hover:text-white transition-colors mb-3">
          {t(service.title)}
        </h3>

        <p className="text-sm lg:text-base text-[#000000]/60 group-hover:text-white/80 transition-colors leading-relaxed">
          {t(service.description)}
        </p>
      </div>
    </div>
  );
}

export function Services() {
  const { t, language, dir } = useLanguage();
  const config = servicesConfig;
  const { ref, isVisible } = useScrollAnimation({ threshold: 0.1 });

  return (
    <section 
      id="services" 
      className="w-full py-20 lg:py-28 bg-[#F6F6F6] relative overflow-hidden"
      dir={dir}
    >
      {/* Background Image */}
      <div className="absolute inset-0 opacity-5">
        <img
          src={config.backgroundImage}
          alt=""
          className="w-full h-full object-cover"
        />
      </div>

      <div ref={ref} className="container-large px-5 lg:px-12 relative z-10">
        {/* Header */}
        <div
          className={cn(
            'mb-12 lg:mb-16 transition-all duration-1000',
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          )}
        >
          <span className="text-xs font-geist-mono uppercase tracking-widest text-[#000000]/50">
            {t(config.label)}
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-[clamp(2rem,5vw,4rem)] font-black text-[#000000] mt-4 tracking-[-0.03em] leading-[1.1]">
            {language === 'ar' ? 'تصميم / عينات / إنتاج' : 'Design / Sampling / Production'}
          </h2>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {config.services.map((service, index) => (
            <div
              key={service.title.en}
              className={cn(
                'transition-all duration-700',
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              )}
              style={{ transitionDelay: `${(index + 1) * 150}ms` }}
            >
              <ServiceCard service={service} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

import { cn } from '@/lib/utils';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { detailConfig } from '@/config';
import { useLanguage } from '@/context/LanguageContext';
import { Check } from 'lucide-react';

export function Detail() {
  const { t, language, dir } = useLanguage();
  const config = detailConfig;
  const { ref, isVisible } = useScrollAnimation({ threshold: 0.2 });

  return (
    <section 
      id="detail" 
      className="w-full py-20 lg:py-28 bg-[#F6F6F6] relative overflow-hidden"
      dir={dir}
    >
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src={config.backgroundImage}
          alt=""
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-[#000000]/60" />
      </div>

      <div ref={ref} className="container-large px-5 lg:px-12 relative z-10">
        {/* Header */}
        <div
          className={cn(
            'mb-12 lg:mb-16 transition-all duration-1000',
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          )}
        >
          <span className="text-xs font-geist-mono uppercase tracking-widest text-white/50">
            {t(config.label)}
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-[clamp(2rem,5vw,4rem)] font-black text-white mt-4 tracking-[-0.03em] leading-[1.1]">
            {language === 'ar' ? 'تفاصيل تدوم' : 'Detail That Lasts'}
          </h2>
        </div>

        {/* Content Card */}
        <div
          className={cn(
            'max-w-2xl transition-all duration-1000 delay-200',
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          )}
        >
          <div className="bg-white/95 backdrop-blur-sm rounded-[28px] p-6 lg:p-10">
            <span className="text-xs font-geist-mono uppercase tracking-widest text-[#000000]/50">
              {t(config.card.label)}
            </span>

            <p className="mt-4 text-lg text-[#000000] leading-relaxed">
              {t(config.card.paragraph)}
            </p>

            <ul className="mt-6 space-y-3">
              {t(config.card.bullets).map((bullet, index) => (
                <li key={index} className="flex items-center gap-3">
                  <div className="w-5 h-5 bg-[#E10715]/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <Check className="w-3 h-3 text-[#E10715]" />
                  </div>
                  <span className="text-sm text-[#000000]/70">{bullet}</span>
                </li>
              ))}
            </ul>

            <button className="mt-8 px-6 py-3 bg-[#E10715] text-white rounded-full text-sm font-medium hover:bg-[#C00612] transition-colors">
              {t(config.card.cta)}
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

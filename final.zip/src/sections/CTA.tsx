import { cn } from '@/lib/utils';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { ctaConfig } from '@/config';
import { useLanguage } from '@/context/LanguageContext';
import { ArrowRight, Mail } from 'lucide-react';

export function CTA() {
  const { t, language, dir } = useLanguage();
  const config = ctaConfig;
  const { ref, isVisible } = useScrollAnimation({ threshold: 0.2 });

  return (
    <section 
      id="cta" 
      className="w-full py-20 lg:py-28 relative overflow-hidden"
      dir={dir}
    >
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src={config.backgroundImage}
          alt=""
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-[#000000]/70" />
      </div>

      <div ref={ref} className="container-large px-5 lg:px-12 relative z-10">
        <div
          className={cn(
            'max-w-3xl mx-auto text-center transition-all duration-1000',
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          )}
        >
          {/* Tags */}
          <div className="flex flex-wrap justify-center gap-3 mb-8">
            {t(config.tags).map((tag, index) => (
              <span
                key={index}
                className="px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full text-sm text-white/80"
              >
                {tag}
              </span>
            ))}
          </div>

          {/* Heading */}
          <h2 className="text-3xl sm:text-4xl lg:text-[clamp(2rem,5vw,4rem)] font-black text-white tracking-[-0.03em] leading-[1.1]">
            {language === 'ar' ? 'جاهزون عندما تكونون' : 'Ready When You Are'}
          </h2>

          {/* Description */}
          <p className="mt-6 text-lg text-white/70 max-w-xl mx-auto">
            {t(config.description)}
          </p>

          {/* CTA Buttons */}
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href={config.buttonHref}
              className="inline-flex items-center gap-2 px-8 py-4 bg-[#E10715] text-white font-medium rounded-full hover:bg-[#C00612] transition-colors"
            >
              {t(config.buttonText)}
              <ArrowRight className={cn("w-5 h-5", dir === 'rtl' && "rotate-180")} />
            </a>

            <a
              href={`mailto:${config.email}`}
              className="inline-flex items-center gap-2 px-8 py-4 bg-white/10 backdrop-blur-sm text-white font-medium rounded-full hover:bg-white/20 transition-colors"
            >
              <Mail className="w-5 h-5" />
              {config.email}
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

import { cn } from '@/lib/utils';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { processConfig } from '@/config';
import { useLanguage } from '@/context/LanguageContext';

export function Process() {
  const { t, language, dir } = useLanguage();
  const config = processConfig;
  const { ref, isVisible } = useScrollAnimation({ threshold: 0.1 });

  return (
    <section 
      id="process" 
      className="w-full py-20 lg:py-28 bg-[#111111] text-white relative overflow-hidden"
      dir={dir}
    >
      {/* Background Image */}
      <div className="absolute inset-0 opacity-20">
        <img
          src={config.backgroundImage}
          alt=""
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#111111] via-transparent to-[#111111]" />
      </div>

      <div ref={ref} className="container-large px-5 lg:px-12 relative z-10">
        {/* Header */}
        <div
          className={cn(
            'mb-12 lg:mb-16 text-center transition-all duration-1000',
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          )}
        >
          <span className="text-xs font-geist-mono uppercase tracking-widest text-white/50">
            {t(config.label)}
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-[clamp(2rem,5vw,4rem)] font-black text-white mt-4 tracking-[-0.03em] leading-[1.1]">
            {language === 'ar' ? 'عمليتنا' : 'Our Process'}
          </h2>
        </div>

        {/* Steps */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {config.steps.map((step, index) => (
            <div
              key={step.number}
              className={cn(
                'relative transition-all duration-700',
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              )}
              style={{ transitionDelay: `${(index + 1) * 150}ms` }}
            >
              {/* Connector Line */}
              {index < config.steps.length - 1 && (
                <div className="hidden lg:block absolute top-8 left-full w-full h-px bg-white/10" />
              )}

              <div className="text-center">
                {/* Step Number */}
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-[#E10715] mb-6">
                  <span className="text-2xl font-black text-white">{step.number}</span>
                </div>

                <h3 className="text-xl lg:text-2xl font-semibold text-white mb-3">
                  {t(step.title)}
                </h3>

                <p className="text-sm lg:text-base text-white/60 leading-relaxed">
                  {t(step.description)}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

import { useEffect, useRef, useState, useCallback } from 'react';

interface ParallaxPosition {
  x: number;
  y: number;
}

export function useMouseParallax(intensity: number = 20) {
  const ref = useRef<HTMLDivElement>(null);
  const [position, setPosition] = useState<ParallaxPosition>({ x: 0, y: 0 });
  const rafRef = useRef<number | null>(null);
  const targetRef = useRef<ParallaxPosition>({ x: 0, y: 0 });

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!ref.current) return;

    const rect = ref.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const deltaX = (e.clientX - centerX) / rect.width;
    const deltaY = (e.clientY - centerY) / rect.height;

    targetRef.current = {
      x: deltaX * intensity,
      y: deltaY * intensity,
    };
  }, [intensity]);

  const animate = useCallback(() => {
    setPosition(prev => ({
      x: prev.x + (targetRef.current.x - prev.x) * 0.1,
      y: prev.y + (targetRef.current.y - prev.y) * 0.1,
    }));
    rafRef.current = requestAnimationFrame(animate);
  }, []);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;

    element.addEventListener('mousemove', handleMouseMove);
    rafRef.current = requestAnimationFrame(animate);

    return () => {
      element.removeEventListener('mousemove', handleMouseMove);
      if (rafRef.current) {
        cancelAnimationFrame(rafRef.current);
      }
    };
  }, [handleMouseMove, animate]);

  return { ref, position };
}

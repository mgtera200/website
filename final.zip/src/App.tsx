import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { LanguageProvider } from '@/context/LanguageContext';
import { Navigation } from '@/components/layout/Navigation';
import { HomePage } from '@/pages/HomePage';
import { ShopPage } from '@/pages/ShopPage';
import { QuotePage } from '@/pages/QuotePage';
import { Footer } from '@/sections/Footer';
import { SmoothScroll } from '@/components/SmoothScroll';
import './App.css';

function App() {
  return (
    <LanguageProvider>
      <Router>
        <SmoothScroll>
          <div className="min-h-screen bg-white">
            <Navigation />
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/shop" element={<ShopPage />} />
              <Route path="/shop/:productId" element={<ShopPage />} />
              <Route path="/quote" element={<QuotePage />} />
            </Routes>
            <Footer />
          </div>
        </SmoothScroll>
      </Router>
    </LanguageProvider>
  );
}

export default App;

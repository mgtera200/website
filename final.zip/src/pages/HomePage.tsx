import { Hero } from '@/sections/Hero';
import { Products } from '@/sections/Products';
import { About } from '@/sections/About';
import { Services } from '@/sections/Services';
import { Process } from '@/sections/Process';
import { Portfolio } from '@/sections/Portfolio';
import { Detail } from '@/sections/Detail';
import { Testimonials } from '@/sections/Testimonials';
import { CTA } from '@/sections/CTA';

export function HomePage() {
  return (
    <main className="w-full">
      <Hero />
      <Products />
      <About />
      <Services />
      <Process />
      <Portfolio />
      <Detail />
      <Testimonials />
      <CTA />
    </main>
  );
}

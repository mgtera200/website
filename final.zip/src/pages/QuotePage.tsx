import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { ArrowLeft, Send, Check, Building2, User, Mail, Phone, FileText, Package, Users } from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';

export function QuotePage() {
  const { language, dir } = useLanguage();
  const [headerVisible, setHeaderVisible] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    companyName: '',
    contactName: '',
    email: '',
    phone: '',
    industry: '',
    quantity: '',
    message: '',
  });

  useEffect(() => {
    setHeaderVisible(true);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // WordPress Contact Form 7 integration placeholder
    alert(language === 'ar' 
      ? 'سيتم إرسال النموذج إلى WordPress Contact Form 7'
      : 'Form will be submitted to WordPress Contact Form 7'
    );
    setIsSubmitted(true);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const industries = [
    { en: 'Corporate', ar: 'المؤسسات' },
    { en: 'Hospitality', ar: 'الضيافة' },
    { en: 'Medical', ar: 'الطبية' },
    { en: 'Industrial', ar: 'الصناعية' },
    { en: 'Education', ar: 'التعليم' },
    { en: 'Other', ar: 'أخرى' },
  ];

  const quantities = [
    { en: '10-50', ar: '10-50' },
    { en: '50-100', ar: '50-100' },
    { en: '100-500', ar: '100-500' },
    { en: '500+', ar: '500+' },
  ];

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-white pt-24 lg:pt-32 pb-20">
        <div className="container-large px-5 lg:px-12">
          <div className="max-w-2xl mx-auto text-center">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Check className="w-10 h-10 text-green-600" />
            </div>
            <h1 className="text-3xl lg:text-4xl font-bold text-[#000000] mb-4">
              {language === 'ar' ? 'تم إرسال طلبك!' : 'Quote Request Submitted!'}
            </h1>
            <p className="text-[#000000]/60 mb-8">
              {language === 'ar' 
                ? 'سنقوم بالتواصل معك قريباً مع عرض السعر والخطوات التالية.'
                : 'We will get back to you soon with a quote and next steps.'}
            </p>
            <Link
              to="/"
              className="inline-flex items-center gap-2 px-6 py-3 bg-[#E10715] text-white rounded-full hover:bg-[#C00612] transition-colors"
            >
              <ArrowLeft className={cn("w-4 h-4", dir === 'rtl' && "rotate-180")} />
              {language === 'ar' ? 'العودة إلى الصفحة الرئيسية' : 'Back to Home'}
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white pt-24 lg:pt-32 pb-20">
      <div className="container-large px-5 lg:px-12">
        {/* Back Link */}
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-[#000000]/60 hover:text-[#000000] transition-colors mb-8"
        >
          <ArrowLeft className={cn("w-4 h-4", dir === 'rtl' && "rotate-180")} />
          {language === 'ar' ? 'العودة' : 'Back'}
        </Link>

        {/* Header */}
        <div className="mb-12">
          <span
            className={cn(
              'text-xs font-geist-mono uppercase tracking-widest text-[#000000]/50 transition-all duration-800',
              headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            )}
          >
            {language === 'ar' ? 'اطلب عرض سعر' : 'Request a Quote'}
          </span>
          <h1
            className={cn(
              'text-3xl sm:text-4xl lg:text-[clamp(2.5rem,5vw,4rem)] font-black text-[#000000] mt-4 tracking-[-0.03em] leading-[1.1] transition-all duration-800',
              headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            )}
            style={{ transitionDelay: '100ms' }}
          >
            {language === 'ar' ? 'لنبدأ مشروعك' : 'Let\'s Start Your Project'}
          </h1>
          <p
            className={cn(
              'mt-4 text-base lg:text-lg text-[#000000]/60 max-w-xl transition-all duration-800',
              headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            )}
            style={{ transitionDelay: '200ms' }}
          >
            {language === 'ar' 
              ? 'أخبرنا بمتطلباتك وسنقدم لك عرض سعر مخصص خلال 24-48 ساعة.'
              : 'Tell us your requirements and we will provide a custom quote within 24-48 hours.'}
          </p>
        </div>

        {/* Form */}
        <div className="max-w-3xl">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Company & Contact Info */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-[#000000]">
                  {language === 'ar' ? 'اسم الشركة' : 'Company Name'}
                </label>
                <div className="relative">
                  <Building2 className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#000000]/40" />
                  <input
                    type="text"
                    name="companyName"
                    value={formData.companyName}
                    onChange={handleChange}
                    required
                    className="w-full pl-12 pr-4 py-3 bg-[#F6F6F6] border border-transparent rounded-xl text-sm text-[#000000] placeholder:text-[#000000]/40 focus:outline-none focus:border-[#E10715] transition-colors"
                    placeholder={language === 'ar' ? 'اسم شركتك' : 'Your company name'}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-[#000000]">
                  {language === 'ar' ? 'اسم جهة الاتصال' : 'Contact Name'}
                </label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#000000]/40" />
                  <input
                    type="text"
                    name="contactName"
                    value={formData.contactName}
                    onChange={handleChange}
                    required
                    className="w-full pl-12 pr-4 py-3 bg-[#F6F6F6] border border-transparent rounded-xl text-sm text-[#000000] placeholder:text-[#000000]/40 focus:outline-none focus:border-[#E10715] transition-colors"
                    placeholder={language === 'ar' ? 'اسمك الكامل' : 'Your full name'}
                  />
                </div>
              </div>
            </div>

            {/* Email & Phone */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-[#000000]">
                  {language === 'ar' ? 'البريد الإلكتروني' : 'Email Address'}
                </label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#000000]/40" />
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full pl-12 pr-4 py-3 bg-[#F6F6F6] border border-transparent rounded-xl text-sm text-[#000000] placeholder:text-[#000000]/40 focus:outline-none focus:border-[#E10715] transition-colors"
                    placeholder={language === 'ar' ? 'your@email.com' : 'your@email.com'}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-[#000000]">
                  {language === 'ar' ? 'رقم الهاتف' : 'Phone Number'}
                </label>
                <div className="relative">
                  <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#000000]/40" />
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    required
                    className="w-full pl-12 pr-4 py-3 bg-[#F6F6F6] border border-transparent rounded-xl text-sm text-[#000000] placeholder:text-[#000000]/40 focus:outline-none focus:border-[#E10715] transition-colors"
                    placeholder={language === 'ar' ? '+1 (555) 000-0000' : '+1 (555) 000-0000'}
                  />
                </div>
              </div>
            </div>

            {/* Industry & Quantity */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-[#000000]">
                  {language === 'ar' ? 'الصناعة' : 'Industry'}
                </label>
                <div className="relative">
                  <FileText className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#000000]/40" />
                  <select
                    name="industry"
                    value={formData.industry}
                    onChange={handleChange}
                    required
                    className="w-full pl-12 pr-4 py-3 bg-[#F6F6F6] border border-transparent rounded-xl text-sm text-[#000000] focus:outline-none focus:border-[#E10715] transition-colors appearance-none cursor-pointer"
                  >
                    <option value="">
                      {language === 'ar' ? 'اختر الصناعة' : 'Select Industry'}
                    </option>
                    {industries.map((industry) => (
                      <option key={industry.en} value={industry.en}>
                        {language === 'ar' ? industry.ar : industry.en}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-[#000000]">
                  {language === 'ar' ? 'الكمية المطلوبة' : 'Quantity Needed'}
                </label>
                <div className="relative">
                  <Users className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#000000]/40" />
                  <select
                    name="quantity"
                    value={formData.quantity}
                    onChange={handleChange}
                    required
                    className="w-full pl-12 pr-4 py-3 bg-[#F6F6F6] border border-transparent rounded-xl text-sm text-[#000000] focus:outline-none focus:border-[#E10715] transition-colors appearance-none cursor-pointer"
                  >
                    <option value="">
                      {language === 'ar' ? 'اختر الكمية' : 'Select Quantity'}
                    </option>
                    {quantities.map((qty) => (
                      <option key={qty.en} value={qty.en}>
                        {qty.en} {language === 'ar' ? 'قطعة' : 'units'}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Message */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-[#000000]">
                {language === 'ar' ? 'تفاصيل إضافية' : 'Additional Details'}
              </label>
              <div className="relative">
                <Package className="absolute left-4 top-4 w-5 h-5 text-[#000000]/40" />
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows={5}
                  className="w-full pl-12 pr-4 py-3 bg-[#F6F6F6] border border-transparent rounded-xl text-sm text-[#000000] placeholder:text-[#000000]/40 focus:outline-none focus:border-[#E10715] transition-colors resize-none"
                  placeholder={language === 'ar' 
                    ? 'أخبرنا أكثر عن متطلباتك...' 
                    : 'Tell us more about your requirements...'}
                />
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full md:w-auto px-8 py-4 bg-[#E10715] text-white font-medium rounded-full hover:bg-[#C00612] transition-colors flex items-center justify-center gap-2"
            >
              <Send className="w-5 h-5" />
              {language === 'ar' ? 'إرسال طلب عرض السعر' : 'Submit Quote Request'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

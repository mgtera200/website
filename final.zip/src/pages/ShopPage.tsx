import { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { ArrowUpRight, Filter, ShoppingBag } from 'lucide-react';
import { productsConfig } from '@/config';
import { useLanguage } from '@/context/LanguageContext';

function ProductCard({ product, index }: { product: typeof productsConfig.products[0]; index: number }) {
  const { t, dir } = useLanguage();
  const [isVisible, setIsVisible] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setTimeout(() => setIsVisible(true), index * 100);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (cardRef.current) {
      observer.observe(cardRef.current);
    }

    return () => observer.disconnect();
  }, [index]);

  return (
    <div
      ref={cardRef}
      className={cn(
        'group cursor-pointer transition-all duration-700',
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
      )}
    >
      <Link to={`/shop/${product.id}`}>
        <div className="relative overflow-hidden bg-[#000000]/5 rounded-[20px] lg:rounded-[28px]">
          <div className="aspect-[4/5]">
            <img
              src={product.image}
              alt={t(product.name)}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
          </div>

          <div className="absolute inset-0 bg-[#000000]/0 group-hover:bg-[#000000]/20 transition-colors duration-500" />

          <div className="absolute top-3 lg:top-4 right-3 lg:right-4">
            <span className="px-2.5 lg:px-3 py-1 lg:py-1.5 text-xs font-geist-mono bg-white/90 backdrop-blur-sm rounded-full text-[#000000]">
              {t(product.category)}
            </span>
          </div>

          <div className="absolute bottom-3 lg:bottom-4 right-3 lg:right-4 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-2 group-hover:translate-y-0">
            <div className="w-8 lg:w-10 h-8 lg:h-10 bg-white rounded-full flex items-center justify-center">
              <ArrowUpRight className={cn("w-3.5 lg:w-4 h-3.5 lg:h-4 text-[#000000]", dir === 'rtl' && "rotate-90")} />
            </div>
          </div>
        </div>

        <div className="mt-3 lg:mt-4 space-y-1">
          <div className="flex items-start justify-between">
            <div>
              <h3 className="text-base lg:text-lg font-semibold text-[#000000] group-hover:text-[#E10715] transition-colors">
                {t(product.name)}
              </h3>
              <p className="text-xs lg:text-sm text-[#000000]/50">{t(product.variant)}</p>
            </div>
            <span className="text-base lg:text-lg font-semibold text-[#E10715]">
              ${product.price}
            </span>
          </div>
          <p className="text-xs lg:text-sm text-[#000000]/60 line-clamp-2">
            {t(product.description)}
          </p>
        </div>
      </Link>
    </div>
  );
}

export function ShopPage() {
  const { t, language, dir } = useLanguage();
  const config = productsConfig;
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [headerVisible, setHeaderVisible] = useState(false);

  useEffect(() => {
    setHeaderVisible(true);
  }, []);

  const categories = ['All', ...Array.from(new Set(config.products.map(p => p.category.en)))];

  const filteredProducts = selectedCategory === 'All'
    ? config.products
    : config.products.filter(p => p.category.en === selectedCategory);

  return (
    <div className="min-h-screen bg-white pt-24 lg:pt-32">
      {/* Header */}
      <div className="container-large px-5 lg:px-12 mb-10 lg:mb-16">
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6">
          <div>
            <span
              className={cn(
                'text-xs font-geist-mono uppercase tracking-widest text-[#000000]/50 transition-all duration-800',
                headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
              )}
            >
              {language === 'ar' ? 'المتجر' : 'Shop'}
            </span>
            <h1
              className={cn(
                'text-3xl sm:text-4xl lg:text-[clamp(2.5rem,6vw,5rem)] font-black text-[#000000] mt-4 tracking-[-0.04em] leading-[0.88] transition-all duration-800',
                headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              )}
              style={{ transitionDelay: '100ms' }}
            >
              {language === 'ar' ? 'مجموعة الزي الموحد' : 'UNIFORM COLLECTION'}
            </h1>
            <p
              className={cn(
                'mt-4 text-base lg:text-lg text-[#000000]/60 max-w-xl transition-all duration-800',
                headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
              )}
              style={{ transitionDelay: '200ms' }}
            >
              {t(config.description)}
            </p>
          </div>

          <div
            className={cn(
              'flex items-center gap-4 transition-all duration-800',
              headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            )}
            style={{ transitionDelay: '300ms' }}
          >
            <div className="flex items-center gap-3 px-4 lg:px-5 py-2.5 lg:py-3 bg-[#F6F6F6] rounded-full">
              <ShoppingBag className="w-4 lg:w-5 h-4 lg:h-5 text-[#000000]" />
              <span className="text-sm font-medium text-[#000000]">
                {filteredProducts.length} {language === 'ar' ? 'منتج' : 'Products'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Category Filter */}
      <div className="container-large px-5 lg:px-12 mb-8 lg:mb-10">
        <div className="flex items-center gap-2 overflow-x-auto pb-4 scrollbar-hide">
          <Filter className="w-4 h-4 text-[#000000]/40 flex-shrink-0 mr-2" />
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={cn(
                'px-4 py-2 text-sm font-medium rounded-full whitespace-nowrap transition-all',
                selectedCategory === category
                  ? 'bg-[#000000] text-white'
                  : 'bg-[#F6F6F6] text-[#000000]/70 hover:bg-[#000000]/10'
              )}
            >
              {category === 'All' 
                ? (language === 'ar' ? 'الكل' : 'All')
                : category
              }
            </button>
          ))}
        </div>
      </div>

      {/* Products Grid */}
      <div className="container-large px-5 lg:px-12 pb-20 lg:pb-24">
        <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 lg:gap-6">
          {filteredProducts.map((product, index) => (
            <ProductCard
              key={product.id}
              product={product}
              index={index}
            />
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-20">
            <p className="text-lg text-[#000000]/60">
              {language === 'ar' 
                ? 'لا توجد منتجات في هذه الفئة.' 
                : 'No products found in this category.'}
            </p>
          </div>
        )}
      </div>

      {/* CTA Section */}
      <div className="bg-[#000000] py-16 lg:py-20">
        <div className="container-large px-5 lg:px-12 text-center">
          <h2 className="text-2xl lg:text-4xl font-bold text-white mb-4">
            {language === 'ar' ? 'تحتاج زي موحد مخصص؟' : 'Need Custom Uniforms?'}
          </h2>
          <p className="text-white/60 max-w-xl mx-auto mb-8 text-sm lg:text-base">
            {language === 'ar' 
              ? 'نصمم ونصنع ملابس العمل المخصصة المصممة خصيصاً لهوية علامتك التجارية واحتياجات فريقك.'
              : 'We design and manufacture custom workwear tailored to your brand identity and team needs.'}
          </p>
          <Link
            to="/#contact"
            className="inline-flex items-center gap-2 px-6 lg:px-8 py-3 lg:py-4 bg-[#E10715] text-white font-medium rounded-full hover:bg-[#C00612] transition-colors"
          >
            {language === 'ar' ? 'اطلب عرض سعر' : 'Request a Quote'}
            <ArrowUpRight className={cn("w-4 lg:w-5 h-4 lg:h-5", dir === 'rtl' && "rotate-90")} />
          </Link>
        </div>
      </div>
    </div>
  );
}

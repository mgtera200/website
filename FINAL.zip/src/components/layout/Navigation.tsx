import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Menu, X, ShoppingBag, User, UserPlus, Globe } from 'lucide-react';
import { navigationConfig } from '@/config';
import { useLanguage } from '@/context/LanguageContext';

export function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();
  const { language, toggleLanguage, t, dir } = useLanguage();

  // Pages with light backgrounds where nav should always be dark
  const lightBgPages = ['/shop', '/products', '/product'];
  const isLightBgPage = lightBgPages.some(page => 
    location.pathname === page || location.pathname.startsWith(page + '/')
  );

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  const isActive = (href: string) => {
    if (href.startsWith('#')) {
      return location.pathname === '/' && location.hash === href;
    }
    return location.pathname === href;
  };

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    if (href.startsWith('#')) {
      e.preventDefault();
      const hash = href.replace('#', '');
      if (location.pathname === '/') {
        const element = document.getElementById(hash);
        if (element) {
          element.scrollIntoView({ behavior: 'smooth' });
        }
      } else {
        window.location.hash = `/#${hash}`;
      }
    }
  };

  // Determine if nav should show dark text
  const isDark = isLightBgPage || isScrolled;

  return (
    <>
      <nav
        className={cn(
          'fixed top-0 left-0 right-0 z-50 transition-all duration-500',
          isDark
            ? 'bg-white/95 backdrop-blur-md shadow-sm'
            : 'bg-transparent'
        )}
        dir={dir}
      >
        <div className="container-large px-4 sm:px-6 lg:px-12">
          <div className="flex items-center justify-between h-20 lg:h-24">
            {/* Logo */}
            <Link to="/" className="flex items-center">
              <img 
                src={navigationConfig.logo} 
                alt="TERA UNIFORMS" 
                className="h-14 sm:h-16 lg:h-20 w-auto"
              />
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-8">
              {navigationConfig.links.map((link) => (
                <Link
                  key={link.label.en}
                  to={link.href.startsWith('#') ? '/' : link.href}
                  onClick={(e) => handleNavClick(e, link.href)}
                  className={cn(
                    'text-sm font-medium transition-colors relative',
                    isDark
                      ? 'text-[#000000]/70 hover:text-[#000000]'
                      : 'text-white/80 hover:text-white',
                    isActive(link.href) && 'text-[#E10715]'
                  )}
                >
                  {t(link.label)}
                  {isActive(link.href) && (
                    <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-[#E10715]" />
                  )}
                </Link>
              ))}
            </div>

            {/* Right Side Actions */}
            <div className="flex items-center gap-2 lg:gap-4">
              {/* Language Switcher */}
              <button
                onClick={toggleLanguage}
                className={cn(
                  'flex items-center gap-1.5 px-2 py-1.5 rounded-lg text-sm font-medium transition-colors',
                  isDark
                    ? 'text-[#000000]/70 hover:text-[#000000] hover:bg-[#000000]/5'
                    : 'text-white/80 hover:text-white hover:bg-white/10'
                )}
                aria-label="Toggle language"
              >
                <Globe className="w-4 h-4" />
                <span className="uppercase">{language}</span>
              </button>

              {/* Shop Link */}
              <Link
                to="/shop"
                className={cn(
                  'hidden sm:flex items-center gap-1.5 text-sm font-medium transition-colors',
                  isDark
                    ? 'text-[#000000]/70 hover:text-[#000000]'
                    : 'text-white/80 hover:text-white'
                )}
              >
                <ShoppingBag className="w-4 h-4" />
                <span>{language === 'ar' ? 'المتجر' : 'Shop'}</span>
              </Link>

              {/* Login Button */}
              <button
                className={cn(
                  'hidden lg:flex items-center gap-1.5 px-3 py-2 text-sm font-medium rounded-full transition-colors border',
                  isDark
                    ? 'text-[#000000]/70 hover:text-[#000000] border-[#000000]/20 hover:border-[#000000]/40'
                    : 'text-white/80 hover:text-white border-white/30 hover:border-white/50'
                )}
                onClick={() => alert('Login functionality will be connected to WordPress')}
              >
                <User className="w-4 h-4" />
                <span>{t(navigationConfig.loginLabel)}</span>
              </button>

              {/* Register Button */}
              <button
                className={cn(
                  'hidden lg:flex items-center gap-1.5 px-3 py-2 text-sm font-medium rounded-full transition-colors',
                  isDark
                    ? 'bg-[#E10715] text-white hover:bg-[#C00612]'
                    : 'bg-white/20 text-white hover:bg-white/30 backdrop-blur-sm'
                )}
                onClick={() => alert('Register functionality will be connected to WordPress')}
              >
                <UserPlus className="w-4 h-4" />
                <span>{t(navigationConfig.registerLabel)}</span>
              </button>

              {/* CTA Button */}
              <Link
                to={navigationConfig.contactHref}
                className="hidden lg:inline-flex items-center gap-2 px-4 lg:px-5 py-2 lg:py-2.5 bg-[#E10715] text-white text-sm font-medium rounded-full hover:bg-[#C00612] transition-colors"
              >
                {t(navigationConfig.contactLabel)}
              </Link>

              {/* Mobile Menu Button */}
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className={cn(
                  'lg:hidden p-2 rounded-lg transition-colors',
                  isDark
                    ? 'text-[#000000] hover:bg-[#000000]/5'
                    : 'text-white hover:bg-white/10'
                )}
                aria-label="Toggle menu"
              >
                {isMobileMenuOpen ? (
                  <X className="w-5 h-5 sm:w-6 sm:h-6" />
                ) : (
                  <Menu className="w-5 h-5 sm:w-6 sm:h-6" />
                )}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      <div
        className={cn(
          'fixed inset-0 z-40 lg:hidden transition-all duration-500',
          isMobileMenuOpen
            ? 'opacity-100 pointer-events-auto'
            : 'opacity-0 pointer-events-none'
        )}
        dir={dir}
      >
        {/* Backdrop */}
        <div
          className="absolute inset-0 bg-[#000000]/80 backdrop-blur-sm"
          onClick={() => setIsMobileMenuOpen(false)}
        />

        {/* Menu Panel */}
        <div
          className={cn(
            'absolute top-0 h-full bg-white shadow-2xl transition-transform duration-500 w-full max-w-xs',
            dir === 'rtl' ? 'left-0' : 'right-0',
            isMobileMenuOpen ? 'translate-x-0' : dir === 'rtl' ? '-translate-x-full' : 'translate-x-full'
          )}
        >
          <div className="flex flex-col h-full p-5 pt-24">
            {/* Mobile Nav Links */}
            <div className="flex-1 space-y-1">
              {navigationConfig.links.map((link) => (
                <Link
                  key={link.label.en}
                  to={link.href.startsWith('#') ? '/' : link.href}
                  onClick={(e) => handleNavClick(e, link.href)}
                  className={cn(
                    'block py-3 px-4 text-base font-medium rounded-xl transition-colors',
                    isActive(link.href)
                      ? 'bg-[#E10715]/10 text-[#E10715]'
                      : 'text-[#000000] hover:bg-[#000000]/5'
                  )}
                >
                  {t(link.label)}
                </Link>
              ))}

              <Link
                to="/shop"
                className={cn(
                  'flex items-center gap-3 py-3 px-4 text-base font-medium rounded-xl transition-colors',
                  location.pathname === '/shop'
                    ? 'bg-[#E10715]/10 text-[#E10715]'
                    : 'text-[#000000] hover:bg-[#000000]/5'
                )}
              >
                <ShoppingBag className="w-5 h-5" />
                {language === 'ar' ? 'المتجر' : 'Shop'}
              </Link>

              {/* Mobile Login/Register */}
              <div className="pt-4 border-t border-[#000000]/10 space-y-2">
                <button
                  className="flex w-full items-center gap-3 py-3 px-4 text-base font-medium rounded-xl transition-colors text-[#000000] hover:bg-[#000000]/5"
                  onClick={() => {
                    alert('Login functionality will be connected to WordPress');
                    setIsMobileMenuOpen(false);
                  }}
                >
                  <User className="w-5 h-5" />
                  {t(navigationConfig.loginLabel)}
                </button>
                <button
                  className="flex w-full items-center gap-3 py-3 px-4 text-base font-medium rounded-xl transition-colors text-[#000000] hover:bg-[#000000]/5"
                  onClick={() => {
                    alert('Register functionality will be connected to WordPress');
                    setIsMobileMenuOpen(false);
                  }}
                >
                  <UserPlus className="w-5 h-5" />
                  {t(navigationConfig.registerLabel)}
                </button>
              </div>
            </div>

            {/* Mobile CTA */}
            <div className="pt-5 border-t border-[#000000]/10">
              <Link
                to={navigationConfig.contactHref}
                className="flex items-center justify-center gap-2 w-full py-3.5 bg-[#E10715] text-white font-medium rounded-full hover:bg-[#C00612] transition-colors"
              >
                {t(navigationConfig.contactLabel)}
              </Link>
            </div>

            {/* Language Switcher Mobile */}
            <div className="pt-4">
              <button
                onClick={toggleLanguage}
                className="flex w-full items-center justify-center gap-2 py-3 border border-[#000000]/20 rounded-full text-[#000000] font-medium"
              >
                <Globe className="w-4 h-4" />
                {language === 'en' ? 'العربية' : 'English'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

// Bilingual Site Configuration
// TERA Uniforms - Professional Workwear Solutions

export type Language = 'en' | 'ar';

export interface SiteConfig {
  languages: Language[];
  defaultLanguage: Language;
  title: Record<Language, string>;
  description: Record<Language, string>;
}

export const siteConfig: SiteConfig = {
  languages: ['en', 'ar'],
  defaultLanguage: 'en',
  title: {
    en: "TERA Uniforms | Industrial Workwear Solutions",
    ar: "تيرا للزي الموحد | حلول ملابس العمل الصناعية"
  },
  description: {
    en: "Premium industrial workwear for oil & gas, construction, and manufacturing teams. High-visibility safety gear, coveralls, and protective clothing built for demanding environments.",
    ar: "ملابس عمل صناعية متميزة لفرق النفط والغاز والإنشاءات والتصنيع. معدات أمان عالية الوضوح وأوفرول وملابس وقائية مصممة للبيئات الصعبة."
  },
};

// Navigation configuration
export interface NavLink {
  label: Record<Language, string>;
  href: string;
}

export interface NavigationConfig {
  logo: string;
  links: NavLink[];
  contactLabel: Record<Language, string>;
  contactHref: string;
  loginLabel: Record<Language, string>;
  registerLabel: Record<Language, string>;
}

export const navigationConfig: NavigationConfig = {
  logo: "/images/logo.png",
  links: [
    { label: { en: "Work", ar: "أعمالنا" }, href: "#portfolio" },
    { label: { en: "Services", ar: "خدماتنا" }, href: "#services" },
    { label: { en: "Products", ar: "المنتجات" }, href: "#products" },
    { label: { en: "Contact", ar: "اتصل بنا" }, href: "#contact" },
  ],
  contactLabel: {
    en: "Request a Quote",
    ar: "اطلب عرض سعر"
  },
  contactHref: "/quote",
  loginLabel: {
    en: "Login",
    ar: "تسجيل الدخول"
  },
  registerLabel: {
    en: "Register",
    ar: "التسجيل"
  },
};

// Hero section configuration
export interface HeroConfig {
  name: Record<Language, string>;
  roles: Record<Language, string[]>;
  backgroundImage: string;
  featuredProduct: {
    label: Record<Language, string>;
    name: Record<Language, string>;
    image: string;
    cta: Record<Language, string>;
  };
  microcopy: {
    text: Record<Language, string>;
    badge: Record<Language, string>;
  };
}

export const heroConfig: HeroConfig = {
  name: {
    en: "INDUSTRIAL / SAFETY / WORKWEAR",
    ar: "ملابس / العمل / الصناعية"
  },
  roles: {
    en: ["Oil & Gas", "Construction", "Manufacturing"],
    ar: ["النفط والغاز", "الإنشاءات", "التصنيع"]
  },
  backgroundImage: "/images/custom.png",
  featuredProduct: {
    label: {
      en: "FEATURED PRODUCT",
      ar: "المنتج المميز"
    },
    name: {
      en: "High-Visibility Safety Set — Orange/Black",
      ar: "طقم الأمان عالي الوضوح — برتقالي/أسود"
    },
    image: "/images/custom2.png",
    cta: {
      en: "Shop the set",
      ar: "تسوق الطقم"
    },
  },
  microcopy: {
    text: {
      en: "Premium industrial workwear engineered for safety, durability, and comfort in the world's toughest work environments.",
      ar: "ملابس عمل صناعية متميزة مصممة للأمان والمتانة والراحة في أقسى بيئات العمل في العالم."
    },
    badge: {
      en: "OIL & GAS CERTIFIED",
      ar: "معتمد للنفط والغاز"
    },
  },
};

// About section configuration
export interface AboutStat {
  value: string;
  label: Record<Language, string>;
}

export interface AboutImage {
  src: string;
  alt: Record<Language, string>;
}

export interface AboutConfig {
  label: Record<Language, string>;
  description: Record<Language, string>;
  experienceValue: string;
  experienceLabel: Record<Language, string>;
  stats: AboutStat[];
  images: AboutImage[];
}

export const aboutConfig: AboutConfig = {
  label: {
    en: "About",
    ar: "من نحن"
  },
  description: {
    en: "TERA is a leading manufacturer of industrial workwear and safety clothing. We specialize in high-visibility garments, flame-resistant fabrics, and durable workwear for oil & gas, construction, and manufacturing sectors across the Middle East and beyond.",
    ar: "تيرا هي شركة رائدة في تصنيع الملابس الصناعية وملابس الأمان. نحن متخصصون في الملابس عالية الوضوح، والأقمشة المقاومة للهب، والملابس الصناعية المتينة لقطاعات النفط والغاز والإنشاءات والتصنيع في الشرق الأوسط وما وراءه."
  },
  experienceValue: "12+",
  experienceLabel: {
    en: "Years of\nExperience",
    ar: "سنوات\nمن الخبرة"
  },
  stats: [
    { value: "50K+", label: { en: "Units Produced", ar: "قطعة منتجة" } },
    { value: "180+", label: { en: "Corporate Clients", ar: "عميل مؤسسي" } },
    { value: "24–48h", label: { en: "Sample turnaround", ar: " turnaround العينات" } },
  ],
  images: [
    { src: "/images/studio-portrait.jpg", alt: { en: "TERA Factory", ar: "مصنع تيرا" } },
  ],
};

// Services section configuration
export interface ServiceItem {
  iconName: string;
  title: Record<Language, string>;
  description: Record<Language, string>;
  image: string;
}

export interface ServicesConfig {
  label: Record<Language, string>;
  heading: Record<Language, string>;
  services: ServiceItem[];
  backgroundImage: string;
}

export const servicesConfig: ServicesConfig = {
  label: {
    en: "Services",
    ar: "خدماتنا"
  },
  heading: {
    en: "DESIGN / MANUFACTURING / DELIVERY",
    ar: "تصميم / تصنيع / توصيل"
  },
  backgroundImage: "/images/capabilities-bg.jpg",
  services: [
    {
      iconName: "Shield",
      title: {
        en: "Safety Compliance",
        ar: "الامتثال للأمان"
      },
      description: {
        en: "Certified high-visibility and flame-resistant workwear meeting international safety standards for hazardous environments.",
        ar: "ملابس عمل معتمدة عالية الوضوح ومقاومة للهب تلبي معايير الأمان الدولية للبيئات الخطرة."
      },
      image: "/images/portfolio-01.jpg",
    },
    {
      iconName: "Factory",
      title: {
        en: "Bulk Manufacturing",
        ar: "التصنيع بالجملة"
      },
      description: {
        en: "Large-scale production capabilities with consistent quality control for corporate and industrial uniform programs.",
        ar: "قدرات إنتاج واسعة النطاق مع مراقبة جودة متسقة لبرامج الزي الموحد المؤسسي والصناعي."
      },
      image: "/images/portfolio-02.jpg",
    },
    {
      iconName: "Palette",
      title: {
        en: "Customization",
        ar: "التخصيص"
      },
      description: {
        en: "Logo embroidery, custom colors, reflective patterns, and fabric modifications tailored to your brand requirements.",
        ar: "تطريز الشعار، والألوان المخصصة، وأنماط العاكس، وتعديلات الأقمشة حسب متطلبات علامتك التجارية."
      },
      image: "/images/portfolio-03.jpg",
    },
  ],
};

// Process section configuration
export interface ProcessStep {
  number: string;
  title: Record<Language, string>;
  description: Record<Language, string>;
}

export interface ProcessConfig {
  label: Record<Language, string>;
  heading: Record<Language, string>;
  steps: ProcessStep[];
  backgroundImage: string;
}

export const processConfig: ProcessConfig = {
  label: {
    en: "Process",
    ar: "العملية"
  },
  heading: {
    en: "OUR / PROCESS",
    ar: "عمليتنا"
  },
  backgroundImage: "/images/process-bg.jpg",
  steps: [
    {
      number: "01",
      title: {
        en: "Consultation",
        ar: "الاستشارة"
      },
      description: {
        en: "We assess your industry requirements, safety standards, and branding needs.",
        ar: "نقيم متطلبات صناعتك ومعايير الأمان واحتياجات العلامة التجارية."
      },
    },
    {
      number: "02",
      title: {
        en: "Design",
        ar: "التصميم"
      },
      description: {
        en: "Custom patterns, fabric selection, and reflective tape placement for optimal safety.",
        ar: "أنماط مخصصة، واختيار الأقمشة، ووضع الأشرطة العاكسة للأمان الأمثل."
      },
    },
    {
      number: "03",
      title: {
        en: "Sampling",
        ar: "العينات"
      },
      description: {
        en: "Prototype production and wear-testing to ensure fit, comfort, and durability.",
        ar: "إنتاج النماذج الأولية واختبار الارتداء لضمان الملاءمة والراحة والمتانة."
      },
    },
    {
      number: "04",
      title: {
        en: "Production",
        ar: "الإنتاج"
      },
      description: {
        en: "Full-scale manufacturing with quality control and on-time delivery.",
        ar: "التصنيع على نطاق واسع مع مراقبة الجودة والتسليم في الوقت المحدد."
      },
    },
  ],
};

// Products section configuration
export interface ProductItem {
  id: string;
  name: Record<Language, string>;
  variant: Record<Language, string>;
  price: number;
  category: Record<Language, string>;
  image: string;
  featured?: boolean;
  description: Record<Language, string>;
}

export interface ProductsConfig {
  label: Record<Language, string>;
  heading: Record<Language, string>;
  description: Record<Language, string>;
  products: ProductItem[];
  viewAllLabel: Record<Language, string>;
  shopNowLabel: Record<Language, string>;
}

// Standardized 6 Categories:
// 1. Coveralls - Full body protective suits
// 2. Overalls - Two-piece workwear sets
// 3. Hospitality - Service industry uniforms
// 4. Jackets - Safety jackets and outerwear
// 5. Farm Wear - Agricultural workwear
// 6. Vests - High-visibility safety vests

export const productsConfig: ProductsConfig = {
  label: {
    en: "Products",
    ar: "المنتجات"
  },
  heading: {
    en: "INDUSTRIAL / WORKWEAR",
    ar: "ملابس / العمل الصناعية"
  },
  description: {
    en: "High-visibility safety gear, coveralls, and protective workwear engineered for oil & gas, construction, and industrial operations.",
    ar: "معدات أمان عالية الوضوح، وأوفرول، وملابس عمل وقائية مصممة لعمليات النفط والغاز والإنشاءات والصناعة."
  },
  viewAllLabel: {
    en: "View All Products",
    ar: "عرض جميع المنتجات"
  },
  shopNowLabel: {
    en: "Shop Now",
    ar: "تسوق الآن"
  },
  products: [
    {
      id: 'tera-mc301',
      name: {
        en: 'Automotive Mechanic Coverall',
        ar: 'أوفرول ميكانيكي السيارات'
      },
      variant: {
        en: 'Royal Blue',
        ar: 'أزرق ملكي'
      },
      price: 189,
      category: {
        en: 'Coveralls',
        ar: 'أوفرول'
      },
      image: '/images/products/mc301-royal-blue.jpg',
      featured: true,
      description: {
        en: 'Engineered for technicians with snap-button closure, reinforced stitching, and elasticized waist for demanding workshop conditions.',
        ar: 'مصمم للفنيين بإغلاق أزرار ضغط، وخياطة معززة، وخصر مرن لظروف الورشة الصعبة.'
      },
    },
    {
      id: 'tera-cw501',
      name: {
        en: 'Navy Industrial Reflective Coverall',
        ar: 'أوفرول صناعي عاكس كحلي'
      },
      variant: {
        en: 'Navy Blue',
        ar: 'كحلي'
      },
      price: 249,
      category: {
        en: 'Coveralls',
        ar: 'أوفرول'
      },
      image: '/images/products/cw501-navy.jpg',
      featured: false,
      description: {
        en: 'Full-body coverall with high-visibility reflective tapes, multi-pocket design, and reinforced stitching for oil & gas operations.',
        ar: 'أوفرول كامل الجسم بأشرطة عاكسة عالية الوضوح، تصميم متعدد الجيوب، وخياطة معززة لعمليات النفط والغاز.'
      },
    },
    {
      id: 'tera-cw401',
      name: {
        en: 'High-Visibility Industrial Safety Coverall',
        ar: 'أوفرول أمان صناعي عالي الوضوح'
      },
      variant: {
        en: 'High-Vis Orange',
        ar: 'برتقالي عالي الوضوح'
      },
      price: 269,
      category: {
        en: 'Coveralls',
        ar: 'أوفرول'
      },
      image: '/images/products/cw401-orange.jpg',
      featured: false,
      description: {
        en: 'Maximum protection coverall with 360° reflective tape, reinforced knees, and ergonomic design for construction and marine operations.',
        ar: 'أوفرول حماية قصوى بشريط عاكس 360 درجة، ركبتان معززتان، وتصميم مريح للإنشاءات والعمليات البحرية.'
      },
    },
    {
      id: 'tera-hv901',
      name: {
        en: 'High-Visibility Safety Jacket & Trousers Set',
        ar: 'طقم جاكيت وبنطلون أمان عالي الوضوح'
      },
      variant: {
        en: 'Orange/Black',
        ar: 'برتقالي/أسود'
      },
      price: 329,
      category: {
        en: 'Overalls',
        ar: 'أوفرول'
      },
      image: '/images/products/hv901-orange-set.jpg',
      featured: true,
      description: {
        en: 'Complete safety set with fluorescent orange body, 2" reflective tapes, and weather-resistant construction for hazardous environments.',
        ar: 'طقم أمان كامل بجسم برتقالي فلوري، أشرطة عاكسة 2 بوصة، وبناء مقاوم للطقس للبيئات الخطرة.'
      },
    },
    {
      id: 'tera-workwear-set',
      name: {
        en: 'Industrial Workwear Set – Jacket & Trousers',
        ar: 'طقم ملابس العمل الصناعية – جاكيت وبنطلون'
      },
      variant: {
        en: 'Navy Blue',
        ar: 'كحلي'
      },
      price: 279,
      category: {
        en: 'Overalls',
        ar: 'أوفرول'
      },
      image: '/images/products/workwear-set-navy.jpg',
      featured: false,
      description: {
        en: 'Complete two-piece suit with reflective safety tapes, full zip jacket, cargo pockets, and elastic waist for oil & gas and factory work.',
        ar: 'طقم قطعتين كامل بأشرطة أمان عاكسة، جاكيت بسحاب كامل، جيوب كارجو، وخصر مرن للعمل في النفط والغاز والمصانع.'
      },
    },
    {
      id: 'tera-jk1201',
      name: {
        en: 'High-Visibility Neon Yellow Safety Jacket',
        ar: 'جاكيت أمان أصفر نيون عالي الوضوح'
      },
      variant: {
        en: 'Neon Yellow/Navy',
        ar: 'أصفر نيون/كحلي'
      },
      price: 189,
      category: {
        en: 'Jackets',
        ar: 'جاكيتات'
      },
      image: '/images/products/jk1201-neon.jpg',
      featured: false,
      description: {
        en: 'Maximum visibility jacket with 360° reflective tape, heavy-duty zipper, and multi-pocket design for night shift operations.',
        ar: 'جاكيت وضوح قصوى بشريط عاكس 360 درجة، سحاب ثقيل، وتصميم متعدد الجيوب لعمليات الوردية الليلية.'
      },
    },
    {
      id: 'tera-jk1101',
      name: {
        en: 'High-Visibility Yellow/Navy Safety Jacket',
        ar: 'جاكيت أمان أصفر/كحلي عالي الوضوح'
      },
      variant: {
        en: 'Yellow/Navy',
        ar: 'أصفر/كحلي'
      },
      price: 179,
      category: {
        en: 'Jackets',
        ar: 'جاكيتات'
      },
      image: '/images/products/jk1101-yellow-navy.jpg',
      featured: false,
      description: {
        en: 'Fluorescent yellow upper with navy lower panels, silver reflective tapes, and reinforced seams for refinery and power plant operations.',
        ar: 'جزء علوي أصفر فلوري مع ألواح كحلي سفلية، أشرطة عاكسة فضية، وخياطة معززة لعمليات المصافي ومحطات الطاقة.'
      },
    },
    {
      id: 'tera-jk901',
      name: {
        en: 'Navy Industrial Reflective Safety Jacket',
        ar: 'جاكيت أمان صناعي عاكس كحلي'
      },
      variant: {
        en: 'Navy Blue',
        ar: 'كحلي'
      },
      price: 169,
      category: {
        en: 'Jackets',
        ar: 'جاكيتات'
      },
      image: '/images/products/jk901-navy.jpg',
      featured: false,
      description: {
        en: 'Button-front jacket with 360° industrial-grade reflective tapes, chest flap pockets, and adjustable cuffs for field engineers.',
        ar: 'جاكيت بأزرار أمامية بأشرطة عاكسة صناعية 360 درجة، جيوب صدرية بأغطية، وأصفاد قابلة للتعديل للمهندسين الميدانيين.'
      },
    },
    {
      id: 'tera-jk801',
      name: {
        en: 'High-Visibility Orange/Navy Safety Jacket',
        ar: 'جاكيت أمان برتقالي/كحلي عالي الوضوح'
      },
      variant: {
        en: 'Orange/Navy',
        ar: 'برتقالي/كحلي'
      },
      price: 189,
      category: {
        en: 'Jackets',
        ar: 'جاكيتات'
      },
      image: '/images/products/jk801-orange-navy.jpg',
      featured: false,
      description: {
        en: 'Fluorescent orange upper with navy contrast, heavy-duty zipper with storm flap, and 2" silver reflective tape for night-shift crews.',
        ar: 'جزء علوي برتقالي فلوري مع تباين كحلي، سحاب ثقيل مع غطاء عاصفة، وشريط عاكس فضي 2 بوصة لطواقم الوردية الليلية.'
      },
    },
    {
      id: 'tera-jk701',
      name: {
        en: 'Navy Industrial Reflective Jacket – Dual Stripes',
        ar: 'جاكيت صناعي عاكس كحلي – خطوط مزدوجة'
      },
      variant: {
        en: 'Navy Blue',
        ar: 'كحلي'
      },
      price: 159,
      category: {
        en: 'Jackets',
        ar: 'جاكيتات'
      },
      image: '/images/products/jk701-navy-dual.jpg',
      featured: false,
      description: {
        en: 'Dual-color reflective tape design with silver and fluorescent yellow stripes, button-up closure for manufacturing professionals.',
        ar: 'تصميم شريط عاكس ثنائي اللون بخطوط فضية وصفراء فلورية، إغلاق بأزرار لمحترفي التصنيع.'
      },
    },
    {
      id: 'tera-jk601',
      name: {
        en: 'Navy Blue Industrial Reflective Safety Jacket',
        ar: 'جاكيت أمان صناعي عاكس أزرق كحلي'
      },
      variant: {
        en: 'Navy Blue',
        ar: 'أزرق كحلي'
      },
      price: 149,
      category: {
        en: 'Jackets',
        ar: 'جاكيتات'
      },
      image: '/images/products/jk601-navy.jpg',
      featured: false,
      description: {
        en: 'Lightweight jacket with 360° visibility, button-up front, dual chest pockets for renewable energy and field inspection teams.',
        ar: 'جاكيت خفيف الوزن بوضوح 360 درجة، إغلاق أمامي بأزرار، وجيوب صدرية مزدوجة لفرق الطاقة المتجددة والتفتيش الميداني.'
      },
    },
    // NEW PRODUCTS ADDED FROM DESCRIPTION FILES
    {
      id: 'tera-fw401',
      name: {
        en: 'Professional Farm & Livestock Work Overalls',
        ar: 'أوفرول عمل المزارع والمواشي المهني'
      },
      variant: {
        en: 'Grey with Red Panels',
        ar: 'رمادي مع ألواح حمراء'
      },
      price: 229,
      category: {
        en: 'Farm Wear',
        ar: 'ملابس المزارع'
      },
      image: '/images/products/fw401-grey-red.jpg',
      featured: false,
      description: {
        en: 'Heavy-duty 100% cotton overalls for cattle farms and livestock handling. Features reinforced knees, multi-pocket design, and triple-stitched seams for demanding agricultural environments.',
        ar: 'أوفرول قطني ثقيل 100% لمزارع المواشي والتعامل مع الحيوانات. يتميز بركبتين معززتين، تصميم متعدد الجيوب، وخياطة ثلاثية للبيئات الزراعية الصعبة.'
      },
    },
    {
      id: 'tera-fw702',
      name: {
        en: 'Professional Agriculture & Farm Work Overalls',
        ar: 'أوفرول العمل الزراعي المهني'
      },
      variant: {
        en: 'Navy Blue',
        ar: 'كحلي'
      },
      price: 239,
      category: {
        en: 'Farm Wear',
        ar: 'ملابس المزارع'
      },
      image: '/images/products/fw702-navy.jpg',
      featured: false,
      description: {
        en: 'Durable cotton twill overalls designed for dairy workers and agricultural operations. Adjustable straps, relaxed fit, and reinforced stitching for all-day comfort in the field.',
        ar: 'أوفرول قطني متين مصمم لعمال الألبان والعمليات الزراعية. أشرطة قابلة للتعديل، قصة مريحة، وخياطة معززة للراحة طوال اليوم في الميدان.'
      },
    },
    {
      id: 'tera-fe402',
      name: {
        en: 'Professional Field-Engineer Work Overalls',
        ar: 'أوفرول مهندس ميداني مهني'
      },
      variant: {
        en: 'Grey with Orange Accents',
        ar: 'رمادي مع لمسات برتقالية'
      },
      price: 249,
      category: {
        en: 'Overalls',
        ar: 'أوفرول'
      },
      image: '/images/products/fe402-grey-orange.jpg',
      featured: false,
      description: {
        en: 'Engineered for solar farms and electrical installations. Breathable cotton twill with safety orange accents, multi-functional pockets, and ergonomic design for technical fieldwork.',
        ar: 'مصمم لمزارع الطاقة الشمسية والتركيبات الكهربائية. قطن متين قابل للتنفس مع لمسات برتقالية للأمان، جيوب متعددة الوظائف، وتصميم مريح للعمل الميداني التقني.'
      },
    },
    {
      id: 'tera-bo301',
      name: {
        en: 'Royal Blue Mechanic Bib Overall',
        ar: 'أوفرول ميكانيكي أزرق ملكي'
      },
      variant: {
        en: 'Royal Blue',
        ar: 'أزرق ملكي'
      },
      price: 199,
      category: {
        en: 'Overalls',
        ar: 'أوفرول'
      },
      image: '/images/products/bo301-royal-blue.jpg',
      featured: false,
      description: {
        en: 'Premium cotton bib overall for automotive workshops. Features front bib pocket, deep side pockets, and reinforced stress points for mechanical maintenance tasks.',
        ar: 'أوفرول قطني ممتاز للورش الميكانيكية. يتميز بجيب أمامي على الصدر، جيوب جانبية عميقة، ونقاط ضغط معززة لمهام الصيانة الميكانيكية.'
      },
    },
    {
      id: 'tera-aw301',
      name: {
        en: 'Professional Auto-Mechanic Work Overalls',
        ar: 'أوفرول ميكانيكي سيارات مهني'
      },
      variant: {
        en: 'Royal Blue',
        ar: 'أزرق ملكي'
      },
      price: 209,
      category: {
        en: 'Coveralls',
        ar: 'أوفرول'
      },
      image: '/images/products/aw301-royal-blue.jpg',
      featured: false,
      description: {
        en: 'Heavy-duty cotton twill overalls for tire service centers and repair shops. Ergonomic bib design with reinforced seams and multi-pocket functionality for automotive professionals.',
        ar: 'أوفرول قطني ثقيل لمراكز خدمة الإطارات ومحلات الإصلاح. تصميم مريح مع خياطة معززة ووظائف متعددة الجيوب لمحترفي السيارات.'
      },
    },
    {
      id: 'tera-hv201',
      name: {
        en: 'High-Visibility Mesh Safety Vest',
        ar: 'سترة أمان شبكية عالية الوضوح'
      },
      variant: {
        en: 'Hi-Vis Yellow/Navy',
        ar: 'أصفر عالي الوضوح/كحلي'
      },
      price: 89,
      category: {
        en: 'Vests',
        ar: 'سترات'
      },
      image: '/images/products/hv201-yellow-navy.jpg',
      featured: false,
      description: {
        en: 'Breathable polyester mesh vest with 2" silver reflective tape. Multi-pocket design including utility pockets and pen holders for construction and railway workers.',
        ar: 'سترة شبكية بوليستر قابلة للتنفس مع شريط عاكس فضي 2 بوصة. تصميم متعدد الجيوب يشمل جيوب أدوات وحوامل أقلام لعمال الإنشاء والسكك الحديدية.'
      },
    },
    {
      id: 'tera-hv401',
      name: {
        en: 'High-Visibility Safety Vest',
        ar: 'سترة أمان عالية الوضوح'
      },
      variant: {
        en: 'Hi-Vis Orange',
        ar: 'برتقالي عالي الوضوح'
      },
      price: 79,
      category: {
        en: 'Vests',
        ar: 'سترات'
      },
      image: '/images/products/hv401-orange.jpg',
      featured: false,
      description: {
        en: 'Lightweight polyester mesh vest with 360° reflective silver tapes. Available in orange or yellow with front zipper closure for maximum visibility in industrial environments.',
        ar: 'سترة شبكية بوليستر خفيفة الوزن مع أشرطة عاكسة فضية 360 درجة. متوفرة بالبرتقالي أو الأصفر مع إغلاق سحاب أمامي لوضوح قصوى في البيئات الصناعية.'
      },
    },
  ],
};

// Portfolio section configuration
export interface PortfolioCTA {
  label: Record<Language, string>;
  heading: Record<Language, string>;
  linkText: Record<Language, string>;
  linkHref: string;
}

export interface PortfolioConfig {
  label: Record<Language, string>;
  heading: Record<Language, string>;
  description: Record<Language, string>;
  cta: PortfolioCTA;
  viewAllLabel: Record<Language, string>;
}

export const portfolioConfig: PortfolioConfig = {
  label: {
    en: "Portfolio",
    ar: "أعمالنا"
  },
  heading: {
    en: "TRUSTED / BY INDUSTRY LEADERS",
    ar: "موثوق / من قادة الصناعة"
  },
  description: {
    en: "Industrial workwear solutions delivered to major oil & gas, construction, and manufacturing operations across the region.",
    ar: "حلول ملابس العمل الصناعية المقدمة لعمليات النفط والغاز والإنشاءات والتصنيع الرئيسية في المنطقة."
  },
  cta: {
    label: {
      en: "Need custom workwear?",
      ar: "تحتاج ملابس عمل مخصصة؟"
    },
    heading: {
      en: "Let's build your safety uniform program",
      ar: "لنبني برنامج الزي الأمان الخاص بك"
    },
    linkText: {
      en: "Start a project",
      ar: "ابدأ مشروعاً"
    },
    linkHref: "#contact",
  },
  viewAllLabel: {
    en: "View All Projects",
    ar: "عرض جميع المشاريع"
  },
};

// Detail/Craft section configuration
export interface DetailConfig {
  label: Record<Language, string>;
  heading: Record<Language, string>;
  card: {
    label: Record<Language, string>;
    paragraph: Record<Language, string>;
    bullets: Record<Language, string[]>;
    cta: Record<Language, string>;
  };
  backgroundImage: string;
}

export const detailConfig: DetailConfig = {
  label: {
    en: "Materials",
    ar: "المواد"
  },
  heading: {
    en: "BUILT / FOR THE FIELD",
    ar: "مبني / للميدان"
  },
  backgroundImage: "/images/detail-bg.jpg",
  card: {
    label: {
      en: "FABRICS & SAFETY FEATURES",
      ar: "الأقمشة ومواصفات الأمان"
    },
    paragraph: {
      en: "We use premium cotton, poly-cotton blends, and FR fabrics with industrial-grade reflective tapes for maximum visibility and protection.",
      ar: "نستخدم القطن الممتاز، وخلطات القطن البولي، وأقمشة FR مع أشرطة عاكسة صناعية لأقصى درجات الوضوح والحماية."
    },
    bullets: {
      en: [
        "100% Cotton & Poly-Cotton options",
        "Fire-Resistant (FR) fabric available",
        "2\" Industrial-grade reflective tape",
        "Reinforced stress points & seams",
      ],
      ar: [
        "خيارات 100% قطن وقطن بولي",
        "أقمشة مقاومة للهب (FR) متاحة",
        "شريط عاكس صناعي 2 بوصة",
        "نقاط ضغط وخياطة معززة",
      ],
    },
    cta: {
      en: "Request fabric samples",
      ar: "اطلب عينات الأقمشة"
    },
  },
};

// Testimonials section configuration
export interface TestimonialItem {
  quote: Record<Language, string>;
  author: string;
  role: Record<Language, string>;
  company: string;
  image: string;
  rating: number;
}

export interface TestimonialsConfig {
  label: Record<Language, string>;
  heading: Record<Language, string>;
  testimonials: TestimonialItem[];
}

export const testimonialsConfig: TestimonialsConfig = {
  label: {
    en: "Testimonials",
    ar: "آراء العملاء"
  },
  heading: {
    en: "TRUSTED / BY FIELD TEAMS",
    ar: "موثوق / من فرق الميدان"
  },
  testimonials: [
    {
      quote: {
        en: "TERA's high-visibility jackets have significantly improved our night shift safety. The reflective quality exceeds industry standards.",
        ar: "حسنت جاكيتات تيرا عالية الوضوح بشكل كبير من أمان الوردية الليلية لدينا. جودة العاكس تتجاوز معايير الصناعة."
      },
      author: "Mohammed Al-Rashid",
      role: {
        en: "HSE Manager",
        ar: "مدير الصحة والسلامة"
      },
      company: "PetroGulf Operations",
      image: "/images/studio-portrait.jpg",
      rating: 5,
    },
    {
      quote: {
        en: "The coveralls withstand our harsh refinery conditions. 12-hour shifts and they still look professional after months of washing.",
        ar: "تحمل الأوفرول ظروف المصباة القاسية لدينا. ورديات 12 ساعة وما زالت تبدو احترافية بعد أشهر من الغسيل."
      },
      author: "Khalid Al-Farsi",
      role: {
        en: "Operations Supervisor",
        ar: "مشرف العمليات"
      },
      company: "Refinery Solutions",
      image: "/images/featured-coat.jpg",
      rating: 5,
    },
    {
      quote: {
        en: "Fast sampling, consistent quality across 500+ units, and the customization options helped reinforce our brand on site.",
        ar: "عينات سريعة، جودة متسقة عبر 500+ قطعة، وخيارات التخصيص ساعدت في تعزيز علامتنا التجارية في الموقع."
      },
      author: "Sarah Johnson",
      role: {
        en: "Procurement Director",
        ar: "مديرة المشتريات"
      },
      company: "Gulf Construction Co.",
      image: "/images/portfolio-01.jpg",
      rating: 5,
    },
  ],
};

// CTA section configuration
export interface CTAConfig {
  tags: Record<Language, string[]>;
  heading: Record<Language, string>;
  description: Record<Language, string>;
  buttonText: Record<Language, string>;
  buttonHref: string;
  email: string;
  backgroundImage: string;
}

export const ctaConfig: CTAConfig = {
  tags: {
    en: ["Bulk Orders", "Custom Design", "Safety Certified"],
    ar: ["طلبات بالجملة", "تصميم مخصص", "معتمد للأمان"]
  },
  heading: {
    en: "READY FOR / YOUR TEAM",
    ar: "جاهز / لفريقك"
  },
  description: {
    en: "Get a quote for your industrial workwear needs. We handle everything from design to delivery for teams of all sizes.",
    ar: "احصل على عرض سعر لاحتياجات ملابس العمل الصناعية الخاصة بك. نتولى كل شيء من التصميم إلى التسليم للفرق بجميع الأحجام."
  },
  buttonText: {
    en: "Request a quote",
    ar: "اطلب عرض سعر"
  },
  buttonHref: "#contact",
  email: "hello@terauniforms.com",
  backgroundImage: "/images/cta-bg.jpg",
};

// Footer section configuration
export interface FooterLinkColumn {
  title: Record<Language, string>;
  links: { label: Record<Language, string>; href: string }[];
}

export interface SocialLink {
  iconName: string;
  href: string;
  label: string;
}

export interface FooterConfig {
  logo: string;
  description: Record<Language, string>;
  columns: FooterLinkColumn[];
  socialLinks: SocialLink[];
  newsletterHeading: Record<Language, string>;
  newsletterDescription: Record<Language, string>;
  newsletterButtonText: Record<Language, string>;
  newsletterPlaceholder: Record<Language, string>;
  copyright: Record<Language, string>;
  credit: Record<Language, string>;
  contactInfo: {
    email: string;
    phone: string;
    hours: Record<Language, string>;
  };
}

export const footerConfig: FooterConfig = {
  logo: "/images/logo.png",
  description: {
    en: "Industrial workwear manufacturer specializing in high-visibility safety gear, coveralls, and protective clothing for demanding work environments.",
    ar: "مصنع ملابس العمل الصناعية المتخصص في معدات الأمان عالية الوضوح، والأوفرول، والملابس الواقية لبيئات العمل الصعبة."
  },
  columns: [
    {
      title: {
        en: "Products",
        ar: "المنتجات"
      },
      links: [
        { label: { en: "Coveralls", ar: "أوفرول" }, href: "#products" },
        { label: { en: "Overalls", ar: "أوفرول" }, href: "#products" },
        { label: { en: "Hospitality", ar: "الضيافة" }, href: "#products" },
        { label: { en: "Jackets", ar: "جاكيتات" }, href: "#products" },
        { label: { en: "Farm Wear", ar: "ملابس المزارع" }, href: "#products" },
        { label: { en: "Vests", ar: "سترات" }, href: "#products" },
      ],
    },
    {
      title: {
        en: "Industries",
        ar: "الصناعات"
      },
      links: [
        { label: { en: "Oil & Gas", ar: "النفط والغاز" }, href: "#" },
        { label: { en: "Construction", ar: "الإنشاءات" }, href: "#" },
        { label: { en: "Manufacturing", ar: "التصنيع" }, href: "#" },
        { label: { en: "Agriculture", ar: "الزراعة" }, href: "#" },
      ],
    },
    {
      title: {
        en: "Company",
        ar: "الشركة"
      },
      links: [
        { label: { en: "About Us", ar: "من نحن" }, href: "#about" },
        { label: { en: "Our Process", ar: "عمليتنا" }, href: "#process" },
        { label: { en: "Quality Standards", ar: "معايير الجودة" }, href: "#" },
        { label: { en: "Contact", ar: "اتصل بنا" }, href: "#contact" },
      ],
    },
  ],
  socialLinks: [
    { iconName: "Instagram", href: "#", label: "Instagram" },
    { iconName: "Linkedin", href: "#", label: "LinkedIn" },
    { iconName: "Twitter", href: "#", label: "Twitter" },
  ],
  newsletterHeading: {
    en: "Stay Updated",
    ar: "ابقَ على اطلاع"
  },
  newsletterDescription: {
    en: "Get updates on new safety gear, industry compliance standards, and bulk order promotions.",
    ar: "احصل على تحديثات حول معدات الأمان الجديدة، ومعايير الامتثال الصناعي، وعروض الطلبات بالجملة."
  },
  newsletterButtonText: {
    en: "Subscribe",
    ar: "اشترك"
  },
  newsletterPlaceholder: {
    en: "Enter your email",
    ar: "أدخل بريدك الإلكتروني"
  },
  copyright: {
    en: "© 2026 TERA Uniforms. All rights reserved.",
    ar: "© 2026 تيرا للزي الموحد. جميع الحقوق محفوظة."
  },
  credit: {
    en: "Engineered for safety. Built for the field.",
    ar: "مهندس للأمان. مبني للميدان."
  },
  contactInfo: {
    email: "hello@terauniforms.com",
    phone: "+966 (11) 013-2488",
    hours: {
      en: "Sun–Thu, 8am–6pm GST",
      ar: "الأحد–الخميس، 8ص–6م بتوقيت الخليج"
    },
  },
};

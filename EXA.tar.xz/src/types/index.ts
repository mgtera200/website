// ============================================
// MERGED TYPES - V4 Design + V5 Backend
// ============================================

// User Types (from V5)
export interface User {
  id: string;
  email: string;
  first_name: string;
  last_name: string;
  phone?: string;
  avatar_url?: string;
  role: 'customer' | 'admin';
  created_at: string;
  updated_at: string;
}

export interface UserAddress {
  id: string;
  user_id: string;
  type: 'shipping' | 'billing';
  first_name: string;
  last_name: string;
  address_line1: string;
  address_line2?: string;
  city: string;
  state?: string;
  postal_code?: string;
  country: string;
  phone: string;
  is_default: boolean;
  created_at: string;
}

// Product Types (Merged V4 + V5)
export interface ProductColor {
  name: string;
  hex: string;
}

export interface Product {
  id: string;
  name: string;
  description?: string;
  price: number;
  originalPrice?: number;
  original_price?: number;
  image: string;
  images?: string[];
  category: string;
  subcategory: string;
  sizes: string[];
  colors: string[] | ProductColor[];
  isNew?: boolean;
  isSale?: boolean;
  is_new?: boolean;
  is_sale?: boolean;
  stock?: number;
  sku?: string;
  rating?: number;
  review_count?: number;
  tags?: string[];
  created_at?: string;
  updated_at?: string;
}

// Helper function to normalize color to string
export const getColorName = (color: string | ProductColor): string => {
  return typeof color === 'string' ? color : color.name;
};

export const getColorHex = (color: string | ProductColor): string => {
  if (typeof color === 'string') {
    // Map common color names to hex
    const colorMap: Record<string, string> = {
      'black': '#000000',
      'white': '#FFFFFF',
      'grey': '#808080',
      'gray': '#808080',
      'navy': '#000080',
      'blue': '#0000FF',
      'red': '#FF0000',
      'green': '#008000',
      'yellow': '#FFFF00',
      'orange': '#FFA500',
      'purple': '#800080',
      'pink': '#FFC0CB',
      'brown': '#8B4513',
      'beige': '#F5F5DC',
      'cream': '#FFFDD0',
      'charcoal': '#36454F',
      'indigo': '#4B0082',
      'khaki': '#C3B091',
      'olive': '#808000',
      'burgundy': '#800020',
      'sand': '#C2B280',
      'sage': '#9DC183',
      'tan': '#D2B48C',
    };
    return colorMap[color.toLowerCase()] || color;
  }
  return color.hex;
};

export interface ProductVariant {
  id: string;
  product_id: string;
  size: string;
  color: string;
  stock: number;
  sku: string;
}

export interface ProductReview {
  id: string;
  product_id: string;
  user_id: string;
  user_name: string;
  rating: number;
  comment: string;
  created_at: string;
}

// Cart Types (from V5)
export interface CartItem {
  id: string;
  product_id: string;
  variant_id?: string;
  name: string;
  price: number;
  quantity: number;
  size: string;
  color: string;
  image: string;
  stock: number;
}

export interface Cart {
  items: CartItem[];
  coupon_code?: string;
  discount_amount: number;
}

// Order Types (from V5)
export type OrderStatus = 'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled' | 'refunded';
export type PaymentStatus = 'pending' | 'paid' | 'failed' | 'refunded';
export type PaymentMethod = 'card' | 'wallet' | 'cod' | 'bank_transfer';

export interface Order {
  id: string;
  user_id: string;
  order_number: string;
  status: OrderStatus;
  payment_status: PaymentStatus;
  payment_method: PaymentMethod;
  payment_transaction_id?: string;
  subtotal: number;
  shipping_cost: number;
  discount_amount: number;
  tax_amount: number;
  total: number;
  currency: string;
  shipping_address: UserAddress;
  billing_address: UserAddress;
  items: OrderItem[];
  tracking_number?: string;
  tracking_url?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string;
  variant_id?: string;
  name: string;
  sku: string;
  price: number;
  quantity: number;
  size: string;
  color: string;
  image: string;
}

// Wishlist Types (from V5)
export interface WishlistItem {
  id: string;
  user_id: string;
  product_id: string;
  product: Product;
  created_at: string;
}

// Newsletter Types (from V5)
export interface NewsletterSubscriber {
  id: string;
  email: string;
  subscribed: boolean;
  created_at: string;
}

// Navigation Types (Merged)
export interface NavItem {
  label: string;
  href: string;
  children?: NavItem[];
}

// Category Types (Merged V4 + V5)
export interface Category {
  id: string;
  name: string;
  slug?: string;
  image: string;
  href: string;
  description: string;
  parent_id?: string;
  sort_order?: number;
}

// Editorial Types (from V4)
export interface EditorialArticle {
  id: string;
  title: string;
  subtitle: string;
  image: string;
  href: string;
  author?: string;
  date?: string;
  category?: string;
}

// Hero Types (from V4)
export interface HeroSlide {
  id: string;
  title: string;
  subtitle: string;
  image: string;
  cta: string;
  href: string;
}

// Search Types (from V5)
export interface SearchResult {
  products: Product[];
  categories: Category[];
  suggestions: string[];
}

// Paymob Types (from V5)
export interface PaymobConfig {
  apiKey: string;
  integrationId: number;
  iframeId: number;
}

export interface PaymobPayment {
  token: string;
  orderId: number;
  paymentKey: string;
}

// Email Types (from V5)
export interface EmailTemplate {
  to: string;
  subject: string;
  template: string;
  data: Record<string, unknown>;
}

// Filter Types (from V5)
export interface ProductFilter {
  category?: string;
  subcategory?: string;
  minPrice?: number;
  maxPrice?: number;
  sizes?: string[];
  colors?: string[];
  isSale?: boolean;
  isNew?: boolean;
  sortBy?: 'price_asc' | 'price_desc' | 'newest' | 'popular';
}

// Admin Types (from V5)
export interface DashboardStats {
  totalOrders: number;
  totalRevenue: number;
  totalCustomers: number;
  totalProducts: number;
  recentOrders: Order[];
  salesChart: { date: string; amount: number }[];
}

export interface AdminOrderUpdate {
  status?: OrderStatus;
  tracking_number?: string;
  tracking_url?: string;
  notes?: string;
}

import { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Search, User, Heart, ShoppingBag, Menu, X, LogOut, Package } from 'lucide-react';
import { navItems } from '@/data/products';
import { useCart } from '@/hooks/useCart';
import { useAuth } from '@/contexts/AuthContext';
import { useAuthStore } from '@/store/authStore';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

export function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { itemCount } = useCart();
  
  // V5 Auth integration
  const { isAuthenticated, user } = useAuth();
  const { logout } = useAuthStore();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  const isActive = (path: string) => {
    if (path === '/casual' && location.pathname === '/casual') return true;
    if (path === '/uniforms' && location.pathname === '/uniforms') return true;
    if (path === '/school' && location.pathname === '/school') return true;
    if (path === '/new-in' && location.pathname === '/new-in') return true;
    if (path === '/sale' && location.pathname === '/sale') return true;
    return false;
  };

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  // Determine text color based on scroll and page
  const getTextColor = () => {
    if (location.pathname === '/' && !isScrolled) {
      return 'text-white';
    }
    return 'text-black';
  };

  const getTextColorMuted = () => {
    if (location.pathname === '/' && !isScrolled) {
      return 'text-white/70';
    }
    return 'text-black/70';
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled || location.pathname !== '/'
            ? 'bg-white/95 backdrop-blur-md border-b border-black/10'
            : 'bg-transparent'
        }`}
      >
        <div className="w-full px-4 sm:px-6 lg:px-12">
          <div className="flex items-center justify-between h-20 lg:h-24">
            {/* Mobile Menu Button */}
            <button
              className="lg:hidden p-2 -ml-2"
              onClick={() => setIsMobileMenuOpen(true)}
              aria-label="Open menu"
            >
              <Menu className={`w-6 h-6 ${getTextColor()}`} />
            </button>

            {/* Logo - INCREASED SIZE with TRANSPARENT BACKGROUND */}
            <Link to="/" className="flex items-center">
              <img
                src="/images/logo-transparent.png"
                alt="EXA"
                className="h-12 sm:h-14 lg:h-20 w-auto object-contain"
                style={{ 
                  filter: isScrolled || location.pathname !== '/' ? 'none' : 'brightness(0) invert(1)'
                }}
              />
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center space-x-8">
              {navItems.map((item) => (
                <Link
                  key={item.label}
                  to={item.href}
                  className={`text-sm font-medium tracking-wider transition-opacity relative group ${
                    isActive(item.href) ? getTextColor() : `${getTextColorMuted()} hover:${getTextColor()}`
                  }`}
                >
                  {item.label}
                  <span className={`absolute -bottom-1 left-0 h-0.5 transition-all duration-300 group-hover:w-full ${
                    isActive(item.href) ? 'w-full bg-current' : 'w-0 bg-current'
                  }`} />
                </Link>
              ))}
            </nav>

            {/* Right Icons */}
            <div className="flex items-center space-x-2 sm:space-x-4">
              <Link
                to="/search"
                className={`p-2 hover:opacity-60 transition-opacity ${getTextColor()}`}
                aria-label="Search"
              >
                <Search className="w-5 h-5" />
              </Link>
              
              {/* User Account - V5 Auth Integration */}
              {isAuthenticated ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button 
                      className={`p-2 hover:opacity-60 transition-opacity hidden sm:block ${getTextColor()}`}
                      aria-label="Account"
                    >
                      <User className="w-5 h-5" />
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <div className="px-3 py-2">
                      <p className="text-sm font-medium">{user?.first_name} {user?.last_name}</p>
                      <p className="text-xs text-gray-500">{user?.email}</p>
                    </div>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => navigate('/account')}>
                      <User className="mr-2 h-4 w-4" />
                      My Account
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate('/account/orders')}>
                      <Package className="mr-2 h-4 w-4" />
                      My Orders
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate('/account/wishlist')}>
                      <Heart className="mr-2 h-4 w-4" />
                      Wishlist
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout}>
                      <LogOut className="mr-2 h-4 w-4" />
                      Logout
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Link
                  to="/login"
                  className={`p-2 hover:opacity-60 transition-opacity hidden sm:block ${getTextColor()}`}
                  aria-label="Account"
                >
                  <User className="w-5 h-5" />
                </Link>
              )}
              
              <Link
                to="/wishlist"
                className={`p-2 hover:opacity-60 transition-opacity hidden sm:block ${getTextColor()}`}
                aria-label="Wishlist"
              >
                <Heart className="w-5 h-5" />
              </Link>
              <Link
                to="/cart"
                className={`p-2 hover:opacity-60 transition-opacity relative ${getTextColor()}`}
                aria-label="Cart"
              >
                <ShoppingBag className="w-5 h-5" />
                {itemCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-black text-white text-[10px] flex items-center justify-center rounded-full">
                    {itemCount > 9 ? '9+' : itemCount}
                  </span>
                )}
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      <div
        className={`fixed inset-0 z-[60] bg-white transform transition-transform duration-300 lg:hidden ${
          isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Mobile Header */}
          <div className="flex items-center justify-between p-4 border-b border-black/10">
            <Link to="/" className="flex items-center">
              <img
                src="/images/logo-transparent.png"
                alt="EXA"
                className="h-12 w-auto object-contain"
              />
            </Link>
            <button
              onClick={() => setIsMobileMenuOpen(false)}
              className="p-2"
              aria-label="Close menu"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Mobile Nav Links */}
          <nav className="flex-1 overflow-auto py-8">
            <div className="px-6 space-y-6">
              {navItems.map((item) => (
                <Link
                  key={item.label}
                  to={item.href}
                  className={`block text-2xl font-medium tracking-wider ${
                    isActive(item.href) ? 'text-black' : 'text-black/60'
                  }`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {item.label}
                </Link>
              ))}
            </div>

            {/* Mobile Secondary Links */}
            <div className="mt-12 px-6 pt-8 border-t border-black/10">
              <div className="space-y-4">
                {isAuthenticated ? (
                  <>
                    <Link to="/account" className="flex items-center space-x-3 text-lg">
                      <User className="w-5 h-5" />
                      <span>My Account</span>
                    </Link>
                    <Link to="/account/orders" className="flex items-center space-x-3 text-lg">
                      <Package className="w-5 h-5" />
                      <span>My Orders</span>
                    </Link>
                  </>
                ) : (
                  <Link to="/login" className="flex items-center space-x-3 text-lg">
                    <User className="w-5 h-5" />
                    <span>Sign In</span>
                  </Link>
                )}
                <Link to="/wishlist" className="flex items-center space-x-3 text-lg">
                  <Heart className="w-5 h-5" />
                  <span>Wishlist</span>
                </Link>
                <Link to="/cart" className="flex items-center space-x-3 text-lg">
                  <ShoppingBag className="w-5 h-5" />
                  <span>Shopping Bag ({itemCount})</span>
                </Link>
              </div>
            </div>

            {/* Mobile Info Links */}
            <div className="mt-8 px-6 pt-8 border-t border-black/10">
              <div className="space-y-3">
                <Link to="/about" className="block text-sm text-black/60">About EXA</Link>
                <Link to="/size-guide" className="block text-sm text-black/60">Size Guide</Link>
                <Link to="/shipping" className="block text-sm text-black/60">Shipping Info</Link>
                <Link to="/editorial" className="block text-sm text-black/60">Editorial</Link>
              </div>
            </div>
          </nav>
        </div>
      </div>
    </>
  );
}

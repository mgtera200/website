import { useState, useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Heart, ShoppingBag, Eye } from 'lucide-react';
import { products } from '@/data/products';
import type { Product } from '@/types';
import { getColorName, getColorHex } from '@/types';

gsap.registerPlugin(ScrollTrigger);

const tabs = [
  { id: 'trending', label: 'TRENDING NOW' },
  { id: 'uniforms', label: 'UNIFORM ESSENTIALS' },
  { id: 'school', label: 'BACK TO SCHOOL' },
];

function ProductCard({ product }: { product: Product }) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className="group relative"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Image Container */}
      <div className="relative aspect-[3/4] overflow-hidden bg-neutral-100 mb-4">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />

        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-2">
          {product.isNew && (
            <span className="px-3 py-1 bg-black text-white text-xs font-medium tracking-wider">
              NEW
            </span>
          )}
          {product.isSale && (
            <span className="px-3 py-1 bg-black text-white text-xs font-medium tracking-wider">
              SALE
            </span>
          )}
        </div>

        {/* Quick Actions */}
        <div
          className={`absolute inset-x-0 bottom-0 p-4 flex justify-center gap-3 transition-all duration-300 ${
            isHovered ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          }`}
        >
          <button
            className="p-3 bg-white hover:bg-black hover:text-white transition-colors"
            aria-label="Quick view"
          >
            <Eye className="w-5 h-5" />
          </button>
          <button
            className="p-3 bg-white hover:bg-black hover:text-white transition-colors"
            aria-label="Add to wishlist"
          >
            <Heart className="w-5 h-5" />
          </button>
          <button
            className="p-3 bg-white hover:bg-black hover:text-white transition-colors"
            aria-label="Add to cart"
          >
            <ShoppingBag className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Product Info */}
      <div className="space-y-2">
        <h3 className="text-sm font-medium tracking-wide group-hover:opacity-70 transition-opacity">
          {product.name}
        </h3>
        <div className="flex items-center gap-2">
          <span className="text-sm font-semibold">${product.price}</span>
          {product.originalPrice && (
            <span className="text-sm text-black/50 line-through">
              ${product.originalPrice}
            </span>
          )}
        </div>
        {/* Color Options */}
        <div className="flex gap-1 pt-1">
          {product.colors.slice(0, 3).map((color, index) => (
            <span
              key={index}
              className="w-4 h-4 rounded-full border border-black/20"
              style={{ backgroundColor: getColorHex(color) }}
              title={getColorName(color)}
            />
          ))}
          {product.colors.length > 3 && (
            <span className="text-xs text-black/50">+{product.colors.length - 3}</span>
          )}
        </div>
      </div>
    </div>
  );
}

export function FeaturedProducts() {
  const [activeTab, setActiveTab] = useState('trending');
  const sectionRef = useRef<HTMLElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);

  const getFilteredProducts = () => {
    switch (activeTab) {
      case 'trending':
        return products.filter((p) => p.category === 'casual').slice(0, 4);
      case 'uniforms':
        return products.filter((p) => p.category === 'corporate' || p.category === 'medical').slice(0, 4);
      case 'school':
        return products.filter((p) => p.category === 'school' || p.category === 'accessories').slice(0, 4);
      default:
        return products.slice(0, 4);
    }
  };

  useEffect(() => {
    const section = sectionRef.current;
    const grid = gridRef.current;
    if (!section || !grid) return;

    const triggers: ScrollTrigger[] = [];

    const gridTrigger = ScrollTrigger.create({
      trigger: grid,
      start: 'top 80%',
      onEnter: () => {
        const cards = grid.querySelectorAll('.product-card');
        gsap.fromTo(
          cards,
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.6, stagger: 0.1, ease: 'power2.out' }
        );
      },
      once: true,
    });
    triggers.push(gridTrigger);

    return () => {
      triggers.forEach((t) => t.kill());
    };
  }, [activeTab]);

  const filteredProducts = getFilteredProducts();

  return (
    <section ref={sectionRef} className="w-full py-20 lg:py-32 bg-white">
      <div className="w-full px-4 sm:px-6 lg:px-12">
        {/* Section Header */}
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between mb-12">
          <div>
            <p className="text-sm tracking-[0.3em] text-black/60 mb-4 uppercase">
              Curated Selection
            </p>
            <h2 className="text-3xl lg:text-5xl font-bold tracking-tight">
              FEATURED PRODUCTS
            </h2>
          </div>

          {/* Tabs */}
          <div className="flex gap-6 mt-6 lg:mt-0">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`text-sm font-medium tracking-wider pb-2 border-b-2 transition-colors ${
                  activeTab === tab.id
                    ? 'border-black text-black'
                    : 'border-transparent text-black/50 hover:text-black'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Products Grid */}
        <div
          ref={gridRef}
          className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-8"
        >
          {filteredProducts.map((product) => (
            <div key={product.id} className="product-card">
              <ProductCard product={product} />
            </div>
          ))}
        </div>

        {/* View All Link */}
        <div className="mt-12 text-center">
          <a
            href={`/collection/${activeTab}`}
            className="inline-flex items-center justify-center px-8 py-4 border border-black text-sm font-medium tracking-wider hover:bg-black hover:text-white transition-colors"
          >
            VIEW ALL PRODUCTS
          </a>
        </div>
      </div>
    </section>
  );
}

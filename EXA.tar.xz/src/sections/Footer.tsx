import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Twitter, Facebook, Youtube, Mail, MapPin, Phone } from 'lucide-react';

const socialLinks = [
  { icon: Instagram, href: 'https://instagram.com', label: 'Instagram' },
  { icon: Twitter, href: 'https://twitter.com', label: 'Twitter' },
  { icon: Facebook, href: 'https://facebook.com', label: 'Facebook' },
  { icon: Youtube, href: 'https://youtube.com', label: 'YouTube' },
];

const paymentMethods = [
  'Visa',
  'Mastercard',
  'Amex',
  'PayPal',
  'Apple Pay',
  'Google Pay',
];

export function Footer() {
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setIsSubscribed(true);
      setEmail('');
      setTimeout(() => setIsSubscribed(false), 3000);
    }
  };

  return (
    <footer className="w-full bg-black text-white">
      {/* Newsletter Section */}
      <div className="border-b border-white/10">
        <div className="w-full px-4 sm:px-6 lg:px-12 py-12 lg:py-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16 items-center">
            <div>
              <h3 className="text-2xl lg:text-3xl font-bold mb-3">
                JOIN THE EXA COMMUNITY
              </h3>
              <p className="text-white/60">
                Subscribe for exclusive offers, style tips, and early access to new collections.
              </p>
            </div>
            <form onSubmit={handleSubscribe} className="flex gap-4">
              <div className="flex-1 relative">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  className="w-full px-4 py-4 bg-white/10 border border-white/20 text-white placeholder:text-white/40 focus:outline-none focus:border-white/50 transition-colors"
                  required
                />
                {isSubscribed && (
                  <span className="absolute right-4 top-1/2 -translate-y-1/2 text-sm text-green-400">
                    Subscribed!
                  </span>
                )}
              </div>
              <button
                type="submit"
                className="px-8 py-4 bg-white text-black font-medium tracking-wider hover:bg-white/90 transition-colors"
              >
                SUBSCRIBE
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-12 lg:py-16">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 lg:gap-12">
          {/* Brand Column */}
          <div className="col-span-2 md:col-span-3 lg:col-span-2">
            <Link to="/">
              <img
                src="/images/logo-full.png"
                alt="EXA"
                className="h-12 w-auto object-contain invert mb-6"
              />
            </Link>
            <p className="text-white/60 text-sm leading-relaxed mb-6 max-w-sm">
              Your complete wardrobe for work, school, and life. Premium fashion and
              professional uniforms designed for the modern individual.
            </p>
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-sm text-white/60">
                <MapPin className="w-4 h-4" />
                <span>123 Fashion Avenue, New York, NY 10001</span>
              </div>
              <div className="flex items-center gap-3 text-sm text-white/60">
                <Phone className="w-4 h-4" />
                <span>+1 (800) 555-EXA</span>
              </div>
              <div className="flex items-center gap-3 text-sm text-white/60">
                <Mail className="w-4 h-4" />
                <span>hello@exa.com</span>
              </div>
            </div>
          </div>

          {/* Shop */}
          <div>
            <h4 className="text-sm font-semibold tracking-wider mb-6">
              SHOP
            </h4>
            <ul className="space-y-3">
              <li><Link to="/casual" className="text-sm text-white/60 hover:text-white transition-colors">Casual Wear</Link></li>
              <li><Link to="/uniforms" className="text-sm text-white/60 hover:text-white transition-colors">Uniforms</Link></li>
              <li><Link to="/school" className="text-sm text-white/60 hover:text-white transition-colors">School</Link></li>
              <li><Link to="/new-in" className="text-sm text-white/60 hover:text-white transition-colors">New In</Link></li>
              <li><Link to="/sale" className="text-sm text-white/60 hover:text-white transition-colors">Sale</Link></li>
            </ul>
          </div>

          {/* Customer Care */}
          <div>
            <h4 className="text-sm font-semibold tracking-wider mb-6">
              CUSTOMER CARE
            </h4>
            <ul className="space-y-3">
              <li><Link to="/size-guide" className="text-sm text-white/60 hover:text-white transition-colors">Size Guide</Link></li>
              <li><Link to="/shipping" className="text-sm text-white/60 hover:text-white transition-colors">Shipping Info</Link></li>
              <li><Link to="/returns" className="text-sm text-white/60 hover:text-white transition-colors">Returns & Exchanges</Link></li>
              <li><Link to="/track" className="text-sm text-white/60 hover:text-white transition-colors">Track Order</Link></li>
              <li><Link to="/faq" className="text-sm text-white/60 hover:text-white transition-colors">FAQ</Link></li>
            </ul>
          </div>

          {/* About */}
          <div>
            <h4 className="text-sm font-semibold tracking-wider mb-6">ABOUT</h4>
            <ul className="space-y-3">
              <li><Link to="/about" className="text-sm text-white/60 hover:text-white transition-colors">Our Story</Link></li>
              <li><Link to="/editorial" className="text-sm text-white/60 hover:text-white transition-colors">Editorial</Link></li>
              <li><Link to="/careers" className="text-sm text-white/60 hover:text-white transition-colors">Careers</Link></li>
              <li><Link to="/press" className="text-sm text-white/60 hover:text-white transition-colors">Press</Link></li>
              <li><Link to="/sustainability" className="text-sm text-white/60 hover:text-white transition-colors">Sustainability</Link></li>
            </ul>
          </div>

          {/* Social */}
          <div>
            <h4 className="text-sm font-semibold tracking-wider mb-6">FOLLOW US</h4>
            <div className="flex flex-wrap gap-3">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 bg-white/10 hover:bg-white/20 transition-colors"
                  aria-label={social.label}
                >
                  <social.icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/10">
        <div className="w-full px-4 sm:px-6 lg:px-12 py-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <p className="text-sm text-white/40">
              &copy; {new Date().getFullYear()} EXA. All rights reserved.
            </p>

            {/* Payment Methods */}
            <div className="flex items-center gap-4">
              <span className="text-xs text-white/40">We accept:</span>
              <div className="flex gap-2">
                {paymentMethods.map((method) => (
                  <span
                    key={method}
                    className="px-2 py-1 bg-white/10 text-xs text-white/60"
                  >
                    {method}
                  </span>
                ))}
              </div>
            </div>

            {/* Legal Links */}
            <div className="flex gap-6">
              <Link
                to="/privacy"
                className="text-sm text-white/40 hover:text-white transition-colors"
              >
                Privacy Policy
              </Link>
              <Link
                to="/terms"
                className="text-sm text-white/40 hover:text-white transition-colors"
              >
                Terms of Service
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}

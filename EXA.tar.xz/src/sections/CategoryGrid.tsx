import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';
import { categories } from '@/data/products';

gsap.registerPlugin(ScrollTrigger);

export function CategoryGrid() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const title = titleRef.current;
    const grid = gridRef.current;
    if (!section || !title || !grid) return;

    const triggers: ScrollTrigger[] = [];

    // Title animation
    const titleTrigger = ScrollTrigger.create({
      trigger: title,
      start: 'top 80%',
      onEnter: () => {
        gsap.fromTo(
          title.children,
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.8, stagger: 0.1, ease: 'power2.out' }
        );
      },
      once: true,
    });
    triggers.push(titleTrigger);

    // Grid items animation
    const cards = grid.querySelectorAll('.category-card');
    const gridTrigger = ScrollTrigger.create({
      trigger: grid,
      start: 'top 75%',
      onEnter: () => {
        gsap.fromTo(
          cards,
          { y: 60, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, stagger: 0.1, ease: 'power2.out' }
        );
      },
      once: true,
    });
    triggers.push(gridTrigger);

    return () => {
      triggers.forEach((t) => t.kill());
    };
  }, []);

  return (
    <section ref={sectionRef} className="w-full py-20 lg:py-32 bg-white">
      <div className="w-full px-4 sm:px-6 lg:px-12">
        {/* Section Header */}
        <div ref={titleRef} className="mb-12 lg:mb-16">
          <p className="text-sm tracking-[0.3em] text-black/60 mb-4 uppercase">
            Browse Collections
          </p>
          <h2 className="text-3xl lg:text-5xl font-bold tracking-tight">
            SHOP BY CATEGORY
          </h2>
        </div>

        {/* Category Grid */}
        <div
          ref={gridRef}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 lg:gap-6"
        >
          {categories.map((category) => (
            <a
              key={category.id}
              href={category.href}
              className="category-card group relative aspect-[3/4] overflow-hidden bg-neutral-100"
            >
              {/* Image */}
              <img
                src={category.image}
                alt={category.name}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />

              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />

              {/* Content */}
              <div className="absolute inset-x-0 bottom-0 p-6">
                <h3 className="text-white text-xl lg:text-2xl font-bold mb-2">
                  {category.name}
                </h3>
                <p className="text-white/70 text-sm mb-4">{category.description}</p>
                <div className="flex items-center text-white text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <span>Explore</span>
                  <ArrowRight className="w-4 h-4 ml-2 transition-transform group-hover:translate-x-1" />
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

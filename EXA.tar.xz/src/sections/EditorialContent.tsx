import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';
import { editorialArticles } from '@/data/products';

gsap.registerPlugin(ScrollTrigger);

export function EditorialContent() {
  const sectionRef = useRef<HTMLElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const grid = gridRef.current;
    if (!section || !grid) return;

    const triggers: ScrollTrigger[] = [];

    // Title animation
    const title = section.querySelector('.editorial-title');
    if (title) {
      const titleTrigger = ScrollTrigger.create({
        trigger: title,
        start: 'top 80%',
        onEnter: () => {
          gsap.fromTo(
            title,
            { y: 40, opacity: 0 },
            { y: 0, opacity: 1, duration: 0.8, ease: 'power2.out' }
          );
        },
        once: true,
      });
      triggers.push(titleTrigger);
    }

    // Articles animation
    const articles = grid.querySelectorAll('.editorial-article');
    const gridTrigger = ScrollTrigger.create({
      trigger: grid,
      start: 'top 75%',
      onEnter: () => {
        gsap.fromTo(
          articles,
          { y: 60, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, stagger: 0.15, ease: 'power2.out' }
        );
      },
      once: true,
    });
    triggers.push(gridTrigger);

    return () => {
      triggers.forEach((t) => t.kill());
    };
  }, []);

  return (
    <section ref={sectionRef} className="w-full py-20 lg:py-32 bg-neutral-50">
      <div className="w-full px-4 sm:px-6 lg:px-12">
        {/* Section Header */}
        <div className="editorial-title mb-12 lg:mb-16">
          <p className="text-sm tracking-[0.3em] text-black/60 mb-4 uppercase">
            Style Guide
          </p>
          <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between">
            <h2 className="text-3xl lg:text-5xl font-bold tracking-tight">
              EDITORIAL
            </h2>
            <a
              href="/editorial"
              className="inline-flex items-center text-sm font-medium tracking-wider mt-4 lg:mt-0 group"
            >
              <span className="border-b border-black pb-1 group-hover:border-black/50 transition-colors">
                VIEW ALL ARTICLES
              </span>
              <ArrowRight className="w-4 h-4 ml-2 transition-transform group-hover:translate-x-1" />
            </a>
          </div>
        </div>

        {/* Editorial Grid */}
        <div ref={gridRef} className="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8">
          {editorialArticles.map((article, index) => (
            <a
              key={article.id}
              href={article.href}
              className={`editorial-article group ${
                index === 0 ? 'lg:col-span-2 lg:row-span-2' : ''
              }`}
            >
              <div
                className={`relative overflow-hidden bg-neutral-200 ${
                  index === 0 ? 'aspect-[16/10] lg:aspect-auto lg:h-full' : 'aspect-[16/10]'
                }`}
              >
                <img
                  src={article.image}
                  alt={article.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />

                {/* Content */}
                <div className="absolute inset-x-0 bottom-0 p-6 lg:p-8">
                  <p className="text-white/70 text-sm tracking-wider mb-3">
                    {article.subtitle}
                  </p>
                  <h3
                    className={`text-white font-bold leading-tight ${
                      index === 0 ? 'text-2xl lg:text-3xl' : 'text-xl lg:text-2xl'
                    }`}
                  >
                    {article.title}
                  </h3>
                  <div className="flex items-center text-white text-sm font-medium mt-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <span>Read Article</span>
                    <ArrowRight className="w-4 h-4 ml-2 transition-transform group-hover:translate-x-1" />
                  </div>
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

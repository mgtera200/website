import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const dualFocusItems = [
  {
    id: 'work-weekend',
    title: 'WORK TO WEEKEND',
    subtitle: 'Versatile styling that transitions seamlessly',
    description:
      'Discover pieces that work as hard as you do. From morning meetings to evening plans, our collection adapts to your schedule without compromising on style.',
    image: '/images/editorial-workweekend.jpg',
    cta: 'Explore Collection',
    href: '/work-weekend',
    layout: 'left',
  },
  {
    id: 'school-street',
    title: 'SCHOOL MEETS STREET',
    subtitle: 'Uniforms that break the mold',
    description:
      'Gone are the days of boring school uniforms. Our designs combine institutional requirements with contemporary fashion, so students actually want to wear them.',
    image: '/images/editorial-school.jpg',
    cta: 'Shop School Wear',
    href: '/school',
    layout: 'right',
  },
];

export function DualFocus() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const triggers: ScrollTrigger[] = [];
    const items = section.querySelectorAll('.dual-focus-item');

    items.forEach((item) => {
      const image = item.querySelector('.dual-image');
      const content = item.querySelector('.dual-content');

      const itemTrigger = ScrollTrigger.create({
        trigger: item,
        start: 'top 75%',
        onEnter: () => {
          gsap.fromTo(
            image,
            { x: item.classList.contains('layout-right') ? 60 : -60, opacity: 0 },
            { x: 0, opacity: 1, duration: 0.9, ease: 'power2.out' }
          );
          gsap.fromTo(
            content,
            { x: item.classList.contains('layout-right') ? -40 : 40, opacity: 0 },
            { x: 0, opacity: 1, duration: 0.9, delay: 0.2, ease: 'power2.out' }
          );
        },
        once: true,
      });
      triggers.push(itemTrigger);
    });

    return () => {
      triggers.forEach((t) => t.kill());
    };
  }, []);

  return (
    <section ref={sectionRef} className="w-full bg-neutral-50">
      {dualFocusItems.map((item) => (
        <div
          key={item.id}
          className={`dual-focus-item ${
            item.layout === 'right' ? 'layout-right' : 'layout-left'
          }`}
        >
          <div
            className={`grid grid-cols-1 lg:grid-cols-2 min-h-[500px] lg:min-h-[600px] ${
              item.layout === 'right' ? 'lg:flex-row-reverse' : ''
            }`}
          >
            {/* Image */}
            <div
              className={`dual-image relative h-[300px] lg:h-auto overflow-hidden ${
                item.layout === 'right' ? 'lg:order-2' : 'lg:order-1'
              }`}
            >
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Content */}
            <div
              className={`dual-content flex items-center ${
                item.layout === 'right' ? 'lg:order-1' : 'lg:order-2'
              }`}
            >
              <div className="px-4 sm:px-6 lg:px-12 xl:px-20 py-12 lg:py-0">
                <p className="text-sm tracking-[0.3em] text-black/60 mb-4 uppercase">
                  {item.subtitle}
                </p>
                <h2 className="text-3xl lg:text-4xl xl:text-5xl font-bold tracking-tight mb-6">
                  {item.title}
                </h2>
                <p className="text-black/70 text-base lg:text-lg leading-relaxed mb-8 max-w-md">
                  {item.description}
                </p>
                <a
                  href={item.href}
                  className="inline-flex items-center text-sm font-medium tracking-wider group"
                >
                  <span className="border-b border-black pb-1 group-hover:border-black/50 transition-colors">
                    {item.cta}
                  </span>
                  <ArrowRight className="w-4 h-4 ml-2 transition-transform group-hover:translate-x-1" />
                </a>
              </div>
            </div>
          </div>
        </div>
      ))}
    </section>
  );
}

import { useState } from 'react';
import { Link } from 'react-router-dom';
import { User, ShoppingBag, Heart, MapPin, LogOut, Eye, EyeOff } from 'lucide-react';

export function Account() {
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // Mock user data
  const [user] = useState({
    name: 'John Doe',
    email: 'john.doe@example.com',
    orders: [
      { id: 'EXA-12345', date: '2024-01-15', total: 145.00, status: 'Delivered' },
      { id: 'EXA-12346', date: '2024-02-01', total: 89.50, status: 'Processing' },
    ],
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoggedIn(true);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
  };

  if (isLoggedIn) {
    return (
      <div className="min-h-screen bg-white pt-24 lg:pt-28">
        <div className="w-full px-4 sm:px-6 lg:px-12 py-8 lg:py-16">
          <h1 className="text-2xl lg:text-4xl font-bold mb-8">MY ACCOUNT</h1>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Sidebar */}
            <div className="lg:col-span-1">
              <div className="bg-neutral-50 p-6">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 bg-black text-white rounded-full flex items-center justify-center text-xl font-bold">
                    {user.name.charAt(0)}
                  </div>
                  <div>
                    <p className="font-semibold">{user.name}</p>
                    <p className="text-sm text-black/60">{user.email}</p>
                  </div>
                </div>

                <nav className="space-y-2">
                  <Link
                    to="/account"
                    className="flex items-center gap-3 px-4 py-3 bg-black text-white"
                  >
                    <User className="w-5 h-5" />
                    <span>Account Overview</span>
                  </Link>
                  <Link
                    to="/account/orders"
                    className="flex items-center gap-3 px-4 py-3 hover:bg-black/5 transition-colors"
                  >
                    <ShoppingBag className="w-5 h-5" />
                    <span>My Orders</span>
                  </Link>
                  <Link
                    to="/wishlist"
                    className="flex items-center gap-3 px-4 py-3 hover:bg-black/5 transition-colors"
                  >
                    <Heart className="w-5 h-5" />
                    <span>Wishlist</span>
                  </Link>
                  <Link
                    to="/account/addresses"
                    className="flex items-center gap-3 px-4 py-3 hover:bg-black/5 transition-colors"
                  >
                    <MapPin className="w-5 h-5" />
                    <span>Addresses</span>
                  </Link>
                  <button
                    onClick={handleLogout}
                    className="w-full flex items-center gap-3 px-4 py-3 text-red-600 hover:bg-red-50 transition-colors"
                  >
                    <LogOut className="w-5 h-5" />
                    <span>Logout</span>
                  </button>
                </nav>
              </div>
            </div>

            {/* Main Content */}
            <div className="lg:col-span-3">
              {/* Account Overview */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
                <div className="bg-neutral-50 p-6">
                  <ShoppingBag className="w-8 h-8 mb-4" />
                  <p className="text-2xl font-bold">{user.orders.length}</p>
                  <p className="text-sm text-black/60">Total Orders</p>
                </div>
                <div className="bg-neutral-50 p-6">
                  <Heart className="w-8 h-8 mb-4" />
                  <p className="text-2xl font-bold">3</p>
                  <p className="text-sm text-black/60">Wishlist Items</p>
                </div>
                <div className="bg-neutral-50 p-6">
                  <MapPin className="w-8 h-8 mb-4" />
                  <p className="text-2xl font-bold">2</p>
                  <p className="text-sm text-black/60">Saved Addresses</p>
                </div>
              </div>

              {/* Recent Orders */}
              <div className="bg-neutral-50 p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-lg font-bold">RECENT ORDERS</h2>
                  <Link to="/account/orders" className="text-sm hover:underline">
                    View All
                  </Link>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-black/10">
                        <th className="text-left py-3 text-sm font-semibold">Order #</th>
                        <th className="text-left py-3 text-sm font-semibold">Date</th>
                        <th className="text-left py-3 text-sm font-semibold">Total</th>
                        <th className="text-left py-3 text-sm font-semibold">Status</th>
                        <th className="text-left py-3 text-sm font-semibold"></th>
                      </tr>
                    </thead>
                    <tbody>
                      {user.orders.map((order) => (
                        <tr key={order.id} className="border-b border-black/10">
                          <td className="py-4 text-sm">{order.id}</td>
                          <td className="py-4 text-sm text-black/60">{order.date}</td>
                          <td className="py-4 text-sm font-semibold">${order.total.toFixed(2)}</td>
                          <td className="py-4">
                            <span
                              className={`px-3 py-1 text-xs font-medium ${
                                order.status === 'Delivered'
                                  ? 'bg-green-100 text-green-800'
                                  : 'bg-yellow-100 text-yellow-800'
                              }`}
                            >
                              {order.status}
                            </span>
                          </td>
                          <td className="py-4">
                            <Link
                              to={`/account/orders/${order.id}`}
                              className="text-sm hover:underline"
                            >
                              View
                            </Link>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white pt-24 lg:pt-28">
      <div className="w-full px-4 sm:px-6 lg:px-12 py-8 lg:py-16">
        <div className="max-w-md mx-auto">
          <h1 className="text-2xl lg:text-3xl font-bold text-center mb-2">
            {isLogin ? 'WELCOME BACK' : 'CREATE ACCOUNT'}
          </h1>
          <p className="text-black/60 text-center mb-8">
            {isLogin
              ? 'Sign in to access your account and orders'
              : 'Join EXA for exclusive offers and faster checkout'}
          </p>

          {/* Tabs */}
          <div className="flex mb-8 border-b border-black/10">
            <button
              onClick={() => setIsLogin(true)}
              className={`flex-1 py-3 text-sm font-medium tracking-wider transition-colors ${
                isLogin
                  ? 'border-b-2 border-black text-black'
                  : 'text-black/40 hover:text-black'
              }`}
            >
              SIGN IN
            </button>
            <button
              onClick={() => setIsLogin(false)}
              className={`flex-1 py-3 text-sm font-medium tracking-wider transition-colors ${
                !isLogin
                  ? 'border-b-2 border-black text-black'
                  : 'text-black/40 hover:text-black'
              }`}
            >
              REGISTER
            </button>
          </div>

          {/* Form */}
          <form onSubmit={isLogin ? handleLogin : handleRegister} className="space-y-6">
            {!isLogin && (
              <div>
                <label className="text-sm font-medium mb-2 block">FULL NAME *</label>
                <input
                  type="text"
                  required
                  className="w-full px-4 py-3 border border-black/20 focus:outline-none focus:border-black"
                  placeholder="Enter your full name"
                />
              </div>
            )}

            <div>
              <label className="text-sm font-medium mb-2 block">EMAIL *</label>
              <input
                type="email"
                required
                className="w-full px-4 py-3 border border-black/20 focus:outline-none focus:border-black"
                placeholder="Enter your email"
              />
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">PASSWORD *</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  className="w-full px-4 py-3 border border-black/20 focus:outline-none focus:border-black pr-12"
                  placeholder="Enter your password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-black/40 hover:text-black"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            {isLogin && (
              <div className="flex items-center justify-between">
                <label className="flex items-center gap-2 text-sm">
                  <input type="checkbox" className="w-4 h-4 accent-black" />
                  <span>Remember me</span>
                </label>
                <Link to="/account/forgot-password" className="text-sm hover:underline">
                  Forgot password?
                </Link>
              </div>
            )}

            <button
              type="submit"
              className="w-full py-4 bg-black text-white font-medium tracking-wider hover:bg-black/90 transition-colors"
            >
              {isLogin ? 'SIGN IN' : 'CREATE ACCOUNT'}
            </button>
          </form>

          {/* Social Login */}
          <div className="mt-8">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-black/10" />
              </div>
              <div className="relative flex justify-center">
                <span className="bg-white px-4 text-sm text-black/60">Or continue with</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mt-6">
              <button className="flex items-center justify-center gap-2 px-4 py-3 border border-black/20 hover:border-black transition-colors">
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path
                    fill="currentColor"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="currentColor"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="currentColor"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                  />
                  <path
                    fill="currentColor"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                  />
                </svg>
                Google
              </button>
              <button className="flex items-center justify-center gap-2 px-4 py-3 border border-black/20 hover:border-black transition-colors">
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M16.365 1.43c0 1.14-.493 2.27-1.177 3.08-.684.81-1.768 1.46-2.978 1.46-.068 0-.136 0-.204-.01-.068.01-.136.01-.204.01-1.21 0-2.294-.65-2.978-1.46-.684-.81-1.177-1.94-1.177-3.08 0-1.14.493-2.27 1.177-3.08.684-.81 1.768-1.46 2.978-1.46.068 0 .136 0 .204.01.068-.01.136-.01.204-.01 1.21 0 2.294.65 2.978 1.46.684.81 1.177 1.94 1.177 3.08zm-5.34 6.84c-2.722 0-5.34 1.37-5.34 4.1 0 2.04 1.37 4.1 5.34 4.1 3.97 0 5.34-2.06 5.34-4.1 0-2.73-2.618-4.1-5.34-4.1z" />
                </svg>
                Apple
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuthStore } from '@/store/authStore';
import { toast } from 'sonner';

export const AuthCallback = () => {
  const navigate = useNavigate();
  const { setUser } = useAuthStore();

  useEffect(() => {
    const handleAuthCallback = async () => {
      try {
        // Get the session from the URL
        const { data: { session }, error } = await supabase.auth.getSession();
        
        if (error) {
          toast.error('Authentication failed');
          navigate('/login');
          return;
        }

        if (session?.user) {
          // Check if user profile exists
          const { data: profile } = await supabase
            .from('users')
            .select('*')
            .eq('id', session.user.id)
            .single();

          if (profile) {
            setUser(profile);
            toast.success('Welcome back!');
          } else {
            // Create new user profile
            const { data: newProfile, error: createError } = await supabase
              .from('users')
              .insert({
                id: session.user.id,
                email: session.user.email!,
                first_name: session.user.user_metadata.full_name?.split(' ')[0] || 'User',
                last_name: session.user.user_metadata.full_name?.split(' ').slice(1).join(' ') || '',
                role: 'customer',
              })
              .select()
              .single();

            if (createError) {
              toast.error('Failed to create profile');
              navigate('/login');
              return;
            }

            if (newProfile) {
              setUser(newProfile);
              toast.success('Account created successfully!');
            }
          }

          navigate('/account');
        } else {
          navigate('/login');
        }
      } catch {
        toast.error('An error occurred');
        navigate('/login');
      }
    };

    handleAuthCallback();
  }, [navigate, setUser]);

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <div className="w-12 h-12 border-2 border-black/30 border-t-black rounded-full animate-spin mx-auto mb-4" />
        <p className="text-gray-600">Completing sign in...</p>
      </div>
    </div>
  );
};

export default AuthCallback;

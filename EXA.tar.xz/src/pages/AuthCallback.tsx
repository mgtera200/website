import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuthStore } from '@/store/authStore';
import { toast } from 'sonner';

export const AuthCallback = () => {
  const navigate = useNavigate();
  const { setUser } = useAuthStore();
  const [status, setStatus] = useState<'processing' | 'success' | 'error'>('processing');
  const [message, setMessage] = useState('Completing sign in...');
  const processedRef = useRef(false);

  useEffect(() => {
    // Prevent double processing
    if (processedRef.current) return;
    processedRef.current = true;

    const handleAuthCallback = async () => {
      try {
        setMessage('Verifying authentication...');
        
        // Get the session from the URL (handles OAuth callback)
        const { data: { session }, error: sessionError } = await supabase.auth.getSession();
        
        if (sessionError) {
          console.error('Session error:', sessionError);
          toast.error('Authentication failed: ' + sessionError.message);
          setStatus('error');
          setTimeout(() => navigate('/login'), 2000);
          return;
        }

        if (!session?.user) {
          console.log('No session found, checking URL hash...');
          // Try to exchange the auth code for a session
          const { data: exchangeData, error: exchangeError } = await supabase.auth.exchangeCodeForSession(window.location.hash);
          
          if (exchangeError || !exchangeData.session) {
            console.error('Exchange error:', exchangeError);
            toast.error('Authentication session not found');
            setStatus('error');
            setTimeout(() => navigate('/login'), 2000);
            return;
          }
          
          // Retry with new session
          return handleAuthCallback();
        }

        const user = session.user;
        console.log('Authenticated user:', user.id);
        setMessage('Loading your profile...');

        // Check if user profile exists with retry logic
        let profile = null;
        let retries = 3;
        
        while (retries > 0 && !profile) {
          const { data, error } = await supabase
            .from('users')
            .select('*')
            .eq('id', user.id)
            .single();

          if (error) {
            console.log(`Profile check attempt ${4 - retries} failed:`, error.message);
            if (retries > 1) {
              await new Promise(resolve => setTimeout(resolve, 500));
            }
          } else {
            profile = data;
          }
          retries--;
        }

        if (profile) {
          console.log('Profile found:', profile);
          setUser(profile);
          setStatus('success');
          setMessage('Welcome back!');
          toast.success('Welcome back!');
          setTimeout(() => navigate('/account'), 1000);
          return;
        }

        // Profile doesn't exist - create it manually (trigger may have failed)
        console.log('Profile not found, creating new profile...');
        setMessage('Creating your profile...');
        
        const fullName = user.user_metadata?.full_name || user.user_metadata?.name || '';
        const email = user.email || '';
        const avatarUrl = user.user_metadata?.avatar_url || user.user_metadata?.picture || null;
        
        const firstName = fullName.split(' ')[0] || email.split('@')[0] || 'User';
        const lastName = fullName.split(' ').slice(1).join(' ') || '';

        // Try to create profile with retry logic
        let newProfile = null;
        let createRetries = 3;
        
        while (createRetries > 0 && !newProfile) {
          const { data, error: createError } = await supabase
            .from('users')
            .insert({
              id: user.id,
              email: email,
              first_name: firstName,
              last_name: lastName,
              avatar_url: avatarUrl,
              role: 'customer',
              created_at: new Date().toISOString(),
            })
            .select()
            .single();

          if (createError) {
            console.log(`Profile creation attempt ${4 - createRetries} failed:`, createError.message);
            if (createRetries > 1) {
              await new Promise(resolve => setTimeout(resolve, 500));
            }
          } else {
            newProfile = data;
          }
          createRetries--;
        }

        if (newProfile) {
          console.log('Profile created:', newProfile);
          setUser(newProfile);
          setStatus('success');
          setMessage('Account created successfully!');
          toast.success('Account created successfully!');
          setTimeout(() => navigate('/account'), 1000);
        } else {
          // Last resort: try upsert
          console.log('Trying upsert as last resort...');
          const { data: upsertData, error: upsertError } = await supabase
            .from('users')
            .upsert({
              id: user.id,
              email: email,
              first_name: firstName,
              last_name: lastName,
              avatar_url: avatarUrl,
              role: 'customer',
            }, { onConflict: 'id' })
            .select()
            .single();

          if (upsertError || !upsertData) {
            console.error('All profile creation attempts failed');
            toast.error('Failed to create profile. Please contact support.');
            setStatus('error');
            setTimeout(() => navigate('/login'), 2000);
            return;
          }

          setUser(upsertData);
          setStatus('success');
          toast.success('Account created successfully!');
          setTimeout(() => navigate('/account'), 1000);
        }
      } catch (error) {
        console.error('Auth callback error:', error);
        toast.error('An unexpected error occurred');
        setStatus('error');
        setMessage('Something went wrong');
        setTimeout(() => navigate('/login'), 2000);
      }
    };

    handleAuthCallback();
  }, [navigate, setUser]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="text-center p-8 bg-white rounded-lg shadow-sm max-w-md w-full mx-4">
        <div className={`w-12 h-12 rounded-full mx-auto mb-4 flex items-center justify-center ${
          status === 'error' ? 'bg-red-100' : status === 'success' ? 'bg-green-100' : 'bg-gray-100'
        }`}>
          {status === 'processing' && (
            <div className="w-6 h-6 border-2 border-gray-300 border-t-black rounded-full animate-spin" />
          )}
          {status === 'success' && (
            <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          )}
          {status === 'error' && (
            <svg className="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          )}
        </div>
        <h2 className="text-xl font-semibold text-gray-900 mb-2">
          {status === 'processing' && 'Signing you in...'}
          {status === 'success' && 'Success!'}
          {status === 'error' && 'Something went wrong'}
        </h2>
        <p className="text-gray-600">{message}</p>
        {status === 'processing' && (
          <p className="text-sm text-gray-400 mt-4">This may take a few moments...</p>
        )}
      </div>
    </div>
  );
};

export default AuthCallback;

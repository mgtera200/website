import { useState, useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Link } from 'react-router-dom';
import { Heart, ShoppingBag, ChevronDown, SlidersHorizontal } from 'lucide-react';
import { products } from '@/data/products';
import { useCart } from '@/hooks/useCart';
import type { Product } from '@/types';
import { getColorName, getColorHex } from '@/types';

gsap.registerPlugin(ScrollTrigger);

const casualProducts = products.filter((p) => p.category === 'casual');

const sizes = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];
const colors = ['Black', 'White', 'Grey', 'Navy'];
const priceRanges = [
  { label: 'Under $30', min: 0, max: 30 },
  { label: '$30 - $60', min: 30, max: 60 },
  { label: '$60 - $100', min: 60, max: 100 },
  { label: 'Over $100', min: 100, max: Infinity },
];

function ProductCard({ product }: { product: Product }) {
  const [isHovered, setIsHovered] = useState(false);
  const { addItem } = useCart();

  const handleQuickAdd = () => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      size: product.sizes[0],
      color: getColorName(product.colors[0]),
    });
  };

  return (
    <div
      className="group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <Link to={`/product/${product.id}`} className="block">
        <div className="relative aspect-[3/4] overflow-hidden bg-neutral-100 mb-4">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          
          {product.isNew && (
            <span className="absolute top-3 left-3 px-3 py-1 bg-black text-white text-xs font-medium tracking-wider">
              NEW
            </span>
          )}
          
          <div
            className={`absolute inset-x-0 bottom-0 p-4 flex justify-center gap-3 transition-all duration-300 ${
              isHovered ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            <button
              onClick={(e) => {
                e.preventDefault();
                handleQuickAdd();
              }}
              className="p-3 bg-white hover:bg-black hover:text-white transition-colors"
              aria-label="Add to cart"
            >
              <ShoppingBag className="w-5 h-5" />
            </button>
            <button
              onClick={(e) => e.preventDefault()}
              className="p-3 bg-white hover:bg-black hover:text-white transition-colors"
              aria-label="Add to wishlist"
            >
              <Heart className="w-5 h-5" />
            </button>
          </div>
        </div>
      </Link>

      <div className="space-y-2">
        <Link to={`/product/${product.id}`}>
          <h3 className="text-sm font-medium tracking-wide group-hover:opacity-70 transition-opacity">
            {product.name}
          </h3>
        </Link>
        <div className="flex items-center gap-2">
          <span className="text-sm font-semibold">${product.price}</span>
          {product.originalPrice && (
            <span className="text-sm text-black/50 line-through">
              ${product.originalPrice}
            </span>
          )}
        </div>
        <div className="flex gap-1 pt-1">
          {product.colors.slice(0, 3).map((color, index) => (
            <span
              key={index}
              className="w-4 h-4 rounded-full border border-black/20"
              style={{ backgroundColor: getColorHex(color) }}
              title={getColorName(color)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

export function Casual() {
  const [selectedSizes, setSelectedSizes] = useState<string[]>([]);
  const [selectedColors, setSelectedColors] = useState<string[]>([]);
  const [selectedPriceRange, setSelectedPriceRange] = useState<string | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [sortBy, setSortBy] = useState('newest');
  const gridRef = useRef<HTMLDivElement>(null);

  const filteredProducts = casualProducts.filter((product) => {
    if (selectedSizes.length > 0 && !selectedSizes.some((s) => product.sizes.includes(s))) {
      return false;
    }
    if (selectedColors.length > 0 && !selectedColors.some((c) => product.colors.some(pc => getColorName(pc).toLowerCase() === c.toLowerCase()))) {
      return false;
    }
    if (selectedPriceRange) {
      const range = priceRanges.find((r) => r.label === selectedPriceRange);
      if (range && (product.price < range.min || product.price > range.max)) {
        return false;
      }
    }
    return true;
  });

  const sortedProducts = [...filteredProducts].sort((a, b) => {
    if (sortBy === 'price-low') return a.price - b.price;
    if (sortBy === 'price-high') return b.price - a.price;
    if (sortBy === 'newest') return (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0);
    return 0;
  });

  useEffect(() => {
    const grid = gridRef.current;
    if (!grid) return;

    const cards = grid.querySelectorAll('.product-card');
    gsap.fromTo(
      cards,
      { y: 40, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.6, stagger: 0.1, ease: 'power2.out' }
    );
  }, [sortedProducts]);

  return (
    <div className="min-h-screen bg-white pt-24 lg:pt-28">
      {/* Hero Banner */}
      <div className="relative h-[400px] lg:h-[500px] overflow-hidden">
        <img
          src="/images/hero-casual.jpg"
          alt="Casual Collection"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40" />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white">
            <p className="text-sm tracking-[0.3em] mb-4 uppercase">Collection</p>
            <h1 className="text-4xl lg:text-6xl font-bold tracking-tight">CASUAL WEAR</h1>
            <p className="mt-4 text-white/80 max-w-md mx-auto">
              Streetwear essentials designed for everyday comfort and style
            </p>
          </div>
        </div>
      </div>

      {/* Filters & Products */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-12">
        {/* Filter Bar */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 mb-8 pb-6 border-b border-black/10">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-2 px-4 py-2 border border-black/20 hover:border-black transition-colors"
            >
              <SlidersHorizontal className="w-4 h-4" />
              <span className="text-sm font-medium">Filters</span>
              {(selectedSizes.length > 0 || selectedColors.length > 0 || selectedPriceRange) && (
                <span className="w-5 h-5 bg-black text-white text-xs flex items-center justify-center rounded-full">
                  {selectedSizes.length + selectedColors.length + (selectedPriceRange ? 1 : 0)}
                </span>
              )}
            </button>
            <span className="text-sm text-black/60">
              {sortedProducts.length} products
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-sm text-black/60">Sort by:</span>
            <div className="relative">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="appearance-none px-4 py-2 pr-10 border border-black/20 text-sm focus:outline-none focus:border-black bg-white"
              >
                <option value="newest">Newest</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Filter Panel */}
        {showFilters && (
          <div className="mb-8 p-6 bg-neutral-50">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Size Filter */}
              <div>
                <h4 className="text-sm font-semibold mb-4">Size</h4>
                <div className="flex flex-wrap gap-2">
                  {sizes.map((size) => (
                    <button
                      key={size}
                      onClick={() => {
                        setSelectedSizes((prev) =>
                          prev.includes(size)
                            ? prev.filter((s) => s !== size)
                            : [...prev, size]
                        );
                      }}
                      className={`px-4 py-2 text-sm border transition-colors ${
                        selectedSizes.includes(size)
                          ? 'bg-black text-white border-black'
                          : 'border-black/20 hover:border-black'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>

              {/* Color Filter */}
              <div>
                <h4 className="text-sm font-semibold mb-4">Color</h4>
                <div className="flex flex-wrap gap-3">
                  {colors.map((color) => (
                    <button
                      key={color}
                      onClick={() => {
                        setSelectedColors((prev) =>
                          prev.includes(color)
                            ? prev.filter((c) => c !== color)
                            : [...prev, color]
                        );
                      }}
                      className={`flex items-center gap-2 px-3 py-2 text-sm border transition-colors ${
                        selectedColors.includes(color)
                          ? 'bg-black text-white border-black'
                          : 'border-black/20 hover:border-black'
                      }`}
                    >
                      <span
                        className="w-4 h-4 rounded-full border border-black/20"
                        style={{
                          backgroundColor:
                            color.toLowerCase() === 'white'
                              ? '#ffffff'
                              : color.toLowerCase() === 'black'
                              ? '#000000'
                              : color.toLowerCase() === 'grey' || color.toLowerCase() === 'gray'
                              ? '#808080'
                              : color.toLowerCase() === 'navy'
                              ? '#000080'
                              : '#cccccc',
                        }}
                      />
                      {color}
                    </button>
                  ))}
                </div>
              </div>

              {/* Price Filter */}
              <div>
                <h4 className="text-sm font-semibold mb-4">Price Range</h4>
                <div className="space-y-2">
                  {priceRanges.map((range) => (
                    <button
                      key={range.label}
                      onClick={() => {
                        setSelectedPriceRange((prev) =>
                          prev === range.label ? null : range.label
                        );
                      }}
                      className={`block w-full text-left px-3 py-2 text-sm border transition-colors ${
                        selectedPriceRange === range.label
                          ? 'bg-black text-white border-black'
                          : 'border-black/20 hover:border-black'
                      }`}
                    >
                      {range.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Clear Filters */}
            {(selectedSizes.length > 0 || selectedColors.length > 0 || selectedPriceRange) && (
              <button
                onClick={() => {
                  setSelectedSizes([]);
                  setSelectedColors([]);
                  setSelectedPriceRange(null);
                }}
                className="mt-6 text-sm text-black/60 hover:text-black underline"
              >
                Clear all filters
              </button>
            )}
          </div>
        )}

        {/* Products Grid */}
        <div ref={gridRef} className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-8">
          {sortedProducts.map((product) => (
            <div key={product.id} className="product-card">
              <ProductCard product={product} />
            </div>
          ))}
        </div>

        {sortedProducts.length === 0 && (
          <div className="text-center py-16">
            <p className="text-black/60">No products match your filters.</p>
            <button
              onClick={() => {
                setSelectedSizes([]);
                setSelectedColors([]);
                setSelectedPriceRange(null);
              }}
              className="mt-4 text-sm underline hover:no-underline"
            >
              Clear filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

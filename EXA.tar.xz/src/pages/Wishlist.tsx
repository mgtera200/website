import { Link } from 'react-router-dom';
import { Heart, ShoppingBag, Trash2 } from 'lucide-react';
import { products } from '@/data/products';
import { useCart } from '@/hooks/useCart';
import { getColorName } from '@/types';

const wishlistItems = products.slice(0, 3);

export function Wishlist() {
  const { addItem } = useCart();

  return (
    <div className="min-h-screen bg-white pt-24 lg:pt-28">
      <div className="w-full px-4 sm:px-6 lg:px-12 py-8 lg:py-16">
        <h1 className="text-2xl lg:text-4xl font-bold mb-8">MY WISHLIST</h1>

        {wishlistItems.length === 0 ? (
          <div className="text-center py-16">
            <Heart className="w-16 h-16 mx-auto mb-6 text-black/30" />
            <h2 className="text-xl font-bold mb-4">YOUR WISHLIST IS EMPTY</h2>
            <p className="text-black/60 mb-8">
              Save items you love to your wishlist and buy them later.
            </p>
            <Link
              to="/casual"
              className="inline-flex items-center justify-center px-8 py-4 bg-black text-white font-medium tracking-wider hover:bg-black/90 transition-colors"
            >
              START SHOPPING
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-8">
            {wishlistItems.map((product) => (
              <div key={product.id} className="group">
                <Link to={`/product/${product.id}`} className="block">
                  <div className="relative aspect-[3/4] overflow-hidden bg-neutral-100 mb-4">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    
                    <button
                      onClick={(e) => {
                        e.preventDefault();
                      }}
                      className="absolute top-3 right-3 p-2 bg-white hover:bg-red-50 transition-colors"
                      aria-label="Remove from wishlist"
                    >
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </button>
                  </div>
                </Link>

                <div className="space-y-2">
                  <Link to={`/product/${product.id}`}>
                    <h3 className="text-sm font-medium tracking-wide group-hover:opacity-70 transition-opacity">
                      {product.name}
                    </h3>
                  </Link>
                  <span className="text-sm font-semibold">${product.price}</span>
                  <button
                    onClick={() =>
                      addItem({
                        id: product.id,
                        name: product.name,
                        price: product.price,
                        image: product.image,
                        size: product.sizes[0],
                        color: getColorName(product.colors[0]),
                      })
                    }
                    className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-black text-white text-sm font-medium hover:bg-black/90 transition-colors"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    ADD TO CART
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

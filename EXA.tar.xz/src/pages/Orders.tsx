import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Package, ChevronRight } from 'lucide-react';
import { useAuthStore } from '@/store/authStore';
import { getUserOrders } from '@/lib/supabase';
import { toast } from 'sonner';
import type { Order } from '@/types';

const statusColors: Record<string, string> = {
  pending: 'bg-yellow-100 text-yellow-800',
  confirmed: 'bg-blue-100 text-blue-800',
  processing: 'bg-purple-100 text-purple-800',
  shipped: 'bg-indigo-100 text-indigo-800',
  delivered: 'bg-green-100 text-green-800',
  cancelled: 'bg-red-100 text-red-800',
  refunded: 'bg-gray-100 text-gray-800',
};

export const Orders = () => {
  const { user } = useAuthStore();
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchOrders = async () => {
      if (!user) return;

      try {
        const { data, error } = await getUserOrders(user.id);
        if (error) {
          toast.error('Failed to load orders');
          return;
        }
        if (data) {
          setOrders(data);
        }
      } catch {
        toast.error('An error occurred');
      } finally {
        setIsLoading(false);
      }
    };

    fetchOrders();
  }, [user]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-16">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-black" />
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <div className="text-center py-16">
        <Package className="mx-auto mb-4" size={48} strokeWidth={1} />
        <h3 className="text-lg font-medium mb-2">No orders yet</h3>
        <p className="text-gray-500 mb-6">You have not placed any orders yet.</p>
        <Link
          to="/casual"
          className="inline-block px-6 py-3 bg-black text-white font-medium hover:bg-gray-800 transition-colors"
        >
          START SHOPPING
        </Link>
      </div>
    );
  }

  return (
    <div>
      <h2 className="text-xl font-bold mb-6">My Orders</h2>

      <div className="space-y-4">
        {orders.map((order) => (
          <Link
            key={order.id}
            to={`/order/${order.id}`}
            className="block border hover:border-black transition-colors"
          >
            <div className="p-4 lg:p-6">
              <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
                <div>
                  <p className="text-sm text-gray-500">Order Number</p>
                  <p className="font-medium">{order.order_number}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Date</p>
                  <p className="font-medium">
                    {new Date(order.created_at).toLocaleDateString()}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Total</p>
                  <p className="font-medium">{order.total} EGP</p>
                </div>
                <div>
                  <span className={`px-3 py-1 text-xs font-medium ${statusColors[order.status]}`}>
                    {order.status.toUpperCase()}
                  </span>
                </div>
                <ChevronRight className="text-gray-400" size={20} />
              </div>

              {/* Order Items Preview */}
              <div className="flex gap-2 pt-4 border-t">
                {order.items?.slice(0, 4).map((item, index) => (
                  <div key={index} className="w-16 h-16 bg-gray-100">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                ))}
                {order.items && order.items.length > 4 && (
                  <div className="w-16 h-16 bg-gray-100 flex items-center justify-center text-sm text-gray-500">
                    +{order.items.length - 4}
                  </div>
                )}
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default Orders;

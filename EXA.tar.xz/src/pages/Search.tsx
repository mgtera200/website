import { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Search as SearchIcon, X } from 'lucide-react';
import { Navigation } from '@/components/Navigation';
import { Footer } from '@/sections/Footer';
import { searchProducts } from '@/data/products';
import { useCartStore } from '@/store/cartStore';
import { toast } from 'sonner';
import type { Product } from '@/types';
import { getColorName } from '@/types';

interface ProductCardProps {
  product: Product;
}

const ProductCard = ({ product }: ProductCardProps) => {
  const addItem = useCartStore(state => state.addItem);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    addItem({
      product_id: product.id,
      name: product.name,
      price: product.price,
      quantity: 1,
      size: product.sizes[0],
      color: getColorName(product.colors[0]),
      image: product.image,
      stock: product.stock || 10,
    });
    
    toast.success(`${product.name} added to cart`);
  };

  return (
    <Link to={`/product/${product.id}`} className="group block">
      <div className="relative overflow-hidden bg-gray-100 mb-4">
        <div className="aspect-[3/4] relative">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        </div>

        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1">
          {product.is_new && (
            <span className="bg-black text-white text-[10px] px-2 py-1 tracking-wider">NEW</span>
          )}
          {product.is_sale && (
            <span className="bg-red-600 text-white text-[10px] px-2 py-1 tracking-wider">SALE</span>
          )}
        </div>

        {/* Quick Add */}
        <button
          onClick={handleAddToCart}
          className="absolute bottom-0 left-0 right-0 bg-black text-white py-3 text-sm tracking-wider opacity-0 group-hover:opacity-100 transition-opacity"
        >
          QUICK ADD
        </button>
      </div>

      <h3 className="text-sm font-medium text-gray-900 group-hover:text-gray-600 transition-colors">
        {product.name}
      </h3>
      <div className="flex items-center gap-2 mt-1">
        <span className="text-sm font-semibold">{product.price} EGP</span>
        {product.original_price && (
          <span className="text-sm text-gray-400 line-through">{product.original_price} EGP</span>
        )}
      </div>
    </Link>
  );
};

export const Search = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialQuery = searchParams.get('q') || '';
  
  const [query, setQuery] = useState(initialQuery);
  const [results, setResults] = useState<Product[]>([]);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);

  // Load recent searches from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('recentSearches');
    if (saved) {
      setRecentSearches(JSON.parse(saved));
    }
  }, []);

  // Perform search
  useEffect(() => {
    if (initialQuery) {
      const searchResults = searchProducts(initialQuery);
      setResults(searchResults);
      
      // Save to recent searches
      if (initialQuery.trim()) {
        const updated = [initialQuery, ...recentSearches.filter(s => s !== initialQuery)].slice(0, 5);
        setRecentSearches(updated);
        localStorage.setItem('recentSearches', JSON.stringify(updated));
      }
    } else {
      setResults([]);
    }
  }, [initialQuery]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      setSearchParams({ q: query.trim() });
    }
  };

  const clearSearch = () => {
    setQuery('');
    setSearchParams({});
  };

  const removeRecentSearch = (search: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = recentSearches.filter(s => s !== search);
    setRecentSearches(updated);
    localStorage.setItem('recentSearches', JSON.stringify(updated));
  };

  return (
    <div className="min-h-screen">
      <Navigation />
      
      <main className="pt-[104px]">
        <div className="container mx-auto px-4 py-8">
          <h1 className="text-2xl lg:text-3xl font-bold tracking-wider mb-8">SEARCH</h1>

          {/* Search Form */}
          <form onSubmit={handleSearch} className="max-w-2xl mx-auto mb-12">
            <div className="relative">
              <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search for products..."
                className="w-full pl-12 pr-12 py-4 border border-gray-300 focus:border-black focus:outline-none text-lg"
              />
              {query && (
                <button
                  type="button"
                  onClick={clearSearch}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-black"
                >
                  <X size={20} />
                </button>
              )}
            </div>
          </form>

          {/* Recent Searches */}
          {!initialQuery && recentSearches.length > 0 && (
            <div className="max-w-2xl mx-auto mb-12">
              <h2 className="text-sm font-medium text-gray-500 mb-4">RECENT SEARCHES</h2>
              <div className="flex flex-wrap gap-2">
                {recentSearches.map((search) => (
                  <button
                    key={search}
                    onClick={() => {
                      setQuery(search);
                      setSearchParams({ q: search });
                    }}
                    className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 transition-colors"
                  >
                    <span>{search}</span>
                    <X
                      size={14}
                      className="text-gray-400 hover:text-red-500"
                      onClick={(e) => removeRecentSearch(search, e)}
                    />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Search Results */}
          {initialQuery && (
            <div>
              <div className="flex items-center justify-between mb-6">
                <p className="text-gray-600">
                  {results.length} results for "{initialQuery}"
                </p>
              </div>

              {results.length > 0 ? (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 lg:gap-6">
                  {results.map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-16">
                  <SearchIcon className="mx-auto mb-4 text-gray-300" size={48} />
                  <h3 className="text-lg font-medium mb-2">No results found</h3>
                  <p className="text-gray-500 mb-6">
                    We could not find any products matching "{initialQuery}"
                  </p>
                  <div className="space-y-2">
                    <p className="text-sm text-gray-500">Try:</p>
                    <ul className="text-sm text-gray-500">
                      <li>Checking your spelling</li>
                      <li>Using more general keywords</li>
                      <li>Searching for a different term</li>
                    </ul>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Search;

import { useState, useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { Link } from 'react-router-dom';
import { Heart, ShoppingBag, GraduationCap, Check, ArrowRight } from 'lucide-react';
import { products } from '@/data/products';
import { useCart } from '@/hooks/useCart';
import type { Product } from '@/types';
import { getColorName } from '@/types';

const schoolProducts = products.filter((p) => p.category === 'school' || p.category === 'accessories');

const schoolFeatures = [
  'Durable, easy-care fabrics',
  'Custom embroidery available',
  'Bulk discounts for schools',
  'Size exchanges guaranteed',
];

function ProductCard({ product }: { product: Product }) {
  const [isHovered, setIsHovered] = useState(false);
  const { addItem } = useCart();

  const handleQuickAdd = () => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      size: product.sizes[0],
      color: getColorName(product.colors[0]),
    });
  };

  return (
    <div
      className="group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <Link to={`/product/${product.id}`} className="block">
        <div className="relative aspect-[3/4] overflow-hidden bg-neutral-100 mb-4">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          
          <div
            className={`absolute inset-x-0 bottom-0 p-4 flex justify-center gap-3 transition-all duration-300 ${
              isHovered ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            <button
              onClick={(e) => {
                e.preventDefault();
                handleQuickAdd();
              }}
              className="p-3 bg-white hover:bg-black hover:text-white transition-colors"
              aria-label="Add to cart"
            >
              <ShoppingBag className="w-5 h-5" />
            </button>
            <button
              onClick={(e) => e.preventDefault()}
              className="p-3 bg-white hover:bg-black hover:text-white transition-colors"
              aria-label="Add to wishlist"
            >
              <Heart className="w-5 h-5" />
            </button>
          </div>
        </div>
      </Link>

      <div className="space-y-2">
        <Link to={`/product/${product.id}`}>
          <h3 className="text-sm font-medium tracking-wide group-hover:opacity-70 transition-opacity">
            {product.name}
          </h3>
        </Link>
        <span className="text-sm font-semibold">${product.price}</span>
      </div>
    </div>
  );
}

export function School() {
  const gridRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const grid = gridRef.current;
    if (!grid) return;

    const cards = grid.querySelectorAll('.product-card');
    gsap.fromTo(
      cards,
      { y: 40, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.6, stagger: 0.1, ease: 'power2.out', delay: 0.3 }
    );
  }, []);

  return (
    <div className="min-h-screen bg-white pt-24 lg:pt-28">
      {/* Hero Banner */}
      <div className="relative h-[400px] lg:h-[500px] overflow-hidden">
        <img
          src="/images/hero-school.jpg"
          alt="School Uniforms"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/50" />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white">
            <p className="text-sm tracking-[0.3em] mb-4 uppercase">Education</p>
            <h1 className="text-4xl lg:text-6xl font-bold tracking-tight">SCHOOL UNIFORMS</h1>
            <p className="mt-4 text-white/80 max-w-md mx-auto">
              Modern uniforms that students actually want to wear
            </p>
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-16">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {schoolFeatures.map((feature, index) => (
            <div key={index} className="flex items-center gap-3">
              <div className="w-10 h-10 bg-black flex items-center justify-center flex-shrink-0">
                <Check className="w-5 h-5 text-white" />
              </div>
              <span className="text-sm font-medium">{feature}</span>
            </div>
          ))}
        </div>
      </div>

      {/* School Uniform Finder */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-16 bg-neutral-50">
        <div className="max-w-4xl mx-auto text-center">
          <GraduationCap className="w-16 h-16 mx-auto mb-6" />
          <h2 className="text-2xl lg:text-4xl font-bold mb-4">UNIFORM LOOKUP</h2>
          <p className="text-black/70 mb-8">
            Find your school's specific uniform requirements quickly and easily.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto">
            <input
              type="text"
              placeholder="Enter school name..."
              className="flex-1 px-4 py-4 border border-black/20 focus:outline-none focus:border-black"
            />
            <button className="px-8 py-4 bg-black text-white font-medium tracking-wider hover:bg-black/90 transition-colors">
              SEARCH
            </button>
          </div>
        </div>
      </div>

      {/* Products */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-16">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl lg:text-3xl font-bold">SCHOOL ESSENTIALS</h2>
          <Link
            to="/category/school"
            className="text-sm font-medium hover:opacity-70 transition-opacity"
          >
            View All
          </Link>
        </div>
        
        <div ref={gridRef} className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-8">
          {schoolProducts.map((product) => (
            <div key={product.id} className="product-card">
              <ProductCard product={product} />
            </div>
          ))}
        </div>
      </div>

      {/* School Program CTA */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          <div>
            <img
              src="/images/category-school.jpg"
              alt="School Program"
              className="w-full aspect-[4/3] object-cover"
            />
          </div>
          <div className="lg:pl-8">
            <h2 className="text-2xl lg:text-4xl font-bold mb-4">
              SCHOOL PARTNERSHIP PROGRAM
            </h2>
            <p className="text-black/70 mb-6">
              Partner with EXA for your school's uniform needs. We offer dedicated account
              managers, custom designs, parent portals, and flexible payment options.
            </p>
            <ul className="space-y-3 mb-8">
              <li className="flex items-center gap-2">
                <Check className="w-4 h-4" />
                <span className="text-sm">Custom branding and embroidery</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-4 h-4" />
                <span className="text-sm">Online ordering for parents</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-4 h-4" />
                <span className="text-sm">Bulk pricing and seasonal discounts</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-4 h-4" />
                <span className="text-sm">Dedicated support team</span>
              </li>
            </ul>
            <Link
              to="/school-programs"
              className="inline-flex items-center gap-2 px-8 py-4 bg-black text-white font-medium tracking-wider hover:bg-black/90 transition-colors"
            >
              LEARN MORE
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

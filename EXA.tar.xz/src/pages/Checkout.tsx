import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CreditCard, Truck, Shield, Check, Lock, ArrowLeft } from 'lucide-react';
import { useCart } from '@/hooks/useCart';

// Use environment variables - NEVER hardcode API keys
const PAYMOB_INTEGRATION_ID = import.meta.env.VITE_PAYMOB_INTEGRATION_ID || '5558687';
const PAYMOB_IFRAME_ID = import.meta.env.VITE_PAYMOB_IFRAME_ID || '1010526';
const PAYMOB_API_KEY = import.meta.env.VITE_PAYMOB_API_KEY;

interface ShippingInfo {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
}

export function Checkout() {
  const navigate = useNavigate();
  const { items, total, clearCart } = useCart();
  const [step, setStep] = useState<'shipping' | 'payment' | 'processing' | 'success'>('shipping');
  const [isLoading, setIsLoading] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'paymob' | 'cod'>('paymob');
  
  const [shippingInfo, setShippingInfo] = useState<ShippingInfo>({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    country: 'Egypt',
  });

  const shipping = total >= 1500 ? 0 : 50; // Free shipping over 1500 EGP
  const finalTotal = total + shipping;

  const handleShippingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('payment');
    window.scrollTo(0, 0);
  };

  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!PAYMOB_API_KEY) {
      alert('Payment configuration missing. Please check environment variables.');
      console.error('VITE_PAYMOB_API_KEY is not set in .env file');
      return;
    }

    setIsLoading(true);
    setStep('processing');

    if (paymentMethod === 'paymob') {
      try {
        // Step 1: Get authentication token
        const authResponse = await fetch('https://accept.paymob.com/api/auth/tokens', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ api_key: PAYMOB_API_KEY }),
        });
        
        if (!authResponse.ok) throw new Error('Authentication failed');
        const authData = await authResponse.json();
        const token = authData.token;

        // Step 2: Create order
        const orderResponse = await fetch('https://accept.paymob.com/api/ecommerce/orders', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            auth_token: token,
            delivery_needed: 'false',
            amount_cents: Math.round(finalTotal * 100),
            currency: 'EGP',
            items: items.map((item) => ({
              name: item.name,
              amount_cents: Math.round(item.price * 100),
              description: `${item.name} - Size: ${item.size || 'N/A'}, Color: ${item.color || 'N/A'}`,
              quantity: item.quantity,
            })),
          }),
        });
        
        if (!orderResponse.ok) throw new Error('Order creation failed');
        const orderData = await orderResponse.json();
        const orderId = orderData.id;

        // Step 3: Generate payment key
        const paymentKeyResponse = await fetch('https://accept.paymob.com/api/acceptance/payment_keys', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            auth_token: token,
            amount_cents: Math.round(finalTotal * 100),
            expiration: 3600,
            order_id: orderId,
            billing_data: {
              apartment: 'NA',
              email: shippingInfo.email,
              floor: 'NA',
              first_name: shippingInfo.firstName,
              street: shippingInfo.address,
              building: 'NA',
              phone_number: shippingInfo.phone,
              shipping_method: 'NA',
              postal_code: shippingInfo.zipCode || '00000',
              city: shippingInfo.city,
              country: shippingInfo.country === 'Egypt' ? 'EG' : 'EG',
              last_name: shippingInfo.lastName,
              state: shippingInfo.state,
            },
            currency: 'EGP',
            integration_id: parseInt(PAYMOB_INTEGRATION_ID),
            lock_order_when_paid: false,
          }),
        });
        
        if (!paymentKeyResponse.ok) throw new Error('Payment key generation failed');
        const paymentKeyData = await paymentKeyResponse.json();
        const paymentToken = paymentKeyData.token;

        // Step 4: Redirect to Paymob IFrame
        window.location.href = `https://accept.paymob.com/api/acceptance/iframes/${PAYMOB_IFRAME_ID}?payment_token=${paymentToken}`;

      } catch (error) {
        console.error('Paymob payment error:', error);
        alert('Payment processing failed. Please try again or contact support.');
        setIsLoading(false);
        setStep('payment');
      }
    } else {
      // Cash on Delivery
      setTimeout(() => {
        clearCart();
        setStep('success');
        setIsLoading(false);
      }, 2000);
    }
  };

  if (items.length === 0 && step !== 'success') {
    navigate('/cart');
    return null;
  }

  return (
    <div className="min-h-screen bg-white pt-24 lg:pt-28">
      <div className="w-full px-4 sm:px-6 lg:px-12 py-8 lg:py-16">
        {/* Progress Steps */}
        <div className="max-w-4xl mx-auto mb-12">
          <div className="flex items-center justify-center">
            <div className={`flex items-center ${step === 'shipping' ? 'text-black' : 'text-black/40'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                step === 'shipping' ? 'bg-black text-white' : 'bg-black/20'
              }`}>
                1
              </div>
              <span className="ml-2 text-sm font-medium">Shipping</span>
            </div>
            <div className="w-16 h-px bg-black/20 mx-4" />
            <div className={`flex items-center ${step === 'payment' ? 'text-black' : 'text-black/40'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                step === 'payment' ? 'bg-black text-white' : 'bg-black/20'
              }`}>
                2
              </div>
              <span className="ml-2 text-sm font-medium">Payment</span>
            </div>
            <div className="w-16 h-px bg-black/20 mx-4" />
            <div className={`flex items-center ${step === 'success' ? 'text-black' : 'text-black/40'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                step === 'success' ? 'bg-black text-white' : 'bg-black/20'
              }`}>
                3
              </div>
              <span className="ml-2 text-sm font-medium">Confirmation</span>
            </div>
          </div>
        </div>

        {/* Success State */}
        {step === 'success' && (
          <div className="max-w-2xl mx-auto text-center py-16">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Check className="w-10 h-10 text-green-600" />
            </div>
            <h1 className="text-3xl font-bold mb-4">ORDER CONFIRMED!</h1>
            <p className="text-black/60 mb-8">
              Thank you for your purchase. You will receive a confirmation email shortly.
            </p>
            <div className="bg-neutral-50 p-6 mb-8 text-left">
              <h3 className="font-semibold mb-4">Order Details</h3>
              <p className="text-sm text-black/60">Order #: EXA-{Date.now().toString().slice(-8)}</p>
              <p className="text-sm text-black/60">Total: EGP {finalTotal.toFixed(2)}</p>
            </div>
            <button
              onClick={() => navigate('/')}
              className="px-8 py-4 bg-black text-white font-medium tracking-wider hover:bg-black/90 transition-colors"
            >
              CONTINUE SHOPPING
            </button>
          </div>
        )}

        {/* Processing State */}
        {step === 'processing' && (
          <div className="max-w-2xl mx-auto text-center py-16">
            <div className="w-16 h-16 border-4 border-black border-t-transparent rounded-full animate-spin mx-auto mb-6" />
            <h2 className="text-2xl font-bold mb-4">Processing Payment...</h2>
            <p className="text-black/60">
              Please do not close this window. You will be redirected to complete your payment.
            </p>
          </div>
        )}

        {/* Shipping Form */}
        {step === 'shipping' && (
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <h2 className="text-xl font-bold mb-6">SHIPPING INFORMATION</h2>
                <form onSubmit={handleShippingSubmit} className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium mb-2 block">First Name *</label>
                      <input
                        type="text"
                        required
                        value={shippingInfo.firstName}
                        onChange={(e) => setShippingInfo({ ...shippingInfo, firstName: e.target.value })}
                        className="w-full px-4 py-3 border border-black/20 focus:outline-none focus:border-black"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-2 block">Last Name *</label>
                      <input
                        type="text"
                        required
                        value={shippingInfo.lastName}
                        onChange={(e) => setShippingInfo({ ...shippingInfo, lastName: e.target.value })}
                        className="w-full px-4 py-3 border border-black/20 focus:outline-none focus:border-black"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium mb-2 block">Email *</label>
                      <input
                        type="email"
                        required
                        value={shippingInfo.email}
                        onChange={(e) => setShippingInfo({ ...shippingInfo, email: e.target.value })}
                        className="w-full px-4 py-3 border border-black/20 focus:outline-none focus:border-black"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-2 block">Phone *</label>
                      <input
                        type="tel"
                        required
                        value={shippingInfo.phone}
                        onChange={(e) => setShippingInfo({ ...shippingInfo, phone: e.target.value })}
                        className="w-full px-4 py-3 border border-black/20 focus:outline-none focus:border-black"
                        placeholder="01xxxxxxxxx"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Address *</label>
                    <input
                      type="text"
                      required
                      value={shippingInfo.address}
                      onChange={(e) => setShippingInfo({ ...shippingInfo, address: e.target.value })}
                      className="w-full px-4 py-3 border border-black/20 focus:outline-none focus:border-black"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium mb-2 block">City *</label>
                      <input
                        type="text"
                        required
                        value={shippingInfo.city}
                        onChange={(e) => setShippingInfo({ ...shippingInfo, city: e.target.value })}
                        className="w-full px-4 py-3 border border-black/20 focus:outline-none focus:border-black"
                        placeholder="Cairo"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-2 block">State/Governorate *</label>
                      <input
                        type="text"
                        required
                        value={shippingInfo.state}
                        onChange={(e) => setShippingInfo({ ...shippingInfo, state: e.target.value })}
                        className="w-full px-4 py-3 border border-black/20 focus:outline-none focus:border-black"
                        placeholder="Cairo"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium mb-2 block">Postal Code</label>
                      <input
                        type="text"
                        value={shippingInfo.zipCode}
                        onChange={(e) => setShippingInfo({ ...shippingInfo, zipCode: e.target.value })}
                        className="w-full px-4 py-3 border border-black/20 focus:outline-none focus:border-black"
                        placeholder="Optional"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-2 block">Country *</label>
                      <select
                        value={shippingInfo.country}
                        onChange={(e) => setShippingInfo({ ...shippingInfo, country: e.target.value })}
                        className="w-full px-4 py-3 border border-black/20 focus:outline-none focus:border-black bg-white"
                      >
                        <option>Egypt</option>
                        <option>United Arab Emirates</option>
                        <option>Saudi Arabia</option>
                        <option>Kuwait</option>
                        <option>Qatar</option>
                      </select>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-black text-white font-medium tracking-wider hover:bg-black/90 transition-colors"
                  >
                    CONTINUE TO PAYMENT
                  </button>
                </form>
              </div>

              {/* Order Summary */}
              <div className="bg-neutral-50 p-6 h-fit">
                <h3 className="font-bold mb-4">ORDER SUMMARY</h3>
                <div className="space-y-3 mb-6">
                  {items.map((item) => (
                    <div key={`${item.id}-${item.size}-${item.color}`} className="flex gap-3">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-16 h-20 object-cover bg-white"
                      />
                      <div className="flex-1">
                        <p className="text-sm font-medium">{item.name}</p>
                        <p className="text-xs text-black/60">
                          {item.size} / {item.color} / Qty: {item.quantity}
                        </p>
                        <p className="text-sm font-semibold mt-1">
                          EGP {item.price * item.quantity}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="space-y-2 pt-4 border-t border-black/10">
                  <div className="flex justify-between text-sm">
                    <span className="text-black/60">Subtotal</span>
                    <span>EGP {total.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-black/60">Shipping</span>
                    <span>{shipping === 0 ? 'FREE' : `EGP ${shipping.toFixed(2)}`}</span>
                  </div>
                  <div className="flex justify-between text-lg font-bold pt-2 border-t border-black/10">
                    <span>TOTAL</span>
                    <span>EGP {finalTotal.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Payment Form */}
        {step === 'payment' && (
          <div className="max-w-4xl mx-auto">
            <button
              onClick={() => setStep('shipping')}
              className="flex items-center gap-2 text-sm text-black/60 hover:text-black mb-6"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Shipping
            </button>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <h2 className="text-xl font-bold mb-6">PAYMENT METHOD</h2>
                
                <form onSubmit={handlePaymentSubmit} className="space-y-6">
                  {/* Payment Methods */}
                  <div className="space-y-4">
                    {/* Paymob Card Payment */}
                    <label
                      className={`flex items-start gap-4 p-6 border-2 cursor-pointer transition-colors ${
                        paymentMethod === 'paymob'
                          ? 'border-black bg-neutral-50'
                          : 'border-black/20 hover:border-black/40'
                      }`}
                    >
                      <input
                        type="radio"
                        name="payment"
                        value="paymob"
                        checked={paymentMethod === 'paymob'}
                        onChange={() => setPaymentMethod('paymob')}
                        className="mt-1 w-4 h-4 accent-black"
                      />
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <CreditCard className="w-5 h-5" />
                          <span className="font-semibold">Credit/Debit Card (Paymob)</span>
                        </div>
                        <p className="text-sm text-black/60">
                          Secure payment powered by Paymob. Accepts Visa, Mastercard, Meeza, and mobile wallets.
                        </p>
                        <div className="flex gap-2 mt-3">
                          <span className="px-2 py-1 bg-white border text-xs">VISA</span>
                          <span className="px-2 py-1 bg-white border text-xs">MASTERCARD</span>
                          <span className="px-2 py-1 bg-white border text-xs">MEEZA</span>
                        </div>
                      </div>
                    </label>

                    {/* Cash on Delivery */}
                    <label
                      className={`flex items-start gap-4 p-6 border-2 cursor-pointer transition-colors ${
                        paymentMethod === 'cod'
                          ? 'border-black bg-neutral-50'
                          : 'border-black/20 hover:border-black/40'
                      }`}
                    >
                      <input
                        type="radio"
                        name="payment"
                        value="cod"
                        checked={paymentMethod === 'cod'}
                        onChange={() => setPaymentMethod('cod')}
                        className="mt-1 w-4 h-4 accent-black"
                      />
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <Truck className="w-5 h-5" />
                          <span className="font-semibold">Cash on Delivery</span>
                        </div>
                        <p className="text-sm text-black/60">
                          Pay when your order arrives. Additional EGP 50 COD fee applies.
                        </p>
                      </div>
                    </label>
                  </div>

                  {/* Paymob Integration Note */}
                  {paymentMethod === 'paymob' && (
                    <div className="p-4 bg-blue-50 border border-blue-200">
                      <div className="flex items-start gap-3">
                        <Lock className="w-5 h-5 text-blue-600 mt-0.5" />
                        <div>
                          <p className="text-sm font-medium text-blue-900">
                            Secure Payment Processing
                          </p>
                          <p className="text-sm text-blue-700 mt-1">
                            You will be redirected to Paymob's secure payment gateway to complete 
                            your transaction. Your card details are never stored on our servers.
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-black text-white font-medium tracking-wider hover:bg-black/90 transition-colors disabled:opacity-50"
                  >
                    {isLoading ? (
                      <>
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        PROCESSING...
                      </>
                    ) : (
                      <>
                        <Lock className="w-4 h-4" />
                        {paymentMethod === 'paymob' ? 'PAY WITH CARD' : 'PLACE ORDER (COD)'}
                      </>
                    )}
                  </button>
                </form>

                {/* Security Badges */}
                <div className="flex items-center justify-center gap-6 mt-8 pt-8 border-t border-black/10">
                  <div className="flex items-center gap-2 text-sm text-black/60">
                    <Shield className="w-5 h-5" />
                    <span>SSL Secured</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-black/60">
                    <Lock className="w-5 h-5" />
                    <span>Encrypted</span>
                  </div>
                </div>
              </div>

              {/* Order Summary */}
              <div className="bg-neutral-50 p-6 h-fit">
                <h3 className="font-bold mb-4">ORDER SUMMARY</h3>
                
                {/* Shipping Address */}
                <div className="mb-6 pb-6 border-b border-black/10">
                  <p className="text-sm font-medium mb-2">Shipping to:</p>
                  <p className="text-sm text-black/60">
                    {shippingInfo.firstName} {shippingInfo.lastName}<br />
                    {shippingInfo.address}<br />
                    {shippingInfo.city}, {shippingInfo.state}<br />
                    {shippingInfo.country}
                  </p>
                  <button
                    onClick={() => setStep('shipping')}
                    className="text-sm text-black/60 hover:text-black underline mt-2"
                  >
                    Edit
                  </button>
                </div>

                {/* Items */}
                <div className="space-y-3 mb-6 max-h-48 overflow-auto">
                  {items.map((item) => (
                    <div key={`${item.id}-${item.size}-${item.color}`} className="flex gap-3">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-12 h-16 object-cover bg-white"
                      />
                      <div className="flex-1">
                        <p className="text-sm font-medium">{item.name}</p>
                        <p className="text-xs text-black/60">
                          {item.size} / {item.color} / Qty: {item.quantity}
                        </p>
                      </div>
                      <p className="text-sm font-semibold">
                        EGP {item.price * item.quantity}
                      </p>
                    </div>
                  ))}
                </div>

                {/* Totals */}
                <div className="space-y-2 pt-4 border-t border-black/10">
                  <div className="flex justify-between text-sm">
                    <span className="text-black/60">Subtotal</span>
                    <span>EGP {total.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-black/60">Shipping</span>
                    <span>{shipping === 0 ? 'FREE' : `EGP ${shipping.toFixed(2)}`}</span>
                  </div>
                  {paymentMethod === 'cod' && (
                    <div className="flex justify-between text-sm">
                      <span className="text-black/60">COD Fee</span>
                      <span>EGP 50.00</span>
                    </div>
                  )}
                  <div className="flex justify-between text-lg font-bold pt-2 border-t border-black/10">
                    <span>TOTAL</span>
                    <span>EGP {(finalTotal + (paymentMethod === 'cod' ? 50 : 0)).toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

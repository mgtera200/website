import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ChevronLeft, Package, Truck, MapPin, CreditCard } from 'lucide-react';
import { Navigation } from '@/components/Navigation';
import { Footer } from '@/sections/Footer';
import { getOrderById } from '@/lib/supabase';
import { toast } from 'sonner';
import type { Order } from '@/types';

const statusSteps = [
  { key: 'pending', label: 'Order Placed' },
  { key: 'confirmed', label: 'Confirmed' },
  { key: 'processing', label: 'Processing' },
  { key: 'shipped', label: 'Shipped' },
  { key: 'delivered', label: 'Delivered' },
];

const statusColors: Record<string, string> = {
  pending: 'bg-yellow-100 text-yellow-800',
  confirmed: 'bg-blue-100 text-blue-800',
  processing: 'bg-purple-100 text-purple-800',
  shipped: 'bg-indigo-100 text-indigo-800',
  delivered: 'bg-green-100 text-green-800',
  cancelled: 'bg-red-100 text-red-800',
  refunded: 'bg-gray-100 text-gray-800',
};

export const OrderDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [order, setOrder] = useState<Order | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchOrder = async () => {
      if (!id) return;

      try {
        const { data, error } = await getOrderById(id);
        if (error) {
          toast.error('Failed to load order');
          return;
        }
        if (data) {
          setOrder(data);
        }
      } catch {
        toast.error('An error occurred');
      } finally {
        setIsLoading(false);
      }
    };

    fetchOrder();
  }, [id]);

  if (isLoading) {
    return (
      <div className="min-h-screen">
        <Navigation />
        <main className="pt-[104px]">
          <div className="flex items-center justify-center py-16">
            <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-black" />
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!order) {
    return (
      <div className="min-h-screen">
        <Navigation />
        <main className="pt-[104px]">
          <div className="container mx-auto px-4 py-16 text-center">
            <h1 className="text-2xl font-bold mb-4">Order Not Found</h1>
            <Link to="/account/orders" className="text-black hover:underline">
              ← Back to orders
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const currentStepIndex = statusSteps.findIndex(s => s.key === order.status);

  return (
    <div className="min-h-screen">
      <Navigation />
      
      <main className="pt-[104px]">
        <div className="container mx-auto px-4 py-8">
          <Link
            to="/account/orders"
            className="inline-flex items-center gap-2 text-gray-600 hover:text-black mb-6"
          >
            <ChevronLeft size={18} />
            Back to Orders
          </Link>

          <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
            <div>
              <h1 className="text-2xl font-bold">Order {order.order_number}</h1>
              <p className="text-gray-500">
                Placed on {new Date(order.created_at).toLocaleDateString('en-US', {
                  month: 'long',
                  day: 'numeric',
                  year: 'numeric',
                })}
              </p>
            </div>
            <span className={`px-4 py-2 text-sm font-medium ${statusColors[order.status]}`}>
              {order.status.toUpperCase()}
            </span>
          </div>

          {/* Progress Bar */}
          {order.status !== 'cancelled' && order.status !== 'refunded' && (
            <div className="mb-12">
              <div className="flex items-center">
                {statusSteps.map((step, index) => (
                  <div key={step.key} className="flex-1 flex items-center">
                    <div className="flex flex-col items-center">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center text-sm ${
                          index <= currentStepIndex
                            ? 'bg-black text-white'
                            : 'bg-gray-200 text-gray-500'
                        }`}
                      >
                        {index < currentStepIndex ? '✓' : index + 1}
                      </div>
                      <span className="text-xs mt-2 text-gray-500">{step.label}</span>
                    </div>
                    {index < statusSteps.length - 1 && (
                      <div
                        className={`flex-1 h-1 mx-2 ${
                          index < currentStepIndex ? 'bg-black' : 'bg-gray-200'
                        }`}
                      />
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Order Items */}
            <div className="lg:col-span-2">
              <div className="border p-6 mb-6">
                <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <Package size={20} />
                  Order Items
                </h2>
                <div className="space-y-4">
                  {order.items?.map((item, index) => (
                    <div key={index} className="flex gap-4 py-4 border-b last:border-0">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-20 h-20 object-cover"
                      />
                      <div className="flex-1">
                        <Link
                          to={`/product/${item.product_id}`}
                          className="font-medium hover:text-gray-600"
                        >
                          {item.name}
                        </Link>
                        <p className="text-sm text-gray-500">
                          Size: {item.size} | Color: {item.color}
                        </p>
                        <p className="text-sm text-gray-500">Qty: {item.quantity}</p>
                      </div>
                      <p className="font-medium">{item.price * item.quantity} EGP</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Tracking Info */}
              {order.tracking_number && (
                <div className="border p-6">
                  <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
                    <Truck size={20} />
                    Tracking Information
                  </h2>
                  <p className="text-sm text-gray-600 mb-2">
                    Tracking Number: <span className="font-medium">{order.tracking_number}</span>
                  </p>
                  {order.tracking_url && (
                    <a
                      href={order.tracking_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm text-blue-600 hover:underline"
                    >
                      Track your order →
                    </a>
                  )}
                </div>
              )}
            </div>

            {/* Order Summary */}
            <div>
              <div className="border p-6 mb-6">
                <h2 className="text-lg font-bold mb-4">Order Summary</h2>
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Subtotal</span>
                    <span>{order.subtotal} EGP</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Shipping</span>
                    <span>{order.shipping_cost} EGP</span>
                  </div>
                  {order.discount_amount > 0 && (
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Discount</span>
                      <span className="text-green-600">-{order.discount_amount} EGP</span>
                    </div>
                  )}
                </div>
                <div className="border-t pt-4">
                  <div className="flex justify-between">
                    <span className="font-bold">Total</span>
                    <span className="font-bold text-xl">{order.total} EGP</span>
                  </div>
                </div>
              </div>

              {/* Shipping Address */}
              <div className="border p-6 mb-6">
                <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <MapPin size={20} />
                  Shipping Address
                </h2>
                <p className="text-sm text-gray-600">
                  {order.shipping_address.first_name} {order.shipping_address.last_name}<br />
                  {order.shipping_address.address_line1}<br />
                  {order.shipping_address.address_line2 && <>{order.shipping_address.address_line2}<br /></>}
                  {order.shipping_address.city}, {order.shipping_address.state} {order.shipping_address.postal_code}<br />
                  {order.shipping_address.country}<br />
                  Phone: {order.shipping_address.phone}
                </p>
              </div>

              {/* Payment Info */}
              <div className="border p-6">
                <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
                  <CreditCard size={20} />
                  Payment
                </h2>
                <p className="text-sm text-gray-600 capitalize">
                  Method: {order.payment_method}<br />
                  Status: <span className={statusColors[order.payment_status]}>
                    {order.payment_status}
                  </span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default OrderDetail;

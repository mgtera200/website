import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Heart, ShoppingBag, ChevronRight, Minus, Plus, Check, Truck, RotateCcw, Shield } from 'lucide-react';
import { products } from '@/data/products';
import { useCart } from '@/hooks/useCart';
import { getColorName, getColorHex } from '@/types';

const relatedProducts = products.slice(0, 4);

const productFeatures = [
  { icon: Truck, title: 'Free Shipping', description: 'On orders over $75' },
  { icon: RotateCcw, title: 'Easy Returns', description: '30-day return policy' },
  { icon: Shield, title: 'Quality Guarantee', description: 'Premium materials' },
];

export function ProductDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addItem } = useCart();
  
  const product = products.find((p) => p.id === id);
  
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [quantity, setQuantity] = useState(1);
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [showAddedMessage, setShowAddedMessage] = useState(false);
  // Image gallery state (for future multi-image support)
  // const [activeImage, setActiveImage] = useState(0);

  useEffect(() => {
    if (product) {
      setSelectedSize(product.sizes[0]);
      setSelectedColor(getColorName(product.colors[0]));
    }
  }, [product]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [id]);

  if (!product) {
    return (
      <div className="min-h-screen bg-white pt-24 lg:pt-28 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Product Not Found</h1>
          <Link to="/" className="text-black/60 hover:text-black underline">
            Return to Home
          </Link>
        </div>
      </div>
    );
  }

  const handleAddToCart = () => {
    if (!selectedSize || !selectedColor) return;
    
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      size: selectedSize,
      color: selectedColor,
    });
    
    setShowAddedMessage(true);
    setTimeout(() => setShowAddedMessage(false), 3000);
  };

  const handleBuyNow = () => {
    handleAddToCart();
    navigate('/cart');
  };

  return (
    <div className="min-h-screen bg-white pt-24 lg:pt-28">
      {/* Breadcrumb */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-4 border-b border-black/10">
        <nav className="flex items-center gap-2 text-sm text-black/60">
          <Link to="/" className="hover:text-black">Home</Link>
          <ChevronRight className="w-4 h-4" />
          <Link to={`/${product.category}`} className="hover:text-black capitalize">
            {product.category}
          </Link>
          <ChevronRight className="w-4 h-4" />
          <span className="text-black">{product.name}</span>
        </nav>
      </div>

      {/* Product Section */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-8 lg:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16">
          {/* Image Gallery */}
          <div className="space-y-4">
            <div className="aspect-[3/4] bg-neutral-100 overflow-hidden">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Product Info */}
          <div className="lg:sticky lg:top-28 lg:self-start">
            {/* Badges */}
            <div className="flex gap-2 mb-4">
              {product.isNew && (
                <span className="px-3 py-1 bg-black text-white text-xs font-medium tracking-wider">
                  NEW
                </span>
              )}
              {product.isSale && (
                <span className="px-3 py-1 bg-black text-white text-xs font-medium tracking-wider">
                  SALE
                </span>
              )}
            </div>

            <h1 className="text-2xl lg:text-4xl font-bold mb-4">{product.name}</h1>
            
            <div className="flex items-center gap-3 mb-6">
              <span className="text-2xl font-semibold">${product.price}</span>
              {product.originalPrice && (
                <span className="text-lg text-black/50 line-through">
                  ${product.originalPrice}
                </span>
              )}
            </div>

            <p className="text-black/70 mb-8 leading-relaxed">
              Premium quality {product.name.toLowerCase()} designed for comfort and style. 
              Made with high-quality materials that last. Perfect for everyday wear.
            </p>

            {/* Color Selection */}
            <div className="mb-6">
              <h3 className="text-sm font-semibold mb-3">
                COLOR: <span className="font-normal text-black/60">{selectedColor}</span>
              </h3>
              <div className="flex gap-3">
                {product.colors.map((color, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedColor(getColorName(color))}
                    className={`w-10 h-10 rounded-full border-2 transition-all ${
                      selectedColor === getColorName(color)
                        ? 'border-black scale-110'
                        : 'border-black/20 hover:border-black/50'
                    }`}
                    style={{ backgroundColor: getColorHex(color) }}
                    title={getColorName(color)}
                  />
                ))}
              </div>
            </div>

            {/* Size Selection */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold">
                  SIZE: <span className="font-normal text-black/60">{selectedSize}</span>
                </h3>
                <Link to="/size-guide" className="text-sm text-black/60 hover:text-black underline">
                  Size Guide
                </Link>
              </div>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((size) => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`px-4 py-3 text-sm border transition-colors ${
                      selectedSize === size
                        ? 'bg-black text-white border-black'
                        : 'border-black/20 hover:border-black'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity */}
            <div className="mb-8">
              <h3 className="text-sm font-semibold mb-3">QUANTITY</h3>
              <div className="flex items-center border border-black/20 w-fit">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="p-3 hover:bg-black/5 transition-colors"
                  aria-label="Decrease quantity"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="w-12 text-center font-medium">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="p-3 hover:bg-black/5 transition-colors"
                  aria-label="Increase quantity"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-4 mb-8">
              <button
                onClick={handleAddToCart}
                className="flex-1 flex items-center justify-center gap-2 px-6 py-4 bg-black text-white font-medium tracking-wider hover:bg-black/90 transition-colors"
              >
                <ShoppingBag className="w-5 h-5" />
                ADD TO CART
              </button>
              <button
                onClick={handleBuyNow}
                className="flex-1 px-6 py-4 border border-black font-medium tracking-wider hover:bg-black hover:text-white transition-colors"
              >
                BUY NOW
              </button>
              <button
                onClick={() => setIsWishlisted(!isWishlisted)}
                className={`p-4 border transition-colors ${
                  isWishlisted
                    ? 'border-black bg-black text-white'
                    : 'border-black/20 hover:border-black'
                }`}
                aria-label="Add to wishlist"
              >
                <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-current' : ''}`} />
              </button>
            </div>

            {/* Added to Cart Message */}
            {showAddedMessage && (
              <div className="mb-6 p-4 bg-green-50 border border-green-200 flex items-center gap-3">
                <Check className="w-5 h-5 text-green-600" />
                <span className="text-green-800">Added to cart successfully!</span>
                <Link to="/cart" className="ml-auto text-green-800 underline">
                  View Cart
                </Link>
              </div>
            )}

            {/* Features */}
            <div className="grid grid-cols-3 gap-4 pt-8 border-t border-black/10">
              {productFeatures.map((feature) => (
                <div key={feature.title} className="text-center">
                  <feature.icon className="w-6 h-6 mx-auto mb-2" />
                  <h4 className="text-xs font-semibold mb-1">{feature.title}</h4>
                  <p className="text-xs text-black/60">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Related Products */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-16 bg-neutral-50">
        <h2 className="text-2xl font-bold mb-8">YOU MAY ALSO LIKE</h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-8">
          {relatedProducts.map((relatedProduct) => (
            <Link
              key={relatedProduct.id}
              to={`/product/${relatedProduct.id}`}
              className="group"
            >
              <div className="aspect-[3/4] bg-neutral-100 overflow-hidden mb-4">
                <img
                  src={relatedProduct.image}
                  alt={relatedProduct.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <h3 className="text-sm font-medium group-hover:opacity-70 transition-opacity">
                {relatedProduct.name}
              </h3>
              <span className="text-sm font-semibold">${relatedProduct.price}</span>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}

import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { products } from '@/data/products';
import { useCart } from '@/hooks/useCart';
import { getColorName } from '@/types';

const newProducts = products.filter((p) => p.isNew);

export function NewIn() {
  const { addItem } = useCart();

  return (
    <div className="min-h-screen bg-white pt-24 lg:pt-28">
      {/* Hero */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-12 lg:py-20">
        <div className="max-w-4xl mx-auto text-center">
          <span className="inline-block px-4 py-2 bg-black text-white text-sm font-medium tracking-wider mb-6">
            NEW ARRIVALS
          </span>
          <h1 className="text-4xl lg:text-6xl font-bold mb-6">JUST DROPPED</h1>
          <p className="text-lg text-black/60 max-w-2xl mx-auto">
            Discover our latest collection of contemporary fashion and professional uniforms. 
            Fresh styles, premium quality.
          </p>
        </div>
      </div>

      {/* Products */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-12 bg-neutral-50">
        {newProducts.length > 0 ? (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-8">
            {newProducts.map((product) => (
              <div key={product.id} className="group bg-white">
                <Link to={`/product/${product.id}`} className="block">
                  <div className="relative aspect-[3/4] overflow-hidden bg-neutral-100 mb-4">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <span className="absolute top-3 left-3 px-3 py-1 bg-black text-white text-xs font-medium tracking-wider">
                      NEW
                    </span>
                  </div>
                </Link>

                <div className="p-4 space-y-2">
                  <Link to={`/product/${product.id}`}>
                    <h3 className="text-sm font-medium tracking-wide group-hover:opacity-70 transition-opacity">
                      {product.name}
                    </h3>
                  </Link>
                  <span className="text-sm font-semibold">${product.price}</span>
                  <button
                    onClick={() =>
                      addItem({
                        id: product.id,
                        name: product.name,
                        price: product.price,
                        image: product.image,
                        size: product.sizes[0],
                        color: getColorName(product.colors[0]),
                      })
                    }
                    className="w-full mt-2 px-4 py-2 border border-black text-sm font-medium hover:bg-black hover:text-white transition-colors"
                  >
                    QUICK ADD
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <p className="text-black/60">New arrivals coming soon. Check back later!</p>
          </div>
        )}
      </div>

      {/* CTA */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-16">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">EXPLORE MORE</h2>
          <p className="text-black/60 mb-8">
            Browse our full collection of casual wear and professional uniforms.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/casual"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-black text-white font-medium tracking-wider hover:bg-black/90 transition-colors"
            >
              SHOP CASUAL
              <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              to="/uniforms"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 border border-black font-medium tracking-wider hover:bg-black hover:text-white transition-colors"
            >
              SHOP UNIFORMS
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { Plus, MapPin, Trash2, Edit2, Check } from 'lucide-react';
import { useAuthStore } from '@/store/authStore';
import { addAddress, updateAddress, deleteAddress } from '@/lib/supabase';
import { toast } from 'sonner';
import type { UserAddress } from '@/types';

export const Addresses = () => {
  const { user, addresses, addAddress: addToStore, updateAddress: updateInStore, removeAddress } = useAuthStore();
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const emptyAddress: Omit<UserAddress, 'id' | 'user_id' | 'created_at'> = {
    type: 'shipping',
    first_name: '',
    last_name: '',
    address_line1: '',
    address_line2: '',
    city: '',
    state: '',
    postal_code: '',
    country: 'Egypt',
    phone: '',
    is_default: false,
  };

  const [formData, setFormData] = useState(emptyAddress);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setIsLoading(true);
    try {
      if (editingId) {
        const { data, error } = await updateAddress(editingId, formData);
        if (error) {
          toast.error('Failed to update address');
          return;
        }
        if (data) {
          updateInStore(editingId, data);
          toast.success('Address updated successfully');
        }
      } else {
        const { data, error } = await addAddress({
          ...formData,
          user_id: user.id,
        });
        if (error) {
          toast.error('Failed to add address');
          return;
        }
        if (data) {
          addToStore(data);
          toast.success('Address added successfully');
        }
      }
      resetForm();
    } catch {
      toast.error('An error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this address?')) return;

    try {
      const { error } = await deleteAddress(id);
      if (error) {
        toast.error('Failed to delete address');
        return;
      }
      removeAddress(id);
      toast.success('Address deleted successfully');
    } catch {
      toast.error('An error occurred');
    }
  };

  const handleSetDefault = async (id: string) => {
    try {
      const { data, error } = await updateAddress(id, { is_default: true });
      if (error) {
        toast.error('Failed to set default address');
        return;
      }
      if (data) {
        // Update all addresses in store
        addresses.forEach(addr => {
          if (addr.id === id) {
            updateInStore(id, { ...addr, is_default: true });
          } else if (addr.is_default) {
            updateInStore(addr.id, { ...addr, is_default: false });
          }
        });
        toast.success('Default address updated');
      }
    } catch {
      toast.error('An error occurred');
    }
  };

  const resetForm = () => {
    setFormData(emptyAddress);
    setIsAdding(false);
    setEditingId(null);
  };

  const startEdit = (address: UserAddress) => {
    setFormData({
      type: address.type,
      first_name: address.first_name,
      last_name: address.last_name,
      address_line1: address.address_line1,
      address_line2: address.address_line2 || '',
      city: address.city,
      state: address.state || '',
      postal_code: address.postal_code || '',
      country: address.country,
      phone: address.phone,
      is_default: address.is_default,
    });
    setEditingId(address.id);
    setIsAdding(true);
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold">My Addresses</h2>
        {!isAdding && (
          <button
            onClick={() => setIsAdding(true)}
            className="flex items-center gap-2 px-4 py-2 bg-black text-white text-sm hover:bg-gray-800 transition-colors"
          >
            <Plus size={16} />
            Add Address
          </button>
        )}
      </div>

      {isAdding ? (
        <form onSubmit={handleSubmit} className="border p-6 mb-6">
          <h3 className="font-medium mb-4">
            {editingId ? 'Edit Address' : 'Add New Address'}
          </h3>

          <div className="grid md:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-sm font-medium mb-1">First Name *</label>
              <input
                type="text"
                value={formData.first_name}
                onChange={(e) => setFormData({ ...formData, first_name: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 focus:border-black focus:outline-none"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Last Name *</label>
              <input
                type="text"
                value={formData.last_name}
                onChange={(e) => setFormData({ ...formData, last_name: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 focus:border-black focus:outline-none"
                required
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium mb-1">Address Line 1 *</label>
              <input
                type="text"
                value={formData.address_line1}
                onChange={(e) => setFormData({ ...formData, address_line1: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 focus:border-black focus:outline-none"
                required
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium mb-1">Address Line 2</label>
              <input
                type="text"
                value={formData.address_line2}
                onChange={(e) => setFormData({ ...formData, address_line2: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 focus:border-black focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">City *</label>
              <input
                type="text"
                value={formData.city}
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 focus:border-black focus:outline-none"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">State</label>
              <input
                type="text"
                value={formData.state}
                onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 focus:border-black focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Postal Code</label>
              <input
                type="text"
                value={formData.postal_code}
                onChange={(e) => setFormData({ ...formData, postal_code: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 focus:border-black focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Phone *</label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 focus:border-black focus:outline-none"
                required
              />
            </div>
          </div>

          <div className="flex items-center gap-2 mb-6">
            <input
              type="checkbox"
              id="default"
              checked={formData.is_default}
              onChange={(e) => setFormData({ ...formData, is_default: e.target.checked })}
              className="w-4 h-4"
            />
            <label htmlFor="default" className="text-sm">Set as default address</label>
          </div>

          <div className="flex gap-3">
            <button
              type="button"
              onClick={resetForm}
              className="flex-1 py-3 border border-gray-300 font-medium hover:bg-gray-50 transition-colors"
            >
              CANCEL
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="flex-1 bg-black text-white py-3 font-medium hover:bg-gray-800 transition-colors disabled:opacity-50"
            >
              {isLoading ? 'SAVING...' : editingId ? 'UPDATE ADDRESS' : 'SAVE ADDRESS'}
            </button>
          </div>
        </form>
      ) : null}

      {/* Address List */}
      <div className="grid md:grid-cols-2 gap-4">
        {addresses.map((address) => (
          <div
            key={address.id}
            className={`border p-4 ${address.is_default ? 'border-black' : ''}`}
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                <MapPin size={18} className="text-gray-400" />
                {address.is_default && (
                  <span className="text-xs bg-black text-white px-2 py-1">DEFAULT</span>
                )}
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => startEdit(address)}
                  className="p-2 text-gray-400 hover:text-black transition-colors"
                >
                  <Edit2 size={16} />
                </button>
                <button
                  onClick={() => handleDelete(address.id)}
                  className="p-2 text-gray-400 hover:text-red-500 transition-colors"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>

            <p className="font-medium">
              {address.first_name} {address.last_name}
            </p>
            <p className="text-sm text-gray-600">
              {address.address_line1}
            </p>
            {address.address_line2 && (
              <p className="text-sm text-gray-600">{address.address_line2}</p>
            )}
            <p className="text-sm text-gray-600">
              {address.city}, {address.state} {address.postal_code}
            </p>
            <p className="text-sm text-gray-600">{address.country}</p>
            <p className="text-sm text-gray-600 mt-2">{address.phone}</p>

            {!address.is_default && (
              <button
                onClick={() => handleSetDefault(address.id)}
                className="mt-4 text-sm text-gray-500 hover:text-black flex items-center gap-1"
              >
                <Check size={14} />
                Set as default
              </button>
            )}
          </div>
        ))}
      </div>

      {addresses.length === 0 && !isAdding && (
        <div className="text-center py-12 border border-dashed">
          <MapPin className="mx-auto mb-4 text-gray-300" size={48} />
          <p className="text-gray-500">No addresses saved yet</p>
        </div>
      )}
    </div>
  );
};

export default Addresses;

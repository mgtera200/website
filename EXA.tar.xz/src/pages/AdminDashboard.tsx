import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Package, Users, DollarSign, ShoppingBag, TrendingUp, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { Navigation } from '@/components/Navigation';
import { Footer } from '@/sections/Footer';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { getDashboardStats, getAllOrders, updateOrderStatus } from '@/lib/supabase';
import { sendOrderStatusUpdateEmail } from '@/lib/email';
import { useAuthStore } from '@/store/authStore';
import { toast } from 'sonner';
import type { Order } from '@/types';

const statusColors: Record<string, string> = {
  pending: 'bg-yellow-100 text-yellow-800',
  confirmed: 'bg-blue-100 text-blue-800',
  processing: 'bg-purple-100 text-purple-800',
  shipped: 'bg-indigo-100 text-indigo-800',
  delivered: 'bg-green-100 text-green-800',
  cancelled: 'bg-red-100 text-red-800',
  refunded: 'bg-gray-100 text-gray-800',
};

export const AdminDashboard = () => {
  const { user } = useAuthStore();
  const [stats, setStats] = useState({
    totalOrders: 0,
    totalRevenue: 0,
    totalCustomers: 0,
    totalProducts: 0,
    recentOrders: [] as Order[],
  });
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedStatus, setSelectedStatus] = useState<string>('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const dashboardStats = await getDashboardStats();
        setStats(dashboardStats);

        const { data: allOrders } = await getAllOrders({ limit: 50 });
        if (allOrders) {
          setOrders(allOrders);
        }
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
        toast.error('Failed to load dashboard data');
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleStatusUpdate = async (orderId: string, newStatus: string) => {
    try {
      const { data, error } = await updateOrderStatus(orderId, { status: newStatus as Order['status'] });
      
      if (error) {
        toast.error('Failed to update order status');
        return;
      }

      if (data) {
        // Update local state
        setOrders(orders.map(o => o.id === orderId ? { ...o, status: newStatus as Order['status'] } : o));
        
        // Send email notification
        if (user) {
          await sendOrderStatusUpdateEmail(user, data);
        }
        
        toast.success('Order status updated');
      }
    } catch {
      toast.error('An error occurred');
    }
  };

  const filteredOrders = selectedStatus
    ? orders.filter(o => o.status === selectedStatus)
    : orders;

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-black" />
      </div>
    );
  }

  return (
    <ProtectedRoute requireAdmin>
      <div className="min-h-screen">
        <Navigation />
        
        <main className="pt-[104px]">
          <div className="container mx-auto px-4 py-8">
            <div className="flex items-center justify-between mb-8">
              <h1 className="text-2xl lg:text-3xl font-bold tracking-wider">ADMIN DASHBOARD</h1>
              <div className="text-sm text-gray-500">
                Welcome, {user?.first_name}
              </div>
            </div>

            {/* Stats Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <div className="bg-white border p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-black text-white rounded-full flex items-center justify-center">
                    <ShoppingBag size={24} />
                  </div>
                  <span className="flex items-center text-green-600 text-sm">
                    <ArrowUpRight size={16} />
                    +12%
                  </span>
                </div>
                <p className="text-gray-500 text-sm">Total Orders</p>
                <p className="text-2xl font-bold">{stats.totalOrders}</p>
              </div>

              <div className="bg-white border p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-black text-white rounded-full flex items-center justify-center">
                    <DollarSign size={24} />
                  </div>
                  <span className="flex items-center text-green-600 text-sm">
                    <ArrowUpRight size={16} />
                    +8%
                  </span>
                </div>
                <p className="text-gray-500 text-sm">Total Revenue</p>
                <p className="text-2xl font-bold">{stats.totalRevenue.toLocaleString()} EGP</p>
              </div>

              <div className="bg-white border p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-black text-white rounded-full flex items-center justify-center">
                    <Users size={24} />
                  </div>
                  <span className="flex items-center text-green-600 text-sm">
                    <ArrowUpRight size={16} />
                    +15%
                  </span>
                </div>
                <p className="text-gray-500 text-sm">Total Customers</p>
                <p className="text-2xl font-bold">{stats.totalCustomers}</p>
              </div>

              <div className="bg-white border p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-black text-white rounded-full flex items-center justify-center">
                    <Package size={24} />
                  </div>
                  <span className="flex items-center text-red-600 text-sm">
                    <ArrowDownRight size={16} />
                    -3%
                  </span>
                </div>
                <p className="text-gray-500 text-sm">Total Products</p>
                <p className="text-2xl font-bold">{stats.totalProducts}</p>
              </div>
            </div>

            {/* Recent Orders */}
            <div className="bg-white border mb-8">
              <div className="p-6 border-b">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-bold flex items-center gap-2">
                    <TrendingUp size={20} />
                    Recent Orders
                  </h2>
                  <select
                    value={selectedStatus}
                    onChange={(e) => setSelectedStatus(e.target.value)}
                    className="px-4 py-2 border border-gray-300 text-sm"
                  >
                    <option value="">All Statuses</option>
                    <option value="pending">Pending</option>
                    <option value="confirmed">Confirmed</option>
                    <option value="processing">Processing</option>
                    <option value="shipped">Shipped</option>
                    <option value="delivered">Delivered</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Order</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Customer</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {filteredOrders.slice(0, 10).map((order) => (
                      <tr key={order.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4">
                          <Link to={`/order/${order.id}`} className="font-medium hover:text-gray-600">
                            {order.order_number}
                          </Link>
                        </td>
                        <td className="px-6 py-4 text-sm">
                          {(order as unknown as { user: { first_name: string; last_name: string } }).user?.first_name || 'Guest'}
                        </td>
                        <td className="px-6 py-4 text-sm">
                          {new Date(order.created_at).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4 font-medium">
                          {order.total} EGP
                        </td>
                        <td className="px-6 py-4">
                          <span className={`px-2 py-1 text-xs font-medium ${statusColors[order.status]}`}>
                            {order.status.toUpperCase()}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <select
                            value={order.status}
                            onChange={(e) => handleStatusUpdate(order.id, e.target.value)}
                            className="text-sm border border-gray-300 px-2 py-1"
                          >
                            <option value="pending">Pending</option>
                            <option value="confirmed">Confirmed</option>
                            <option value="processing">Processing</option>
                            <option value="shipped">Shipped</option>
                            <option value="delivered">Delivered</option>
                            <option value="cancelled">Cancelled</option>
                          </select>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="grid md:grid-cols-3 gap-6">
              <Link
                to="/admin/products"
                className="bg-black text-white p-6 hover:bg-gray-800 transition-colors"
              >
                <Package className="mb-4" size={32} />
                <h3 className="text-lg font-bold mb-2">Manage Products</h3>
                <p className="text-sm text-gray-300">Add, edit, or remove products</p>
              </Link>

              <Link
                to="/admin/orders"
                className="bg-black text-white p-6 hover:bg-gray-800 transition-colors"
              >
                <ShoppingBag className="mb-4" size={32} />
                <h3 className="text-lg font-bold mb-2">View All Orders</h3>
                <p className="text-sm text-gray-300">Manage and track all orders</p>
              </Link>

              <Link
                to="/admin/customers"
                className="bg-black text-white p-6 hover:bg-gray-800 transition-colors"
              >
                <Users className="mb-4" size={32} />
                <h3 className="text-lg font-bold mb-2">Manage Customers</h3>
                <p className="text-sm text-gray-300">View and manage customer accounts</p>
              </Link>
            </div>
          </div>
        </main>
        
        <Footer />
      </div>
    </ProtectedRoute>
  );
};

export default AdminDashboard;

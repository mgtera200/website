import { Link } from 'react-router-dom';
import { ArrowRight, Calendar, User } from 'lucide-react';
import { editorialArticles } from '@/data/products';

const articles = [
  ...editorialArticles,
  {
    id: '4',
    title: 'The Ultimate Guide to Workwear Essentials',
    subtitle: 'Building a professional wardrobe that lasts',
    image: '/images/category-workwear.jpg',
    href: '/editorial/workwear-guide',
    author: 'Sarah Mitchell',
    date: 'Feb 20, 2026',
    category: 'Style Guide',
  },
  {
    id: '5',
    title: 'How to Care for Your Medical Scrubs',
    subtitle: 'Tips for maintaining your healthcare uniforms',
    image: '/images/category-medical.jpg',
    href: '/editorial/scrubs-care',
    author: 'Dr. Emily Chen',
    date: 'Feb 15, 2026',
    category: 'Care Guide',
  },
  {
    id: '6',
    title: 'Corporate Fashion Trends 2026',
    subtitle: 'What to wear to the modern workplace',
    image: '/images/category-corporate.jpg',
    href: '/editorial/corporate-trends',
    author: 'James Wilson',
    date: 'Feb 10, 2026',
    category: 'Trends',
  },
];

const categories = ['All', 'Style Guide', 'Care Guide', 'Trends', 'Sustainability'];

export function Editorial() {
  return (
    <div className="min-h-screen bg-white pt-24 lg:pt-28">
      {/* Hero */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-12 lg:py-20">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-sm tracking-[0.3em] text-black/60 mb-4 uppercase">EXA Magazine</p>
          <h1 className="text-4xl lg:text-6xl font-bold mb-6">EDITORIAL</h1>
          <p className="text-lg text-black/60 max-w-2xl mx-auto">
            Style guides, care tips, and fashion inspiration for work, school, and life.
          </p>
        </div>
      </div>

      {/* Categories */}
      <div className="w-full px-4 sm:px-6 lg:px-12 pb-8 border-b border-black/10">
        <div className="flex flex-wrap justify-center gap-4">
          {categories.map((category) => (
            <button
              key={category}
              className="px-6 py-2 text-sm font-medium border border-black/20 hover:border-black hover:bg-black hover:text-white transition-colors"
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      {/* Featured Article */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-12">
        <Link to={articles[0].href} className="block group">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div className="aspect-[16/10] overflow-hidden">
              <img
                src={articles[0].image}
                alt={articles[0].title}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
            </div>
            <div className="lg:pl-8">
              <span className="text-sm text-black/60 tracking-wider">{articles[0].category}</span>
              <h2 className="text-3xl lg:text-4xl font-bold mt-3 mb-4 group-hover:opacity-70 transition-opacity">
                {articles[0].title}
              </h2>
              <p className="text-lg text-black/60 mb-6">{articles[0].subtitle}</p>
              <div className="flex items-center gap-4 text-sm text-black/60">
                <span className="flex items-center gap-2">
                  <User className="w-4 h-4" />
                  {articles[0].author}
                </span>
                <span className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  {articles[0].date}
                </span>
              </div>
              <div className="mt-6 flex items-center gap-2 text-sm font-medium">
                <span>Read Article</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </div>
            </div>
          </div>
        </Link>
      </div>

      {/* Article Grid */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-12 bg-neutral-50">
        <h2 className="text-2xl font-bold mb-8">LATEST ARTICLES</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {articles.slice(1).map((article) => (
            <Link key={article.id} to={article.href} className="group">
              <div className="aspect-[16/10] overflow-hidden mb-4">
                <img
                  src={article.image}
                  alt={article.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <span className="text-sm text-black/60 tracking-wider">{article.category}</span>
              <h3 className="text-xl font-bold mt-2 mb-2 group-hover:opacity-70 transition-opacity">
                {article.title}
              </h3>
              <p className="text-black/60 text-sm mb-4">{article.subtitle}</p>
              <div className="flex items-center gap-4 text-xs text-black/40">
                <span className="flex items-center gap-1">
                  <User className="w-3 h-3" />
                  {article.author}
                </span>
                <span className="flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  {article.date}
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Newsletter CTA */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-16">
        <div className="bg-black text-white p-8 lg:p-16 text-center">
          <h2 className="text-2xl lg:text-4xl font-bold mb-4">STAY INSPIRED</h2>
          <p className="text-white/70 max-w-2xl mx-auto mb-8">
            Subscribe to our newsletter for the latest style guides, fashion tips, and exclusive offers.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-1 px-4 py-4 bg-white/10 border border-white/20 text-white placeholder:text-white/40 focus:outline-none focus:border-white"
            />
            <button className="px-8 py-4 bg-white text-black font-medium tracking-wider hover:bg-white/90 transition-colors">
              SUBSCRIBE
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { Ruler, Info, ChevronDown } from 'lucide-react';

const sizeCategories = [
  { id: 'tops', name: 'Tops & Shirts' },
  { id: 'bottoms', name: 'Bottoms & Trousers' },
  { id: 'uniforms', name: 'Uniforms' },
];

const sizeCharts = {
  tops: {
    headers: ['Size', 'Chest (in)', 'Chest (cm)', 'Length (in)', 'Length (cm)'],
    rows: [
      ['XS', '34-36', '86-91', '26', '66'],
      ['S', '36-38', '91-97', '27', '69'],
      ['M', '38-40', '97-102', '28', '71'],
      ['L', '40-42', '102-107', '29', '74'],
      ['XL', '42-44', '107-112', '30', '76'],
      ['XXL', '44-46', '112-117', '31', '79'],
    ],
  },
  bottoms: {
    headers: ['Size', 'Waist (in)', 'Waist (cm)', 'Hip (in)', 'Hip (cm)', 'Inseam (in)'],
    rows: [
      ['28', '28', '71', '36', '91', '30'],
      ['30', '30', '76', '38', '97', '30'],
      ['32', '32', '81', '40', '102', '31'],
      ['34', '34', '86', '42', '107', '31'],
      ['36', '36', '91', '44', '112', '32'],
      ['38', '38', '97', '46', '117', '32'],
    ],
  },
  uniforms: {
    headers: ['Size', 'Chest (in)', 'Waist (in)', 'Height (ft)', 'Recommended'],
    rows: [
      ['XS', '32-34', '26-28', '5\'2"-5\'4"', 'Small Frame'],
      ['S', '34-36', '28-30', '5\'4"-5\'6"', 'Average Build'],
      ['M', '36-38', '30-32', '5\'6"-5\'9"', 'Average Build'],
      ['L', '38-40', '32-34', '5\'9"-6\'0"', 'Average Build'],
      ['XL', '40-42', '34-36', '6\'0"-6\'2"', 'Large Build'],
      ['XXL', '42-44', '36-38', '6\'2"+', 'Large Build'],
    ],
  },
};

const measurementTips = [
  {
    title: 'Chest',
    description: 'Measure around the fullest part of your chest, keeping the tape horizontal.',
  },
  {
    title: 'Waist',
    description: 'Measure around your natural waistline, keeping the tape comfortably loose.',
  },
  {
    title: 'Hip',
    description: 'Measure around the fullest part of your hips, about 8 inches below your waist.',
  },
  {
    title: 'Inseam',
    description: 'Measure from the crotch seam to the bottom of the leg.',
  },
];

export function SizeGuide() {
  const [activeCategory, setActiveCategory] = useState('tops');
  const [showTips, setShowTips] = useState(false);

  const chart = sizeCharts[activeCategory as keyof typeof sizeCharts];

  return (
    <div className="min-h-screen bg-white pt-24 lg:pt-28">
      <div className="w-full px-4 sm:px-6 lg:px-12 py-8 lg:py-16">
        {/* Header */}
        <div className="max-w-4xl mx-auto text-center mb-12">
          <Ruler className="w-12 h-12 mx-auto mb-4" />
          <h1 className="text-3xl lg:text-5xl font-bold mb-4">SIZE GUIDE</h1>
          <p className="text-black/60 max-w-2xl mx-auto">
            Find your perfect fit with our comprehensive size charts. Measure yourself 
            and compare with the charts below.
          </p>
        </div>

        {/* Category Tabs */}
        <div className="flex justify-center gap-4 mb-12">
          {sizeCategories.map((category) => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={`px-6 py-3 text-sm font-medium tracking-wider transition-colors ${
                activeCategory === category.id
                  ? 'bg-black text-white'
                  : 'border border-black/20 hover:border-black'
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>

        {/* Measurement Tips Toggle */}
        <div className="max-w-4xl mx-auto mb-8">
          <button
            onClick={() => setShowTips(!showTips)}
            className="flex items-center gap-2 text-sm font-medium hover:opacity-70 transition-opacity"
          >
            <Info className="w-4 h-4" />
            How to Measure
            <ChevronDown className={`w-4 h-4 transition-transform ${showTips ? 'rotate-180' : ''}`} />
          </button>

          {showTips && (
            <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4 p-6 bg-neutral-50">
              {measurementTips.map((tip) => (
                <div key={tip.title}>
                  <h4 className="font-semibold mb-1">{tip.title}</h4>
                  <p className="text-sm text-black/60">{tip.description}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Size Chart */}
        <div className="max-w-4xl mx-auto">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-black text-white">
                  {chart.headers.map((header) => (
                    <th key={header} className="px-4 py-4 text-left text-sm font-semibold">
                      {header}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {chart.rows.map((row, index) => (
                  <tr
                    key={index}
                    className={`border-b border-black/10 ${
                      index % 2 === 0 ? 'bg-white' : 'bg-neutral-50'
                    }`}
                  >
                    {row.map((cell, cellIndex) => (
                      <td key={cellIndex} className="px-4 py-4 text-sm">
                        {cell}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Notes */}
        <div className="max-w-4xl mx-auto mt-12 p-6 bg-neutral-50">
          <h3 className="font-semibold mb-4">IMPORTANT NOTES</h3>
          <ul className="space-y-2 text-sm text-black/60">
            <li>• All measurements are approximate and may vary slightly by style.</li>
            <li>• For the best fit, measure over undergarments similar to what you will wear.</li>
            <li>• If you are between sizes, we recommend sizing up for a more comfortable fit.</li>
            <li>• Uniform sizes may fit differently than casual wear. Please refer to the uniform-specific chart.</li>
            <li>• Contact our customer service if you need help determining your size.</li>
          </ul>
        </div>

        {/* Contact */}
        <div className="max-w-4xl mx-auto mt-12 text-center">
          <p className="text-black/60 mb-4">
            Still unsure about your size? Our team is here to help.
          </p>
          <a
            href="mailto:support@exa.com"
            className="inline-flex items-center gap-2 px-6 py-3 bg-black text-white font-medium tracking-wider hover:bg-black/90 transition-colors"
          >
            CONTACT US
          </a>
        </div>
      </div>
    </div>
  );
}

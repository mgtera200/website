import { useState, useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { Link } from 'react-router-dom';
import { Heart, ShoppingBag, ArrowRight, Building2, Stethoscope, UtensilsCrossed, HardHat } from 'lucide-react';
import { products } from '@/data/products';
import { useCart } from '@/hooks/useCart';
import type { Product } from '@/types';
import { getColorName } from '@/types';

const uniformCategories = [
  {
    id: 'corporate',
    name: 'CORPORATE',
    description: 'Professional attire for the modern workplace',
    image: '/images/category-corporate.jpg',
    icon: Building2,
  },
  {
    id: 'medical',
    name: 'MEDICAL',
    description: 'Scrubs, lab coats, and healthcare essentials',
    image: '/images/category-medical.jpg',
    icon: Stethoscope,
  },
  {
    id: 'hospitality',
    name: 'HOSPITALITY',
    description: 'Chef coats, aprons, and service wear',
    image: '/images/category-hospitality.jpg',
    icon: UtensilsCrossed,
  },
  {
    id: 'workwear',
    name: 'WORKWEAR',
    description: 'Industrial and construction uniforms',
    image: '/images/category-workwear.jpg',
    icon: HardHat,
  },
];

const uniformProducts = products.filter(
  (p) => p.category === 'corporate' || p.category === 'medical'
);

function ProductCard({ product }: { product: Product }) {
  const [isHovered, setIsHovered] = useState(false);
  const { addItem } = useCart();

  const handleQuickAdd = () => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      size: product.sizes[0],
      color: getColorName(product.colors[0]),
    });
  };

  return (
    <div
      className="group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <Link to={`/product/${product.id}`} className="block">
        <div className="relative aspect-[3/4] overflow-hidden bg-neutral-100 mb-4">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          
          <div
            className={`absolute inset-x-0 bottom-0 p-4 flex justify-center gap-3 transition-all duration-300 ${
              isHovered ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            <button
              onClick={(e) => {
                e.preventDefault();
                handleQuickAdd();
              }}
              className="p-3 bg-white hover:bg-black hover:text-white transition-colors"
              aria-label="Add to cart"
            >
              <ShoppingBag className="w-5 h-5" />
            </button>
            <button
              onClick={(e) => e.preventDefault()}
              className="p-3 bg-white hover:bg-black hover:text-white transition-colors"
              aria-label="Add to wishlist"
            >
              <Heart className="w-5 h-5" />
            </button>
          </div>
        </div>
      </Link>

      <div className="space-y-2">
        <Link to={`/product/${product.id}`}>
          <h3 className="text-sm font-medium tracking-wide group-hover:opacity-70 transition-opacity">
            {product.name}
          </h3>
        </Link>
        <span className="text-sm font-semibold">${product.price}</span>
      </div>
    </div>
  );
}

export function Uniforms() {
  const gridRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const grid = gridRef.current;
    if (!grid) return;

    const cards = grid.querySelectorAll('.product-card');
    gsap.fromTo(
      cards,
      { y: 40, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.6, stagger: 0.1, ease: 'power2.out', delay: 0.3 }
    );
  }, []);

  return (
    <div className="min-h-screen bg-white pt-24 lg:pt-28">
      {/* Hero Banner */}
      <div className="relative h-[400px] lg:h-[500px] overflow-hidden">
        <img
          src="/images/hero-uniforms.jpg"
          alt="Professional Uniforms"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/50" />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white">
            <p className="text-sm tracking-[0.3em] mb-4 uppercase">Professional</p>
            <h1 className="text-4xl lg:text-6xl font-bold tracking-tight">UNIFORMS</h1>
            <p className="mt-4 text-white/80 max-w-md mx-auto">
              Elevate your professional image with our premium uniform collections
            </p>
          </div>
        </div>
      </div>

      {/* Category Grid */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-16">
        <h2 className="text-2xl lg:text-3xl font-bold mb-8">UNIFORM CATEGORIES</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
          {uniformCategories.map((category) => (
            <Link
              key={category.id}
              to={`/${category.id}`}
              className="group relative aspect-[4/5] overflow-hidden bg-neutral-100"
            >
              <img
                src={category.image}
                alt={category.name}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
              
              <div className="absolute inset-x-0 bottom-0 p-6">
                <category.icon className="w-8 h-8 text-white mb-3" />
                <h3 className="text-white text-xl font-bold mb-2">{category.name}</h3>
                <p className="text-white/70 text-sm mb-4">{category.description}</p>
                <div className="flex items-center text-white text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <span>Explore</span>
                  <ArrowRight className="w-4 h-4 ml-2 transition-transform group-hover:translate-x-1" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Featured Uniforms */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-16 bg-neutral-50">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl lg:text-3xl font-bold">UNIFORM ESSENTIALS</h2>
          <Link
            to="/corporate"
            className="text-sm font-medium hover:opacity-70 transition-opacity"
          >
            View All
          </Link>
        </div>
        
        <div ref={gridRef} className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-8">
          {uniformProducts.map((product) => (
            <div key={product.id} className="product-card">
              <ProductCard product={product} />
            </div>
          ))}
        </div>
      </div>

      {/* Bulk Orders CTA */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-16">
        <div className="bg-black text-white p-8 lg:p-16 text-center">
          <h2 className="text-2xl lg:text-4xl font-bold mb-4">BULK ORDERS</h2>
          <p className="text-white/70 max-w-2xl mx-auto mb-8">
            Need uniforms for your entire team or organization? We offer competitive pricing,
            customization options, and dedicated support for bulk orders.
          </p>
          <Link
            to="/bulk"
            className="inline-flex items-center justify-center px-8 py-4 bg-white text-black text-sm font-medium tracking-wider hover:bg-white/90 transition-colors"
          >
            GET A QUOTE
          </Link>
        </div>
      </div>
    </div>
  );
}

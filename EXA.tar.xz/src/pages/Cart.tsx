import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Trash2, Minus, Plus, ShoppingBag, ArrowRight, Truck, Gift } from 'lucide-react';
import { useCart } from '@/hooks/useCart';

const shippingOptions = [
  { id: 'standard', name: 'Standard Shipping', price: 5, time: '5-7 business days' },
  { id: 'express', name: 'Express Shipping', price: 15, time: '2-3 business days' },
  { id: 'free', name: 'Free Shipping', price: 0, time: '7-10 business days', minOrder: 75 },
];

export function Cart() {
  const { items, total, updateQuantity, removeItem } = useCart();
  const navigate = useNavigate();
  const [promoCode, setPromoCode] = useState('');
  const [promoApplied, setPromoApplied] = useState(false);
  const [selectedShipping, setSelectedShipping] = useState('standard');

  const shipping = shippingOptions.find((s) => s.id === selectedShipping)?.price || 5;
  const discount = promoApplied ? total * 0.1 : 0;
  const finalTotal = total + shipping - discount;

  const handleApplyPromo = () => {
    if (promoCode.toLowerCase() === 'exa10') {
      setPromoApplied(true);
    }
  };

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-white pt-24 lg:pt-28">
        <div className="w-full px-4 sm:px-6 lg:px-12 py-16">
          <div className="max-w-2xl mx-auto text-center">
            <ShoppingBag className="w-16 h-16 mx-auto mb-6 text-black/30" />
            <h1 className="text-2xl lg:text-3xl font-bold mb-4">YOUR CART IS EMPTY</h1>
            <p className="text-black/60 mb-8">
              Looks like you haven't added anything to your cart yet.
            </p>
            <Link
              to="/casual"
              className="inline-flex items-center justify-center px-8 py-4 bg-black text-white font-medium tracking-wider hover:bg-black/90 transition-colors"
            >
              START SHOPPING
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white pt-24 lg:pt-28">
      <div className="w-full px-4 sm:px-6 lg:px-12 py-8 lg:py-16">
        <h1 className="text-2xl lg:text-4xl font-bold mb-8">SHOPPING CART</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-12">
          {/* Cart Items */}
          <div className="lg:col-span-2">
            <div className="border-b border-black/10 pb-4 mb-4 hidden lg:grid lg:grid-cols-12 gap-4 text-sm font-semibold text-black/60">
              <div className="col-span-6">PRODUCT</div>
              <div className="col-span-2 text-center">QUANTITY</div>
              <div className="col-span-2 text-right">PRICE</div>
              <div className="col-span-2 text-right">TOTAL</div>
            </div>

            <div className="space-y-6">
              {items.map((item) => (
                <div
                  key={`${item.id}-${item.size}-${item.color}`}
                  className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-center py-6 border-b border-black/10"
                >
                  {/* Product Info */}
                  <div className="lg:col-span-6 flex gap-4">
                    <Link to={`/product/${item.id}`} className="w-24 h-32 bg-neutral-100 flex-shrink-0">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    </Link>
                    <div className="flex flex-col justify-center">
                      <Link to={`/product/${item.id}`}>
                        <h3 className="font-medium hover:opacity-70 transition-opacity">
                          {item.name}
                        </h3>
                      </Link>
                      <p className="text-sm text-black/60 mt-1">
                        Size: {item.size} / Color: {item.color}
                      </p>
                      <p className="text-sm font-semibold mt-2 lg:hidden">
                        ${item.price * item.quantity}
                      </p>
                    </div>
                  </div>

                  {/* Quantity */}
                  <div className="lg:col-span-2 flex items-center justify-between lg:justify-center">
                    <span className="lg:hidden text-sm text-black/60">Quantity:</span>
                    <div className="flex items-center border border-black/20">
                      <button
                        onClick={() =>
                          updateQuantity(item.id, item.size, item.color, item.quantity - 1)
                        }
                        className="p-2 hover:bg-black/5 transition-colors"
                        aria-label="Decrease quantity"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className="w-10 text-center text-sm font-medium">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() =>
                          updateQuantity(item.id, item.size, item.color, item.quantity + 1)
                        }
                        className="p-2 hover:bg-black/5 transition-colors"
                        aria-label="Increase quantity"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Price */}
                  <div className="lg:col-span-2 text-right hidden lg:block">
                    <span className="text-sm">${item.price}</span>
                  </div>

                  {/* Total */}
                  <div className="lg:col-span-2 flex items-center justify-between lg:justify-end">
                    <span className="lg:hidden text-sm text-black/60">Total:</span>
                    <div className="flex items-center gap-4">
                      <span className="font-semibold">
                        ${item.price * item.quantity}
                      </span>
                      <button
                        onClick={() => removeItem(item.id, item.size, item.color)}
                        className="p-2 text-black/40 hover:text-black transition-colors"
                        aria-label="Remove item"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Continue Shopping */}
            <Link
              to="/casual"
              className="inline-flex items-center gap-2 text-sm font-medium mt-8 hover:opacity-70 transition-opacity"
            >
              <ArrowRight className="w-4 h-4 rotate-180" />
              CONTINUE SHOPPING
            </Link>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-neutral-50 p-6 lg:p-8">
              <h2 className="text-lg font-bold mb-6">ORDER SUMMARY</h2>

              {/* Promo Code */}
              <div className="mb-6">
                <label className="text-sm font-medium mb-2 block">PROMO CODE</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value)}
                    placeholder="Enter code"
                    className="flex-1 px-4 py-3 border border-black/20 text-sm focus:outline-none focus:border-black"
                  />
                  <button
                    onClick={handleApplyPromo}
                    className="px-4 py-3 bg-black text-white text-sm font-medium hover:bg-black/90 transition-colors"
                  >
                    APPLY
                  </button>
                </div>
                {promoApplied && (
                  <p className="text-sm text-green-600 mt-2">
                    10% discount applied!
                  </p>
                )}
                <p className="text-xs text-black/50 mt-2">
                  Try code: EXA10
                </p>
              </div>

              {/* Shipping Options */}
              <div className="mb-6">
                <label className="text-sm font-medium mb-3 block">SHIPPING</label>
                <div className="space-y-2">
                  {shippingOptions.map((option) => (
                    <label
                      key={option.id}
                      className={`flex items-center justify-between p-3 border cursor-pointer transition-colors ${
                        selectedShipping === option.id
                          ? 'border-black bg-white'
                          : 'border-black/20 hover:border-black/40'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <input
                          type="radio"
                          name="shipping"
                          value={option.id}
                          checked={selectedShipping === option.id}
                          onChange={() => setSelectedShipping(option.id)}
                          className="w-4 h-4 accent-black"
                        />
                        <div>
                          <p className="text-sm font-medium">{option.name}</p>
                          <p className="text-xs text-black/60">{option.time}</p>
                        </div>
                      </div>
                      <span className="text-sm font-semibold">
                        {option.price === 0 ? 'FREE' : `$${option.price}`}
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Totals */}
              <div className="space-y-3 pt-6 border-t border-black/10">
                <div className="flex justify-between text-sm">
                  <span className="text-black/60">Subtotal</span>
                  <span>${total.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-black/60">Shipping</span>
                  <span>{shipping === 0 ? 'FREE' : `$${shipping.toFixed(2)}`}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-sm text-green-600">
                    <span>Discount</span>
                    <span>-${discount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-lg font-bold pt-3 border-t border-black/10">
                  <span>TOTAL</span>
                  <span>${finalTotal.toFixed(2)}</span>
                </div>
              </div>

              {/* Checkout Button */}
              <button
                onClick={() => navigate('/checkout')}
                className="w-full mt-6 flex items-center justify-center gap-2 px-6 py-4 bg-black text-white font-medium tracking-wider hover:bg-black/90 transition-colors"
              >
                PROCEED TO CHECKOUT
                <ArrowRight className="w-4 h-4" />
              </button>

              {/* Trust Badges */}
              <div className="grid grid-cols-2 gap-4 mt-6 pt-6 border-t border-black/10">
                <div className="flex items-center gap-2 text-xs text-black/60">
                  <Truck className="w-4 h-4" />
                  <span>Free shipping over $75</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-black/60">
                  <Gift className="w-4 h-4" />
                  <span>Gift wrapping available</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

import { Link } from 'react-router-dom';
import { Navigation } from '@/components/Navigation';
import { Footer } from '@/sections/Footer';

export const NotFound = () => {
  return (
    <div className="min-h-screen">
      <Navigation />
      
      <main className="pt-[104px]">
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-6xl lg:text-8xl font-bold mb-4">404</h1>
          <h2 className="text-2xl lg:text-3xl font-bold mb-4">Page Not Found</h2>
          <p className="text-gray-600 max-w-md mx-auto mb-8">
            The page you are looking for does not exist or has been moved.
          </p>
          <Link
            to="/"
            className="inline-block px-8 py-3 bg-black text-white font-medium tracking-wider hover:bg-gray-800 transition-colors"
          >
            GO HOME
          </Link>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default NotFound;

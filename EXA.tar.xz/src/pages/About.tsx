import { Link } from 'react-router-dom';
import { Check, Target, Users, Globe, Award, Heart } from 'lucide-react';

const values = [
  {
    icon: Target,
    title: 'Quality First',
    description: 'We source only the finest materials and work with skilled manufacturers to ensure every piece meets our high standards.',
  },
  {
    icon: Users,
    title: 'Customer Focused',
    description: 'Your satisfaction is our priority. We listen to feedback and continuously improve our products and services.',
  },
  {
    icon: Globe,
    title: 'Sustainable Practices',
    description: 'We are committed to reducing our environmental impact through responsible sourcing and ethical manufacturing.',
  },
  {
    icon: Award,
    title: 'Innovation',
    description: 'We constantly explore new technologies and designs to bring you the best in fashion and functionality.',
  },
];

const milestones = [
  { year: '2020', event: 'EXA founded with a vision to revolutionize uniforms' },
  { year: '2021', event: 'Launched first corporate collection' },
  { year: '2022', event: 'Expanded to medical and hospitality sectors' },
  { year: '2023', event: 'Introduced sustainable fabric line' },
  { year: '2024', event: 'Reached 100,000+ customers worldwide' },
  { year: '2025', event: 'Launched school uniform program' },
];

export function About() {
  return (
    <div className="min-h-screen bg-white pt-24 lg:pt-28">
      {/* Hero */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-12 lg:py-20">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-sm tracking-[0.3em] text-black/60 mb-4 uppercase">Our Story</p>
          <h1 className="text-4xl lg:text-6xl font-bold mb-6">ABOUT EXA</h1>
          <p className="text-lg text-black/60 max-w-2xl mx-auto leading-relaxed">
            EXA was founded with a simple mission: to provide high-quality, stylish clothing 
            that works as hard as you do. From the office to the classroom, we've got you covered.
          </p>
        </div>
      </div>

      {/* Mission */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-16 bg-neutral-50">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <img
              src="/images/hero-uniforms.jpg"
              alt="EXA Mission"
              className="w-full aspect-[4/3] object-cover"
            />
          </div>
          <div>
            <h2 className="text-3xl lg:text-4xl font-bold mb-6">OUR MISSION</h2>
            <p className="text-black/70 leading-relaxed mb-6">
              At EXA, we believe that what you wear should empower you. Whether you're leading 
              a meeting, caring for patients, or studying for exams, your clothing should support 
              your success, not hinder it.
            </p>
            <p className="text-black/70 leading-relaxed mb-8">
              We combine contemporary design with practical functionality to create uniforms 
              and casual wear that people actually want to wear. No more compromises between 
              style and comfort.
            </p>
            <div className="space-y-3">
              {[
                'Premium quality materials',
                'Modern, versatile designs',
                'Affordable pricing',
                'Exceptional customer service',
              ].map((item) => (
                <div key={item} className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-black" />
                  <span className="text-sm">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Values */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">OUR VALUES</h2>
          <p className="text-black/60 max-w-2xl mx-auto">
            These principles guide everything we do, from design to delivery.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {values.map((value) => (
            <div key={value.title} className="text-center p-6">
              <div className="w-16 h-16 bg-black text-white rounded-full flex items-center justify-center mx-auto mb-6">
                <value.icon className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold mb-3">{value.title}</h3>
              <p className="text-black/60 text-sm leading-relaxed">{value.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Timeline */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-16 bg-neutral-50">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">OUR JOURNEY</h2>
          <p className="text-black/60 max-w-2xl mx-auto">
            From a small startup to a global brand, here's how we've grown.
          </p>
        </div>
        <div className="max-w-4xl mx-auto">
          <div className="relative">
            <div className="absolute left-4 lg:left-1/2 top-0 bottom-0 w-px bg-black/20" />
            {milestones.map((milestone, index) => (
              <div
                key={milestone.year}
                className={`relative flex items-center gap-8 mb-8 ${
                  index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'
                }`}
              >
                <div className="hidden lg:block lg:w-1/2 lg:text-right">
                  {index % 2 === 0 && (
                    <>
                      <p className="text-3xl font-bold">{milestone.year}</p>
                      <p className="text-black/60">{milestone.event}</p>
                    </>
                  )}
                </div>
                <div className="w-8 h-8 bg-black rounded-full flex items-center justify-center relative z-10 flex-shrink-0">
                  <div className="w-3 h-3 bg-white rounded-full" />
                </div>
                <div className="lg:w-1/2">
                  <p className="lg:hidden text-2xl font-bold">{milestone.year}</p>
                  <p className="lg:hidden text-black/60 mb-2">{milestone.event}</p>
                  {index % 2 !== 0 && (
                    <>
                      <p className="hidden lg:block text-3xl font-bold">{milestone.year}</p>
                      <p className="hidden lg:block text-black/60">{milestone.event}</p>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-16">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            { value: '100K+', label: 'Happy Customers' },
            { value: '500+', label: 'Products' },
            { value: '50+', label: 'Countries Served' },
            { value: '99%', label: 'Satisfaction Rate' },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <p className="text-4xl lg:text-5xl font-bold mb-2">{stat.value}</p>
              <p className="text-black/60">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* CTA */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-16">
        <div className="bg-black text-white p-8 lg:p-16 text-center">
          <Heart className="w-12 h-12 mx-auto mb-6" />
          <h2 className="text-2xl lg:text-4xl font-bold mb-4">JOIN THE EXA FAMILY</h2>
          <p className="text-white/70 max-w-2xl mx-auto mb-8">
            Experience the difference quality makes. Shop our collections today.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/casual"
              className="px-8 py-4 bg-white text-black font-medium tracking-wider hover:bg-white/90 transition-colors"
            >
              SHOP CASUAL
            </Link>
            <Link
              to="/uniforms"
              className="px-8 py-4 border border-white font-medium tracking-wider hover:bg-white hover:text-black transition-colors"
            >
              SHOP UNIFORMS
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

import { Link } from 'react-router-dom';
import { Truck, Package, Clock, Globe, MapPin, Phone } from 'lucide-react';

const shippingMethods = [
  {
    name: 'Standard Shipping',
    price: 5,
    time: '5-7 business days',
    description: 'Economical option for non-urgent orders',
    freeThreshold: null,
  },
  {
    name: 'Express Shipping',
    price: 15,
    time: '2-3 business days',
    description: 'Fast delivery for urgent orders',
    freeThreshold: null,
  },
  {
    name: 'Free Shipping',
    price: 0,
    time: '7-10 business days',
    description: 'Available on orders over $75',
    freeThreshold: 75,
  },
];

const deliveryInfo = [
  {
    icon: MapPin,
    title: 'Domestic Shipping',
    description: 'We ship to all 50 US states. Delivery times may vary based on location.',
  },
  {
    icon: Globe,
    title: 'International Shipping',
    description: 'We ship to over 50 countries worldwide. International orders may be subject to customs fees.',
  },
  {
    icon: Clock,
    title: 'Processing Time',
    description: 'Orders are processed within 1-2 business days. Custom orders may take longer.',
  },
  {
    icon: Package,
    title: 'Tracking',
    description: 'You will receive a tracking number via email once your order ships.',
  },
];

const faqs = [
  {
    question: 'When will my order ship?',
    answer: 'Orders are typically processed within 1-2 business days. You will receive an email confirmation with tracking information once your order ships.',
  },
  {
    question: 'Do you ship internationally?',
    answer: 'Yes, we ship to over 50 countries worldwide. International shipping rates and delivery times vary by location.',
  },
  {
    question: 'How do I track my order?',
    answer: 'Once your order ships, you will receive an email with a tracking number. You can use this number on our website or the carrier\'s website to track your package.',
  },
  {
    question: 'What if my package is lost or damaged?',
    answer: 'Please contact our customer service team within 7 days of the expected delivery date. We will work with the carrier to resolve the issue.',
  },
  {
    question: 'Can I change my shipping address after ordering?',
    answer: 'Address changes may be possible if the order has not yet shipped. Please contact us as soon as possible to request a change.',
  },
];

export function Shipping() {
  return (
    <div className="min-h-screen bg-white pt-24 lg:pt-28">
      <div className="w-full px-4 sm:px-6 lg:px-12 py-8 lg:py-16">
        {/* Header */}
        <div className="max-w-4xl mx-auto text-center mb-12">
          <Truck className="w-12 h-12 mx-auto mb-4" />
          <h1 className="text-3xl lg:text-5xl font-bold mb-4">SHIPPING INFORMATION</h1>
          <p className="text-black/60 max-w-2xl mx-auto">
            Everything you need to know about shipping, delivery times, and tracking your order.
          </p>
        </div>

        {/* Shipping Methods */}
        <div className="max-w-4xl mx-auto mb-16">
          <h2 className="text-2xl font-bold mb-8">SHIPPING METHODS</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {shippingMethods.map((method) => (
              <div
                key={method.name}
                className="p-6 border border-black/10 hover:border-black transition-colors"
              >
                <h3 className="font-bold mb-2">{method.name}</h3>
                <p className="text-2xl font-bold mb-2">
                  {method.price === 0 ? 'FREE' : `$${method.price}`}
                </p>
                <p className="text-sm text-black/60 mb-2">{method.time}</p>
                <p className="text-sm text-black/40">{method.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Delivery Info */}
        <div className="max-w-4xl mx-auto mb-16">
          <h2 className="text-2xl font-bold mb-8">DELIVERY INFORMATION</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {deliveryInfo.map((info) => (
              <div key={info.title} className="flex gap-4 p-6 bg-neutral-50">
                <div className="w-12 h-12 bg-black text-white rounded-full flex items-center justify-center flex-shrink-0">
                  <info.icon className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-semibold mb-2">{info.title}</h3>
                  <p className="text-sm text-black/60">{info.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Shipping Rates Table */}
        <div className="max-w-4xl mx-auto mb-16">
          <h2 className="text-2xl font-bold mb-8">INTERNATIONAL SHIPPING RATES</h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-black text-white">
                  <th className="px-4 py-4 text-left text-sm font-semibold">Region</th>
                  <th className="px-4 py-4 text-left text-sm font-semibold">Standard</th>
                  <th className="px-4 py-4 text-left text-sm font-semibold">Express</th>
                  <th className="px-4 py-4 text-left text-sm font-semibold">Delivery Time</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ['Canada', '$15', '$25', '5-10 days'],
                  ['UK & Europe', '$20', '$35', '7-14 days'],
                  ['Australia', '$25', '$40', '10-16 days'],
                  ['Middle East', '$20', '$35', '7-12 days'],
                  ['Asia', '$25', '$45', '10-18 days'],
                  ['Rest of World', '$30', '$50', '14-21 days'],
                ].map((row, index) => (
                  <tr
                    key={index}
                    className={`border-b border-black/10 ${
                      index % 2 === 0 ? 'bg-white' : 'bg-neutral-50'
                    }`}
                  >
                    {row.map((cell, cellIndex) => (
                      <td key={cellIndex} className="px-4 py-4 text-sm">
                        {cell}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* FAQs */}
        <div className="max-w-4xl mx-auto mb-16">
          <h2 className="text-2xl font-bold mb-8">FREQUENTLY ASKED QUESTIONS</h2>
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div key={index} className="p-6 bg-neutral-50">
                <h3 className="font-semibold mb-2">{faq.question}</h3>
                <p className="text-sm text-black/60">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Contact */}
        <div className="max-w-4xl mx-auto">
          <div className="bg-black text-white p-8 lg:p-12">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div>
                <h2 className="text-2xl font-bold mb-4">NEED HELP?</h2>
                <p className="text-white/70 mb-6">
                  Our customer service team is available to assist you with any shipping questions.
                </p>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <Phone className="w-5 h-5" />
                    <span>+1 (800) 555-EXA</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Package className="w-5 h-5" />
                    <span>support@exa.com</span>
                  </div>
                </div>
              </div>
              <div className="text-center md:text-right">
                <Link
                  to="/contact"
                  className="inline-flex items-center justify-center px-8 py-4 bg-white text-black font-medium tracking-wider hover:bg-white/90 transition-colors"
                >
                  CONTACT US
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

import { Hero } from '@/sections/Hero';
import { CategoryGrid } from '@/sections/CategoryGrid';
import { DualFocus } from '@/sections/DualFocus';
import { FeaturedProducts } from '@/sections/FeaturedProducts';
import { EditorialContent } from '@/sections/EditorialContent';

export function Home() {
  return (
    <main className="min-h-screen bg-white">
      <Hero />
      <CategoryGrid />
      <DualFocus />
      <FeaturedProducts />
      <EditorialContent />
    </main>
  );
}

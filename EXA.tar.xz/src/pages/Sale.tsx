import { Link } from 'react-router-dom';
import { Percent } from 'lucide-react';
import { products } from '@/data/products';
import { useCart } from '@/hooks/useCart';
import { getColorName } from '@/types';

const saleProducts = products.filter((p) => p.isSale || p.originalPrice);

export function Sale() {
  const { addItem } = useCart();

  return (
    <div className="min-h-screen bg-white pt-24 lg:pt-28">
      {/* Hero */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-12 lg:py-20">
        <div className="max-w-4xl mx-auto text-center">
          <span className="inline-block px-4 py-2 bg-red-600 text-white text-sm font-medium tracking-wider mb-6">
            LIMITED TIME
          </span>
          <h1 className="text-4xl lg:text-6xl font-bold mb-6">SALE</h1>
          <p className="text-lg text-black/60 max-w-2xl mx-auto">
            Grab these deals before they're gone. Up to 50% off selected items.
          </p>
        </div>
      </div>

      {/* Products */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-12 bg-neutral-50">
        {saleProducts.length > 0 ? (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-8">
            {saleProducts.map((product) => (
              <div key={product.id} className="group bg-white">
                <Link to={`/product/${product.id}`} className="block">
                  <div className="relative aspect-[3/4] overflow-hidden bg-neutral-100 mb-4">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute top-3 left-3 px-3 py-1 bg-red-600 text-white text-xs font-medium tracking-wider flex items-center gap-1">
                      <Percent className="w-3 h-3" />
                      SALE
                    </div>
                    {product.originalPrice && (
                      <div className="absolute top-3 right-3 px-3 py-1 bg-black text-white text-xs font-medium">
                        -{Math.round((1 - product.price / product.originalPrice) * 100)}%
                      </div>
                    )}
                  </div>
                </Link>

                <div className="p-4 space-y-2">
                  <Link to={`/product/${product.id}`}>
                    <h3 className="text-sm font-medium tracking-wide group-hover:opacity-70 transition-opacity">
                      {product.name}
                    </h3>
                  </Link>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold">${product.price}</span>
                    {product.originalPrice && (
                      <span className="text-sm text-black/50 line-through">
                        ${product.originalPrice}
                      </span>
                    )}
                  </div>
                  <button
                    onClick={() =>
                      addItem({
                        id: product.id,
                        name: product.name,
                        price: product.price,
                        image: product.image,
                        size: product.sizes[0],
                        color: getColorName(product.colors[0]),
                      })
                    }
                    className="w-full mt-2 px-4 py-2 border border-black text-sm font-medium hover:bg-black hover:text-white transition-colors"
                  >
                    QUICK ADD
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <Percent className="w-16 h-16 mx-auto mb-6 text-black/30" />
            <h2 className="text-xl font-bold mb-4">NO ACTIVE SALES</h2>
            <p className="text-black/60 mb-8">
              Check back soon for our next sale event!
            </p>
            <Link
              to="/casual"
              className="inline-flex items-center justify-center px-8 py-4 bg-black text-white font-medium tracking-wider hover:bg-black/90 transition-colors"
            >
              SHOP NOW
            </Link>
          </div>
        )}
      </div>

      {/* Newsletter */}
      <div className="w-full px-4 sm:px-6 lg:px-12 py-16">
        <div className="bg-black text-white p-8 lg:p-16 text-center">
          <h2 className="text-2xl lg:text-4xl font-bold mb-4">NEVER MISS A SALE</h2>
          <p className="text-white/70 max-w-2xl mx-auto mb-8">
            Subscribe to our newsletter and be the first to know about exclusive deals and promotions.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-1 px-4 py-4 bg-white/10 border border-white/20 text-white placeholder:text-white/40 focus:outline-none focus:border-white"
            />
            <button className="px-8 py-4 bg-white text-black font-medium tracking-wider hover:bg-white/90 transition-colors">
              SUBSCRIBE
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useEffect } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Toaster } from 'sonner';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { AuthProvider } from '@/contexts/AuthContext';
import { Navigation } from '@/components/Navigation';
import { Footer } from '@/sections/Footer';
import { CartProvider } from '@/hooks/useCart';
import { SmoothScroll } from '@/components/SmoothScroll'; // Added

// V4 Pages
import { Home } from '@/pages/Home';
import { Casual } from '@/pages/Casual';
import { Uniforms } from '@/pages/Uniforms';
import { School } from '@/pages/School';
import { ProductDetail } from '@/pages/ProductDetail';
import { Cart } from '@/pages/Cart';
import { Checkout } from '@/pages/Checkout';
import { Account } from '@/pages/Account';
import { Editorial } from '@/pages/Editorial';
import { About } from '@/pages/About';
import { SizeGuide } from '@/pages/SizeGuide';
import { Shipping } from '@/pages/Shipping';
import { Wishlist } from '@/pages/Wishlist';
import { NewIn } from '@/pages/NewIn';
import { Sale } from '@/pages/Sale';

// V5 Auth Pages
import { Login } from '@/pages/Login';
import { Register } from '@/pages/Register';
import { AuthCallback } from '@/pages/AuthCallback';
import { Profile } from '@/pages/Profile';
import { Orders } from '@/pages/Orders';
import { OrderDetail } from '@/pages/OrderDetail';
import { Addresses } from '@/pages/Addresses';
import { Search } from '@/pages/Search';
import { AdminDashboard } from '@/pages/AdminDashboard';
import { NotFound } from '@/pages/NotFound';

import './App.css';

// Initialize React Query
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      retry: 1,
    },
  },
});

function App() {
  useEffect(() => {
    document.title = 'EXA - Fashion & Uniforms | Your Complete Wardrobe';
    const meta = document.querySelector('meta[name="description"]');
    if (meta) {
      meta.setAttribute(
        'content',
        'EXA - Your complete wardrobe for work, school, and life. Shop contemporary casual clothing and professional uniforms. Premium fashion for every occasion.'
      );
    }
    document.documentElement.lang = 'en';
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <CartProvider>
          <BrowserRouter>
            <SmoothScroll> {/* Wrapped content with smooth scroll */}
              <div className="min-h-screen bg-white">
                <Navigation />
                <main>
                  <Routes>
                    {/* Public Routes */}
                    <Route path="/" element={<Home />} />
                    
                    {/* Auth Routes */}
                    <Route path="/login" element={<Login />} />
                    <Route path="/register" element={<Register />} />
                    <Route path="/auth/callback" element={<AuthCallback />} />
                    
                    {/* Product Routes */}
                    <Route path="/casual" element={<Casual />} />
                    <Route path="/uniforms" element={<Uniforms />} />
                    <Route path="/uniforms/:subcategory" element={<Uniforms />} />
                    <Route path="/school" element={<School />} />
                    <Route path="/corporate" element={<Uniforms />} />
                    <Route path="/medical" element={<Uniforms />} />
                    <Route path="/hospitality" element={<Uniforms />} />
                    <Route path="/workwear" element={<Uniforms />} />
                    <Route path="/accessories" element={<Casual />} />
                    <Route path="/new-in" element={<NewIn />} />
                    <Route path="/sale" element={<Sale />} />
                    <Route path="/product/:id" element={<ProductDetail />} />
                    
                    {/* Cart & Checkout */}
                    <Route path="/cart" element={<Cart />} />
                    <Route path="/checkout" element={<Checkout />} />
                    
                    {/* Search */}
                    <Route path="/search" element={<Search />} />
                    
                    {/* Order Detail */}
                    <Route path="/order/:id" element={<OrderDetail />} />
                    
                    {/* Account Routes with Nested Pages */}
                    <Route path="/account" element={<Account />}>
                      <Route index element={<Profile />} />
                      <Route path="profile" element={<Profile />} />
                      <Route path="orders" element={<Orders />} />
                      <Route path="addresses" element={<Addresses />} />
                      <Route path="wishlist" element={<Wishlist />} />
                    </Route>
                    
                    {/* Admin Routes */}
                    <Route path="/admin" element={<AdminDashboard />} />
                    <Route path="/admin/dashboard" element={<AdminDashboard />} />
                    
                    {/* Static Pages */}
                    <Route path="/editorial" element={<Editorial />} />
                    <Route path="/about" element={<About />} />
                    <Route path="/size-guide" element={<SizeGuide />} />
                    <Route path="/shipping" element={<Shipping />} />
                    <Route path="/wishlist" element={<Wishlist />} />
                    
                    {/* Placeholder Pages */}
                    <Route path="/returns" element={<div className="min-h-screen pt-[104px] container mx-auto px-4 py-8"><h1 className="text-3xl font-bold">Returns & Exchanges</h1></div>} />
                    <Route path="/faq" element={<div className="min-h-screen pt-[104px] container mx-auto px-4 py-8"><h1 className="text-3xl font-bold">FAQ</h1></div>} />
                    <Route path="/contact" element={<div className="min-h-screen pt-[104px] container mx-auto px-4 py-8"><h1 className="text-3xl font-bold">Contact Us</h1></div>} />
                    <Route path="/privacy" element={<div className="min-h-screen pt-[104px] container mx-auto px-4 py-8"><h1 className="text-3xl font-bold">Privacy Policy</h1></div>} />
                    <Route path="/terms" element={<div className="min-h-screen pt-[104px] container mx-auto px-4 py-8"><h1 className="text-3xl font-bold">Terms of Service</h1></div>} />
                    <Route path="/cookies" element={<div className="min-h-screen pt-[104px] container mx-auto px-4 py-8"><h1 className="text-3xl font-bold">Cookie Policy</h1></div>} />
                    <Route path="/forgot-password" element={<div className="min-h-screen pt-[104px] container mx-auto px-4 py-8"><h1 className="text-3xl font-bold">Forgot Password</h1></div>} />
                    
                    {/* 404 */}
                    <Route path="*" element={<NotFound />} />
                  </Routes>
                </main>
                <Footer />
              </div>
            </SmoothScroll>
          </BrowserRouter>
          
          <Toaster 
            position="top-right" 
            richColors 
            closeButton
            toastOptions={{
              style: {
                fontFamily: 'inherit',
              },
            }}
          />
        </CartProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;

import type { Product, Category, EditorialArticle, HeroSlide, NavItem } from '@/types';

export const heroSlides: HeroSlide[] = [
  {
    id: '1',
    title: 'CASUAL ESSENTIALS',
    subtitle: 'Streetwear that moves with you',
    image: '/images/hero-casual.jpg',
    cta: 'SHOP NOW',
    href: '/casual',
  },
  {
    id: '2',
    title: 'PROFESSIONAL UNIFORMS',
    subtitle: 'Elevate your work wardrobe',
    image: '/images/hero-uniforms.jpg',
    cta: 'SHOP NOW',
    href: '/uniforms',
  },
  {
    id: '3',
    title: 'BACK TO SCHOOL',
    subtitle: 'Uniforms with modern style',
    image: '/images/hero-school.jpg',
    cta: 'SHOP NOW',
    href: '/school',
  },
];

export const categories: Category[] = [
  {
    id: 'casual',
    name: 'CASUAL WEAR',
    image: '/images/category-casual.jpg',
    href: '/casual',
    description: 'T-shirts, Hoodies, Jeans, Jackets',
  },
  {
    id: 'corporate',
    name: 'CORPORATE',
    image: '/images/category-corporate.jpg',
    href: '/corporate',
    description: 'Shirts, Trousers, Blazers, Dresses',
  },
  {
    id: 'medical',
    name: 'MEDICAL',
    image: '/images/category-medical.jpg',
    href: '/medical',
    description: 'Scrubs, Lab Coats, Clogs',
  },
  {
    id: 'hospitality',
    name: 'HOSPITALITY',
    image: '/images/category-hospitality.jpg',
    href: '/hospitality',
    description: 'Chef Coats, Aprons, Service Shirts',
  },
  {
    id: 'workwear',
    name: 'WORKWEAR',
    image: '/images/category-workwear.jpg',
    href: '/workwear',
    description: 'Coveralls, Utility Pants, Safety Boots',
  },
  {
    id: 'school',
    name: 'SCHOOL UNIFORMS',
    image: '/images/category-school.jpg',
    href: '/school',
    description: 'Shirts, Trousers, Blazers, PE Kits',
  },
  {
    id: 'accessories',
    name: 'ACCESSORIES',
    image: '/images/category-accessories.jpg',
    href: '/accessories',
    description: 'Bags, Caps, Belts',
  },
];

export const products: Product[] = [
  // Trending Now - Casual
  {
    id: 'c1',
    name: 'Oversized Cotton T-Shirt',
    price: 29,
    image: '/images/product-tshirt.jpg',
    category: 'casual',
    subcategory: 'tshirts',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: ['Black', 'White', 'Grey'],
    isNew: true,
  },
  {
    id: 'c2',
    name: 'Premium Fleece Hoodie',
    price: 59,
    image: '/images/product-hoodie.jpg',
    category: 'casual',
    subcategory: 'hoodies',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: ['Grey', 'Black', 'Navy'],
    isNew: true,
  },
  {
    id: 'c3',
    name: 'Slim Fit Dark Jeans',
    price: 49,
    image: '/images/product-jeans.jpg',
    category: 'casual',
    subcategory: 'jeans',
    sizes: ['28', '30', '32', '34', '36'],
    colors: ['Black', 'Indigo'],
  },
  {
    id: 'c4',
    name: 'Tailored Wool Blazer',
    price: 129,
    image: '/images/product-blazer.jpg',
    category: 'casual',
    subcategory: 'jackets',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: ['Black', 'Charcoal'],
  },
  // Uniform Essentials
  {
    id: 'u1',
    name: 'Classic Dress Shirt',
    price: 45,
    image: '/images/product-shirt.jpg',
    category: 'corporate',
    subcategory: 'shirts',
    sizes: ['14', '15', '16', '17', '18'],
    colors: ['White', 'Light Blue'],
  },
  {
    id: 'u2',
    name: 'Tailored Dress Pants',
    price: 65,
    image: '/images/product-trousers.jpg',
    category: 'corporate',
    subcategory: 'trousers',
    sizes: ['28', '30', '32', '34', '36'],
    colors: ['Black', 'Navy', 'Charcoal'],
  },
  {
    id: 'u3',
    name: 'Performance Scrubs Set',
    price: 55,
    image: '/images/product-scrubs.jpg',
    category: 'medical',
    subcategory: 'scrubs',
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    colors: ['Charcoal', 'Navy', 'Black'],
  },
  {
    id: 'u4',
    name: 'Professional Lab Coat',
    price: 75,
    image: '/images/product-labcoat.jpg',
    category: 'medical',
    subcategory: 'labcoats',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: ['White'],
  },
  // Back to School
  {
    id: 's1',
    name: 'School Blazer with Crest',
    price: 89,
    image: '/images/product-school-blazer.jpg',
    category: 'school',
    subcategory: 'blazers',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: ['Navy', 'Black'],
  },
  {
    id: 's2',
    name: 'Leather Tote Bag',
    price: 79,
    image: '/images/product-bag.jpg',
    category: 'accessories',
    subcategory: 'bags',
    sizes: ['One Size'],
    colors: ['Black', 'Brown'],
  },
];

export const editorialArticles: EditorialArticle[] = [
  {
    id: '1',
    title: 'How to Style Your Scrubs Outside the Hospital',
    subtitle: 'From shift to street - effortless transitions',
    image: '/images/editorial-scrubs.jpg',
    href: '/editorial/scrubs-style',
  },
  {
    id: '2',
    title: 'School Uniforms That Actually Look Good',
    subtitle: 'Modern classics for the new generation',
    image: '/images/editorial-school.jpg',
    href: '/editorial/school-style',
  },
  {
    id: '3',
    title: 'From Office to Dinner: Versatile Pieces',
    subtitle: 'Work to weekend styling guide',
    image: '/images/editorial-workweekend.jpg',
    href: '/editorial/work-weekend',
  },
];

export const navItems: NavItem[] = [
  { label: 'CASUAL', href: '/casual' },
  { label: 'UNIFORMS', href: '/uniforms' },
  { label: 'SCHOOL', href: '/school' },
  { label: 'NEW IN', href: '/new-in' },
  { label: 'SALE', href: '/sale' },
];

export const footerLinks = {
  customerCare: [
    { label: 'Size Guide', href: '/size-guide' },
    { label: 'Uniform Policies', href: '/policies' },
    { label: 'Shipping Info', href: '/shipping' },
    { label: 'Returns & Exchanges', href: '/returns' },
    { label: 'Track Order', href: '/track' },
  ],
  forBusiness: [
    { label: 'Bulk Orders', href: '/bulk' },
    { label: 'Corporate Accounts', href: '/corporate' },
    { label: 'School Programs', href: '/school-programs' },
    { label: 'Become a Partner', href: '/partner' },
  ],
  about: [
    { label: 'Our Story', href: '/about' },
    { label: 'Sustainability', href: '/sustainability' },
    { label: 'Careers', href: '/careers' },
    { label: 'Press', href: '/press' },
  ],
};

// Helper functions for product search and filtering
export const getProductsByCategory = (category: string): Product[] => {
  return products.filter(p => p.category === category);
};

export const getNewArrivals = (): Product[] => {
  return products.filter(p => p.isNew).slice(0, 8);
};

export const getSaleProducts = (): Product[] => {
  return products.filter(p => p.isSale).slice(0, 8);
};

export const getProductById = (id: string): Product | undefined => {
  return products.find(p => p.id === id);
};

export const getRelatedProducts = (product: Product): Product[] => {
  return products
    .filter(p => p.category === product.category && p.id !== product.id)
    .slice(0, 4);
};

export const searchProducts = (query: string): Product[] => {
  const lowercaseQuery = query.toLowerCase();
  return products.filter(
    p =>
      p.name.toLowerCase().includes(lowercaseQuery) ||
      p.category.toLowerCase().includes(lowercaseQuery) ||
      p.subcategory.toLowerCase().includes(lowercaseQuery)
  );
};

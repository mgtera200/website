import emailjs from '@emailjs/browser';
import type { Order, User } from '@/types';

// EmailJS configuration
const EMAILJS_SERVICE_ID = import.meta.env.VITE_EMAILJS_SERVICE_ID || '';
const EMAILJS_TEMPLATE_ID = import.meta.env.VITE_EMAILJS_TEMPLATE_ID || '';
const EMAILJS_PUBLIC_KEY = import.meta.env.VITE_EMAILJS_PUBLIC_KEY || '';
const ADMIN_EMAIL = 'eng.mostafa.tera@gmail.com';

// Initialize EmailJS
export const initEmailJS = () => {
  if (EMAILJS_PUBLIC_KEY) {
    emailjs.init(EMAILJS_PUBLIC_KEY);
  }
};

interface EmailData {
  to_email: string;
  to_name: string;
  subject: string;
  message: string;
  order_number?: string;
  order_total?: string;
  order_status?: string;
  tracking_number?: string;
  tracking_url?: string;
}

// Send email using EmailJS
export const sendEmail = async (data: EmailData): Promise<{ success: boolean; error?: string }> => {
  try {
    if (!EMAILJS_SERVICE_ID || !EMAILJS_TEMPLATE_ID || !EMAILJS_PUBLIC_KEY) {
      console.warn('EmailJS not configured');
      return { success: false, error: 'EmailJS not configured' };
    }

    const response = await emailjs.send(
      EMAILJS_SERVICE_ID,
      EMAILJS_TEMPLATE_ID,
      {
        to_email: data.to_email,
        to_name: data.to_name,
        subject: data.subject,
        message: data.message,
        order_number: data.order_number || '',
        order_total: data.order_total || '',
        order_status: data.order_status || '',
        tracking_number: data.tracking_number || '',
        tracking_url: data.tracking_url || '',
      }
    );

    if (response.status === 200) {
      return { success: true };
    } else {
      return { success: false, error: `EmailJS returned status ${response.status}` };
    }
  } catch (error) {
    console.error('Error sending email:', error);
    return { success: false, error: String(error) };
  }
};

// Send order confirmation email to customer
export const sendOrderConfirmationEmail = async (
  user: User,
  order: Order
): Promise<{ success: boolean; error?: string }> => {
  const itemsList = order.items
    .map(item => `${item.name} - Size: ${item.size}, Color: ${item.color} x${item.quantity} - ${item.price * item.quantity} EGP`)
    .join('\n');

  const message = `
Dear ${user.first_name},

Thank you for your order! We've received your order and are processing it now.

Order Details:
Order Number: ${order.order_number}
Date: ${new Date(order.created_at).toLocaleDateString()}

Items:
${itemsList}

Subtotal: ${order.subtotal} EGP
Shipping: ${order.shipping_cost} EGP
${order.discount_amount > 0 ? `Discount: -${order.discount_amount} EGP\n` : ''}
Total: ${order.total} EGP

Shipping Address:
${order.shipping_address.first_name} ${order.shipping_address.last_name}
${order.shipping_address.address_line1}
${order.shipping_address.address_line2 ? order.shipping_address.address_line2 + '\n' : ''}${order.shipping_address.city}, ${order.shipping_address.state || ''} ${order.shipping_address.postal_code || ''}
${order.shipping_address.country}

We'll send you another email when your order ships.

If you have any questions, please contact us at support@exa-fashion.com

Best regards,
The EXA Team
  `;

  return sendEmail({
    to_email: user.email,
    to_name: `${user.first_name} ${user.last_name}`,
    subject: `Order Confirmation - ${order.order_number}`,
    message,
    order_number: order.order_number,
    order_total: `${order.total} EGP`,
  });
};

// Send order notification to admin
export const sendAdminOrderNotification = async (
  order: Order,
  user: User
): Promise<{ success: boolean; error?: string }> => {
  const itemsList = order.items
    .map(item => `${item.name} - Size: ${item.size}, Color: ${item.color} x${item.quantity} - ${item.price * item.quantity} EGP`)
    .join('\n');

  const message = `
New Order Received!

Order Number: ${order.order_number}
Customer: ${user.first_name} ${user.last_name} (${user.email})
Date: ${new Date(order.created_at).toLocaleDateString()}

Items:
${itemsList}

Subtotal: ${order.subtotal} EGP
Shipping: ${order.shipping_cost} EGP
${order.discount_amount > 0 ? `Discount: -${order.discount_amount} EGP\n` : ''}
Total: ${order.total} EGP

Payment Method: ${order.payment_method}
Payment Status: ${order.payment_status}

Shipping Address:
${order.shipping_address.first_name} ${order.shipping_address.last_name}
${order.shipping_address.address_line1}
${order.shipping_address.address_line2 ? order.shipping_address.address_line2 + '\n' : ''}${order.shipping_address.city}, ${order.shipping_address.state || ''} ${order.shipping_address.postal_code || ''}
${order.shipping_address.country}

Phone: ${order.shipping_address.phone}

Please process this order as soon as possible.
  `;

  return sendEmail({
    to_email: ADMIN_EMAIL,
    to_name: 'EXA Admin',
    subject: `New Order - ${order.order_number}`,
    message,
    order_number: order.order_number,
    order_total: `${order.total} EGP`,
  });
};

// Send order status update email
export const sendOrderStatusUpdateEmail = async (
  user: User,
  order: Order
): Promise<{ success: boolean; error?: string }> => {
  const statusMessages: Record<string, string> = {
    pending: 'Your order is pending confirmation.',
    confirmed: 'Your order has been confirmed and is being prepared.',
    processing: 'Your order is being processed.',
    shipped: 'Your order has been shipped!',
    delivered: 'Your order has been delivered.',
    cancelled: 'Your order has been cancelled.',
    refunded: 'Your order has been refunded.',
  };

  let message = `
Dear ${user.first_name},

${statusMessages[order.status] || 'Your order status has been updated.'}

Order Number: ${order.order_number}
Status: ${order.status.toUpperCase()}
  `;

  if (order.tracking_number) {
    message += `\nTracking Number: ${order.tracking_number}`;
  }
  if (order.tracking_url) {
    message += `\nTrack your order: ${order.tracking_url}`;
  }

  message += `

If you have any questions, please contact us at support@exa-fashion.com

Best regards,
The EXA Team
  `;

  return sendEmail({
    to_email: user.email,
    to_name: `${user.first_name} ${user.last_name}`,
    subject: `Order Update - ${order.order_number}`,
    message,
    order_number: order.order_number,
    order_status: order.status,
    tracking_number: order.tracking_number,
    tracking_url: order.tracking_url,
  });
};

// Send newsletter welcome email
export const sendNewsletterWelcomeEmail = async (
  email: string
): Promise<{ success: boolean; error?: string }> => {
  const message = `
Welcome to the EXA newsletter!

Thank you for subscribing to our newsletter. You'll be the first to know about:
- New arrivals
- Exclusive offers
- Sales and promotions
- Style tips and trends

If you have any questions, please contact us at support@exa-fashion.com

Best regards,
The EXA Team
  `;

  return sendEmail({
    to_email: email,
    to_name: 'Subscriber',
    subject: 'Welcome to EXA Newsletter',
    message,
  });
};

// Send password reset email
export const sendPasswordResetEmail = async (
  email: string,
  resetUrl: string
): Promise<{ success: boolean; error?: string }> => {
  const message = `
Password Reset Request

You requested a password reset for your EXA account.

Please click the link below to reset your password:
${resetUrl}

This link will expire in 24 hours.

If you didn't request this, please ignore this email.

Best regards,
The EXA Team
  `;

  return sendEmail({
    to_email: email,
    to_name: 'User',
    subject: 'Password Reset - EXA',
    message,
  });
};

import { createClient } from '@supabase/supabase-js';
import type { User, UserAddress, Product, Order, OrderItem } from '@/types';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
const hasCredentials = supabaseUrl && supabaseAnonKey && 
  supabaseUrl !== 'your_supabase_url_here' && 
  supabaseAnonKey !== 'your_anon_key_here';

export const supabase = hasCredentials 
  ? createClient(supabaseUrl, supabaseAnonKey, {
      auth: {
        autoRefreshToken: true,
        persistSession: true,
        detectSessionInUrl: true,
      },
    })
  : createMockClient();

export const isDemoMode = !hasCredentials;

function createMockClient() {
  console.warn('⚠️ Supabase credentials not found. Running in DEMO mode.');
  const mockData = {
    auth: {
      getSession: () => Promise.resolve({ data: { session: null }, error: null }),
      getUser: () => Promise.resolve({ data: { user: null }, error: null }),
      onAuthStateChange: (callback: any) => {
        callback('SIGNED_OUT', null);
        return { data: { subscription: { unsubscribe: () => {} } } };
      },
      signUp: () => Promise.resolve({ data: null, error: { message: "Demo mode - Supabase not configured" } }),
      signInWithPassword: () => Promise.resolve({ data: null, error: { message: "Demo mode - Supabase not configured" } }),
      signInWithOAuth: () => Promise.resolve({ data: null, error: { message: "Demo mode - Supabase not configured" } }),
      signOut: () => Promise.resolve({ error: null }),
    },
    from: (_table: string) => ({
      select: () => ({
        eq: () => ({
          single: () => Promise.resolve({ data: null, error: null }),
          order: () => Promise.resolve({ data: [], error: null }),
        }),
        order: () => Promise.resolve({ data: [], error: null }),
        limit: () => Promise.resolve({ data: [], error: null }),
      }),
      insert: () => Promise.resolve({ data: null, error: null }),
      update: () => Promise.resolve({ data: null, error: null }),
      delete: () => Promise.resolve({ error: null }),
    }),
  };
  return mockData as any;
}

// Auth helpers
export const signUpWithEmail = async (email: string, password: string, userData: { first_name: string; last_name: string; phone?: string }) => {
  if (isDemoMode) return { data: null, error: { message: "DEMO MODE" } };
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        first_name: userData.first_name,
        last_name: userData.last_name,
        phone: userData.phone,
        role: 'customer',
      },
    },
  });
  return { data, error };
};

export const signInWithEmail = async (email: string, password: string) => {
  if (isDemoMode) return { data: null, error: { message: "DEMO MODE" } };
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  return { data, error };
};

export const signInWithGoogle = async () => {
  if (isDemoMode) return { data: null, error: { message: "DEMO MODE" } };
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: 'google',
    options: { redirectTo: `${window.location.origin}/auth/callback` },
  });
  return { data, error };
};

export const signInWithApple = async () => {
  if (isDemoMode) return { data: null, error: { message: "DEMO MODE" } };
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: 'apple',
    options: { redirectTo: `${window.location.origin}/auth/callback` },
  });
  return { data, error };
};

export const signOut = async () => {
  if (isDemoMode) return { error: null };
  const { error } = await supabase.auth.signOut();
  return { error };
};

export const getCurrentUser = async () => {
  if (isDemoMode) return { user: null, error: null };
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error || !user) return { user: null, error };
  const { data: profile, error: profileError } = await supabase
    .from('users').select('*').eq('id', user.id).single();
  return { user: profile as User | null, error: profileError };
};

// THIS WAS MISSING - ADD THIS FUNCTION
export const updateUserProfile = async (userId: string, updates: Partial<User>) => {
  if (isDemoMode) return { data: null, error: null };
  const { data, error } = await supabase
    .from('users')
    .update(updates)
    .eq('id', userId)
    .select()
    .single();
  return { data: data as User | null, error };
};

// Address helpers
export const getUserAddresses = async (userId: string) => {
  if (isDemoMode) return { data: [], error: null };
  const { data, error } = await supabase.from('addresses').select('*').eq('user_id', userId).order('is_default', { ascending: false });
  return { data: data as UserAddress[] | null, error };
};

export const addAddress = async (address: Omit<UserAddress, 'id' | 'created_at'>) => {
  if (isDemoMode) return { data: null, error: null };
  const { data, error } = await supabase.from('addresses').insert(address).select().single();
  return { data: data as UserAddress | null, error };
};

export const updateAddress = async (addressId: string, updates: Partial<UserAddress>) => {
  if (isDemoMode) return { data: null, error: null };
  const { data, error } = await supabase.from('addresses').update(updates).eq('id', addressId).select().single();
  return { data: data as UserAddress | null, error };
};

export const deleteAddress = async (addressId: string) => {
  if (isDemoMode) return { error: null };
  const { error } = await supabase.from('addresses').delete().eq('id', addressId);
  return { error };
};

// Product helpers
export const getProducts = async (filters?: { category?: string; is_sale?: boolean; is_new?: boolean; limit?: number }) => {
  if (isDemoMode) return { data: [], error: null };
  let query = supabase.from('products').select('*');
  if (filters?.category) query = query.eq('category', filters.category);
  if (filters?.is_sale) query = query.eq('is_sale', true);
  if (filters?.is_new) query = query.eq('is_new', true);
  if (filters?.limit) query = query.limit(filters.limit);
  const { data, error } = await query.order('created_at', { ascending: false });
  return { data: data as Product[] | null, error };
};

export const getProductById = async (productId: string) => {
  if (isDemoMode) return { data: null, error: null };
  const { data, error } = await supabase.from('products').select('*').eq('id', productId).single();
  return { data: data as Product | null, error };
};

export const getProductReviews = async (productId: string) => {
  if (isDemoMode) return { data: [], error: null };
  const { data, error } = await supabase.from('product_reviews').select('*').eq('product_id', productId).order('created_at', { ascending: false });
  return { data, error };
};

// Order helpers
export const getUserOrders = async (userId: string) => {
  if (isDemoMode) return { data: [], error: null };
  const { data, error } = await supabase.from('orders').select('*, items:order_items(*)').eq('user_id', userId).order('created_at', { ascending: false });
  return { data: data as Order[] | null, error };
};

export const getOrderById = async (orderId: string) => {
  if (isDemoMode) return { data: null, error: null };
  const { data, error } = await supabase.from('orders').select('*, items:order_items(*)').eq('id', orderId).single();
  return { data: data as Order | null, error };
};

export const createOrder = async (order: Omit<Order, 'id' | 'created_at' | 'updated_at'>, items: Omit<OrderItem, 'id' | 'order_id'>[]) => {
  if (isDemoMode) return { data: { ...order, id: 'demo-order-id' } as Order, error: null };
  const { data: orderData, error: orderError } = await supabase.from('orders').insert(order).select().single();
  if (orderError || !orderData) return { data: null, error: orderError };
  const orderItems = items.map(item => ({ ...item, order_id: (orderData as Order).id }));
  const { error: itemsError } = await supabase.from('order_items').insert(orderItems);
  if (itemsError) {
    await supabase.from('orders').delete().eq('id', (orderData as Order).id);
    return { data: null, error: itemsError };
  }
  return { data: orderData as Order, error: null };
};

export const updateOrderStatus = async (orderId: string, updates: Partial<Order>) => {
  if (isDemoMode) return { data: null, error: null };
  const { data, error } = await supabase.from('orders').update(updates).eq('id', orderId).select().single();
  return { data: data as Order | null, error };
};

// Wishlist helpers
export const getUserWishlist = async (userId: string) => {
  if (isDemoMode) return { data: [], error: null };
  const { data, error } = await supabase.from('wishlist').select('*, product:products(*)').eq('user_id', userId);
  return { data, error };
};

export const addToWishlist = async (userId: string, productId: string) => {
  if (isDemoMode) return { data: null, error: null };
  const { data, error } = await supabase.from('wishlist').insert({ user_id: userId, product_id: productId }).select().single();
  return { data, error };
};

export const removeFromWishlist = async (wishlistId: string) => {
  if (isDemoMode) return { error: null };
  const { error } = await supabase.from('wishlist').delete().eq('id', wishlistId);
  return { error };
};

// Newsletter helpers
export const subscribeNewsletter = async (email: string) => {
  if (isDemoMode) return { data: null, error: null };
  const { data, error } = await supabase.from('newsletter_subscribers').upsert({ email, subscribed: true }, { onConflict: 'email' }).select().single();
  return { data, error };
};

// Admin helpers
export const getAllOrders = async (filters?: { status?: string; limit?: number; offset?: number }) => {
  if (isDemoMode) return { data: [], error: null, count: 0 };
  let query = supabase.from('orders').select('*, items:order_items(*), user:users(first_name, last_name, email)', { count: 'exact' });
  if (filters?.status) query = query.eq('status', filters.status);
  if (filters?.limit) query = query.limit(filters.limit);
  if (filters?.offset) query = query.range(filters.offset, filters.offset + (filters.limit || 10) - 1);
  const { data, error, count } = await query.order('created_at', { ascending: false });
  return { data: data as Order[] | null, error, count };
};

export const getDashboardStats = async () => {
  if (isDemoMode) return { totalOrders: 0, totalRevenue: 0, totalCustomers: 0, totalProducts: 0, recentOrders: [] };
  const { count: totalOrders } = await supabase.from('orders').select('*', { count: 'exact', head: true });
  const { data: revenueData } = await supabase.from('orders').select('total').eq('payment_status', 'paid');
  const totalRevenue = (revenueData as { total: number }[] | null)?.reduce((sum, order) => sum + order.total, 0) || 0;
  const { count: totalCustomers } = await supabase.from('users').select('*', { count: 'exact', head: true }).eq('role', 'customer');
  const { count: totalProducts } = await supabase.from('products').select('*', { count: 'exact', head: true });
  const { data: recentOrders } = await supabase.from('orders').select('*, items:order_items(*), user:users(first_name, last_name)').order('created_at', { ascending: false }).limit(10);
  return { totalOrders: totalOrders || 0, totalRevenue, totalCustomers: totalCustomers || 0, totalProducts: totalProducts || 0, recentOrders: (recentOrders as Order[] | null) || [] };
};

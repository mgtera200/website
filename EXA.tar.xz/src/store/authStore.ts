import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { User, UserAddress } from '@/types';
import { supabase, getCurrentUser, getUserAddresses } from '@/lib/supabase';

interface AuthState {
  user: User | null;
  addresses: UserAddress[];
  isLoading: boolean;
  isAuthenticated: boolean;
  setUser: (user: User | null) => void;
  setAddresses: (addresses: UserAddress[]) => void;
  addAddress: (address: UserAddress) => void;
  updateAddress: (addressId: string, updates: Partial<UserAddress>) => void;
  removeAddress: (addressId: string) => void;
  setDefaultAddress: (addressId: string) => void;
  refreshUser: () => Promise<void>;
  logout: () => Promise<void>;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      addresses: [],
      isLoading: true,
      isAuthenticated: false,

      setUser: (user) => {
        set({ user, isAuthenticated: !!user, isLoading: false });
        if (user) {
          get().refreshUser();
        }
      },

      setAddresses: (addresses) => set({ addresses }),

      addAddress: (address) => {
        const addresses = get().addresses;
        // If this is the first address or marked as default, update others
        if (address.is_default || addresses.length === 0) {
          const updatedAddresses = addresses.map(a => ({ ...a, is_default: false }));
          set({ addresses: [...updatedAddresses, address] });
        } else {
          set({ addresses: [...addresses, address] });
        }
      },

      updateAddress: (addressId, updates) => {
        const addresses = get().addresses.map(address => {
          if (address.id === addressId) {
            return { ...address, ...updates };
          }
          // If setting this as default, remove default from others
          if (updates.is_default && address.id !== addressId) {
            return { ...address, is_default: false };
          }
          return address;
        });
        set({ addresses });
      },

      removeAddress: (addressId) => {
        const addresses = get().addresses.filter(a => a.id !== addressId);
        set({ addresses });
      },

      setDefaultAddress: (addressId) => {
        const addresses = get().addresses.map(address => ({
          ...address,
          is_default: address.id === addressId,
        }));
        set({ addresses });
      },

      refreshUser: async () => {
        try {
          const { user, error } = await getCurrentUser();
          if (user && !error) {
            set({ user, isAuthenticated: true });
            // Fetch user addresses
            const { data: addresses } = await getUserAddresses(user.id);
            if (addresses) {
              set({ addresses });
            }
          }
        } catch (error) {
          console.error('Error refreshing user:', error);
        } finally {
          set({ isLoading: false });
        }
      },

      logout: async () => {
        await supabase.auth.signOut();
        set({ user: null, addresses: [], isAuthenticated: false });
      },
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({ user: state.user, addresses: state.addresses }),
    }
  )
);

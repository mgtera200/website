import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { CartItem } from '@/types';
import { supabase } from '@/lib/supabase';
import { useAuthStore } from './authStore';

interface CartState {
  items: CartItem[];
  couponCode: string | null;
  discountAmount: number;
  isLoading: boolean;
  
  // Actions
  addItem: (item: Omit<CartItem, 'id'>) => void;
  removeItem: (itemId: string) => void;
  updateQuantity: (itemId: string, quantity: number) => void;
  updateSize: (itemId: string, size: string) => void;
  updateColor: (itemId: string, color: string) => void;
  clearCart: () => void;
  applyCoupon: (code: string, discountAmount: number) => void;
  removeCoupon: () => void;
  syncWithServer: () => Promise<void>;
  mergeGuestCart: (guestItems: CartItem[]) => void;
  
  // Getters
  getItemCount: () => number;
  getSubtotal: () => number;
  getTotal: () => number;
  getShippingCost: () => number;
  isInCart: (productId: string, size?: string, color?: string) => boolean;
}

const SHIPPING_THRESHOLD = 1000; // Free shipping over 1000 EGP
const SHIPPING_COST = 50;

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      couponCode: null,
      discountAmount: 0,
      isLoading: false,

      addItem: (item) => {
        const items = get().items;
        const existingItem = items.find(
          i => i.product_id === item.product_id && i.size === item.size && i.color === item.color
        );

        if (existingItem) {
          // Update quantity if item already exists
          const updatedItems = items.map(i =>
            i.id === existingItem.id
              ? { ...i, quantity: Math.min(i.quantity + item.quantity, i.stock) }
              : i
          );
          set({ items: updatedItems });
        } else {
          // Add new item
          const newItem: CartItem = {
            ...item,
            id: `${item.product_id}-${item.size}-${item.color}-${Date.now()}`,
          };
          set({ items: [...items, newItem] });
        }

        // Sync with server if user is logged in
        const user = useAuthStore.getState().user;
        if (user) {
          get().syncWithServer();
        }
      },

      removeItem: (itemId) => {
        set({ items: get().items.filter(i => i.id !== itemId) });
        const user = useAuthStore.getState().user;
        if (user) {
          get().syncWithServer();
        }
      },

      updateQuantity: (itemId, quantity) => {
        if (quantity <= 0) {
          get().removeItem(itemId);
          return;
        }
        
        const items = get().items.map(item =>
          item.id === itemId ? { ...item, quantity: Math.min(quantity, item.stock) } : item
        );
        set({ items });
        
        const user = useAuthStore.getState().user;
        if (user) {
          get().syncWithServer();
        }
      },

      updateSize: (itemId, size) => {
        const items = get().items.map(item =>
          item.id === itemId ? { ...item, size } : item
        );
        set({ items });
      },

      updateColor: (itemId, color) => {
        const items = get().items.map(item =>
          item.id === itemId ? { ...item, color } : item
        );
        set({ items });
      },

      clearCart: () => {
        set({ items: [], couponCode: null, discountAmount: 0 });
        const user = useAuthStore.getState().user;
        if (user) {
          supabase.from('cart_items').delete().eq('user_id', user.id);
        }
      },

      applyCoupon: (code, discountAmount) => {
        set({ couponCode: code, discountAmount });
      },

      removeCoupon: () => {
        set({ couponCode: null, discountAmount: 0 });
      },

      syncWithServer: async () => {
        const user = useAuthStore.getState().user;
        if (!user) return;

        set({ isLoading: true });
        try {
          // Get server cart
          const { data: serverCart } = await supabase
            .from('cart_items')
            .select('*')
            .eq('user_id', user.id);

          if (serverCart) {
            // Merge local cart with server cart
            const localItems = get().items;
            const mergedItems = [...localItems];

            for (const serverItem of serverCart) {
              const existingIndex = mergedItems.findIndex(
                i => i.product_id === serverItem.product_id && 
                     i.size === serverItem.size && 
                     i.color === serverItem.color
              );

              if (existingIndex >= 0) {
                // Update quantity if exists
                mergedItems[existingIndex].quantity = Math.max(
                  mergedItems[existingIndex].quantity,
                  serverItem.quantity
                );
              } else {
                mergedItems.push(serverItem as CartItem);
              }
            }

            set({ items: mergedItems });

            // Sync back to server
            await supabase.from('cart_items').delete().eq('user_id', user.id);
            if (mergedItems.length > 0) {
              const cartItemsToInsert = mergedItems.map(item => ({
                user_id: user.id,
                product_id: item.product_id,
                variant_id: item.variant_id,
                name: item.name,
                price: item.price,
                quantity: item.quantity,
                size: item.size,
                color: item.color,
                image: item.image,
                stock: item.stock,
              }));
              await supabase.from('cart_items').insert(cartItemsToInsert);
            }
          }
        } catch (error) {
          console.error('Error syncing cart:', error);
        } finally {
          set({ isLoading: false });
        }
      },

      mergeGuestCart: (guestItems) => {
        const currentItems = get().items;
        const mergedItems = [...currentItems];

        for (const guestItem of guestItems) {
          const existingIndex = mergedItems.findIndex(
            i => i.product_id === guestItem.product_id && 
                 i.size === guestItem.size && 
                 i.color === guestItem.color
          );

          if (existingIndex >= 0) {
            mergedItems[existingIndex].quantity = Math.min(
              mergedItems[existingIndex].quantity + guestItem.quantity,
              mergedItems[existingIndex].stock
            );
          } else {
            mergedItems.push(guestItem);
          }
        }

        set({ items: mergedItems });
        get().syncWithServer();
      },

      getItemCount: () => {
        return get().items.reduce((total, item) => total + item.quantity, 0);
      },

      getSubtotal: () => {
        return get().items.reduce((total, item) => total + item.price * item.quantity, 0);
      },

      getShippingCost: () => {
        const subtotal = get().getSubtotal();
        return subtotal >= SHIPPING_THRESHOLD ? 0 : SHIPPING_COST;
      },

      getTotal: () => {
        const subtotal = get().getSubtotal();
        const shipping = get().getShippingCost();
        const discount = get().discountAmount;
        return Math.max(0, subtotal + shipping - discount);
      },

      isInCart: (productId, size, color) => {
        return get().items.some(
          i => i.product_id === productId && 
               (!size || i.size === size) && 
               (!color || i.color === color)
        );
      },
    }),
    {
      name: 'cart-storage',
      partialize: (state) => ({ 
        items: state.items, 
        couponCode: state.couponCode, 
        discountAmount: state.discountAmount 
      }),
    }
  )
);
